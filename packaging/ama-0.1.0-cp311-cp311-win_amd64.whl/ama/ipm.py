"""Innere-Punkte-Loeser (Mehrotra, primal-dual) fuer das duale Kontakt-QP auf der expliziten
Nachgiebigkeitsmatrix F:

    min 1/2 lam^T F lam - d^T lam,   lam_I >= 0 (Ungleichungszeilen),   Gn lam = en.

Keine Aktivmengen-Kombinatorik: je Schritt ein Sattelsystem [F + D, -Gn^T; Gn, 0] mit der
Barriere-Diagonale D = z/lam. Das Faktor-Backend (CPU float64, CPU float32, GPU float32 mit
cuSOLVER potrf in place) faktorisiert das Jacobi-skalierte M = F + D naeherungsweise, die
Nachiteration in float64 (F bleibt im RAM) macht jede Loesung exakt bis 1e-12. Danach der
exakte Abschluss: Sattelsystem auf {lam > z}, Pruefung, bei Verletzungen die Arbeitsmenge.
"""
from __future__ import annotations

import time

import numpy as np
import scipy.linalg as sla

from . import dicht


class FaktorCPU:
    """M = F + diag(D), Jacobi-skaliert (Diagonale 1), Cholesky in `dtype`: float64 exakt,
    float32 wie auf der GPU (dann traegt die Nachiteration die Genauigkeit)."""

    def __init__(self, Fd, dtype=np.float64):
        self.F = Fd
        self.dtype = np.dtype(dtype)
        self.m = Fd.shape[0]
        self.s = None
        self.L = None

    def bereit(self, D) -> None:
        self.s = 1.0 / np.sqrt(np.diag(self.F) + D)
        for delta in (0.0, 1e-7, 1e-5, 1e-3):
            M = ((self.F * self.s[:, None]) * self.s[None, :]).astype(self.dtype)
            np.fill_diagonal(M, 1.0 + delta)
            try:
                self.L = np.linalg.cholesky(M)
                self.delta = delta
                return
            except np.linalg.LinAlgError:
                continue
        raise RuntimeError("F + D auch mit Verschiebung nicht positiv definit")

    def loese(self, r):
        """Naeherung x von (F + D) x = r, r (m,) oder (m, k) in float64."""
        s = self.s[:, None] if r.ndim == 2 else self.s
        y = (s * r).astype(self.dtype)
        y = sla.solve_triangular(self.L, y, lower=True, check_finite=False)
        y = sla.solve_triangular(self.L, y, lower=True, trans="T", check_finite=False)
        return s * y.astype(np.float64)


class FaktorGPU:
    """Wie FaktorCPU(float32), aber auf der Grafikkarte: ein persistenter float32-Puffer (m x m),
    je Schritt Upload von F32, Skalierung in place, cuSOLVER spotrf in place (unteres Dreieck
    in Fortran-Ordnung = oberes Dreieck des C-geordneten Puffers), Loesen mit trsm."""

    def __init__(self, Fd):
        import cupy as cp
        from cupy.cuda import cublas, cusolver, device

        self.cp, self.cusolver, self.cublas = cp, cusolver, cublas
        self.handle = device.get_cusolver_handle()
        self.blas = device.get_cublas_handle()
        self.eins = np.array(1.0, dtype=np.float32)
        self.zeiten = {"upload": 0.0, "potrf": 0.0, "loesen": 0.0}
        self.F = Fd
        self.m = Fd.shape[0]
        self.F32 = np.ascontiguousarray(Fd, dtype=np.float32)
        self.M = cp.empty((self.m, self.m), dtype=cp.float32)
        self.info = cp.zeros(1, dtype=np.int32)
        lw = cusolver.spotrf_bufferSize(self.handle, cublas.CUBLAS_FILL_MODE_LOWER, self.m, self.M.data.ptr, self.m)
        self.work = cp.empty(lw, dtype=cp.float32)
        self.s = None

    def bereit(self, D) -> None:
        cp = self.cp
        self.s = 1.0 / np.sqrt(np.diag(self.F) + D)
        sg = cp.asarray(self.s.astype(np.float32))
        for delta in (0.0, 1e-7, 1e-5, 1e-3):
            t0 = time.perf_counter()
            self.M.set(self.F32)
            self.M *= sg[:, None]
            self.M *= sg[None, :]
            cp.fill_diagonal(self.M, np.float32(1.0 + delta))
            cp.cuda.Stream.null.synchronize()
            t1 = time.perf_counter()
            self.cusolver.spotrf(self.handle, self.cublas.CUBLAS_FILL_MODE_LOWER, self.m, self.M.data.ptr, self.m,
                                 self.work.data.ptr, self.work.size, self.info.data.ptr)
            ok = int(self.info[0]) == 0
            self.zeiten["upload"] += t1 - t0
            self.zeiten["potrf"] += time.perf_counter() - t1
            if ok:
                self.delta = delta
                return
        raise RuntimeError("F + D auf der GPU auch mit Verschiebung nicht positiv definit")

    def loese(self, r):
        """Ohne Kopie des 5-GB-Puffers: cuBLAS trsm direkt. Der C-geordnete Puffer ist in
        Fortran-Sicht die Transponierte, dort steht L (unten) mit M = L L^T; die rechte Seite
        muss Fortran-geordnet sein (m x k)."""
        cp, cublas = self.cp, self.cublas
        t0 = time.perf_counter()
        s = self.s[:, None] if r.ndim == 2 else self.s
        k = r.shape[1] if r.ndim == 2 else 1
        y = cp.asarray(np.asfortranarray((s * r).astype(np.float32)))
        for op in (cublas.CUBLAS_OP_N, cublas.CUBLAS_OP_T):
            cublas.strsm(self.blas, cublas.CUBLAS_SIDE_LEFT, cublas.CUBLAS_FILL_MODE_LOWER, op,
                         cublas.CUBLAS_DIAG_NON_UNIT, self.m, k, self.eins.ctypes.data, self.M.data.ptr, self.m,
                         y.data.ptr, self.m)
        x = s * cp.asnumpy(y).astype(np.float64)
        self.zeiten["loesen"] += time.perf_counter() - t0
        return x


class SattelIPM:
    """[F + D, -Gn^T; Gn, 0]: Backend-Naeherung plus Nachiteration in float64."""

    def __init__(self, Fd, Gn, faktor, prox_alpha: float = 1e-3):
        self.F = Fd
        self.Gn = Gn                                   # (rn x m) dicht oder None
        self.rn = 0 if Gn is None else Gn.shape[0]
        self.faktor = faktor
        self.prox_alpha = prox_alpha
        self.rho = 0.0
        self.D = None
        self.Y = None
        self.S_cho = None
        self.nachiterationen = 0

    def bereit(self, D) -> None:
        self.D = D
        self.faktor.bereit(D)
        if self.rn:
            self.Y = self.faktor.loese(self.Gn.T)                      # M^-1 Gn^T (m x rn)
            S = self.Gn @ self.Y
            S = (S + S.T) / 2
            # Moden proximal regularisiert: [M, -Gn^T; Gn, rho I]. Schwach gehaltene Koerper
            # (Eigenwerte von S bis 1e-8 bei Mittel 1e-3) machten die Richtung sonst zu einer
            # riesigen Starrkoerperbewegung, Schrittweite 0,05 (gemessen 17.09.2026). Das
            # Gleichgewicht konvergiert ueber das aeussere Residuum.
            self.rho = self.prox_alpha * float(np.trace(S)) / self.rn
            self.S_cho = sla.cho_factor(S + self.rho * np.eye(self.rn), lower=True, check_finite=False)

    def _M(self, x):
        return self.F @ x + self.D * x

    def loese_M(self, r, tol: float = 1e-12, max_it: int = 60):
        """(F + D) x = r in float64: vorkonditioniertes CG mit dem Backend-Faktor als
        Vorkonditionierer. Die einfache Nachiteration braucht ||I - M~^-1 M|| < 1; am Drehlager
        (Kondition ~1e7 nach Jacobi-Skalierung) ist der float32-Faktor der GPU dafuer zu grob
        (Rate 0,7, gemessen 17.09.2026), CG konvergiert mit ~sqrt(Kondition des vorkonditionierten
        Systems)."""
        normr = max(float(np.linalg.norm(r)), 1e-300)
        x = np.zeros_like(r)
        res = r.copy()
        z = self.faktor.loese(res)
        p = z.copy()
        rz = float(res @ z)
        for it in range(max_it):
            Mp = self._M(p)
            alpha = rz / float(p @ Mp)
            x = x + alpha * p
            res = res - alpha * Mp
            self.nachiterationen += 1
            if float(np.linalg.norm(res)) <= tol * normr:
                break
            z = self.faktor.loese(res)
            rz_neu = float(res @ z)
            p = z + (rz_neu / rz) * p
            rz = rz_neu
        return x

    def _naeherung(self, r1, r2, genau: bool):
        x = self.loese_M(r1) if genau else self.faktor.loese(r1)
        if not self.rn:
            return x, np.zeros(0)
        a = sla.cho_solve(self.S_cho, r2 - self.Gn @ x, check_finite=False)
        return x + self.Y @ a, a

    def loese(self, r1, r2, tol: float = 1e-12, max_it: int = 10):
        """x, alpha mit (F + D) x - Gn^T alpha = r1, Gn x = r2: M-Loesungen mit CG genau, der
        Schur-Anteil der Moden (Y aus der Backend-Naeherung) wird aussen nachiteriert."""
        x, a = self._naeherung(r1, r2, True)
        skala = max(float(np.linalg.norm(r1)), float(np.linalg.norm(r2)) if self.rn else 0.0, 1e-300)
        for it in range(max_it):
            res1 = r1 - self._M(x)
            if self.rn:
                res1 = res1 + self.Gn.T @ a
                res2 = r2 - self.Gn @ x - self.rho * a
            else:
                res2 = np.zeros(0)
            res = max(float(np.linalg.norm(res1)), float(np.linalg.norm(res2)) if self.rn else 0.0)
            if res <= tol * skala:
                break
            dx, da = self._naeherung(res1, res2, True)
            x, a = x + dx, a + da
        return x, a


def _schritt(x, dx) -> float:
    neg = dx < 0.0
    if not neg.any():
        return 1.0
    return float(min(1.0, np.min(-x[neg] / dx[neg])))


def loese_ipm(Fd, dual, faktor, tol: float = 1e-9, max_it: int = 60, log=print, start=None, ablage=None,
              prox: float = 1e-6):
    """Mehrotra-Praediktor-Korrektor (gemeinsamer Schritt fuer lam, alpha, z). `start`:
    (lam, alpha, z) zum Fortsetzen, `ablage`: Pfad, unter dem der Zustand je Schritt liegt.
    Liefert lam (skaliert), alpha (rn), z (Spalt der Ungleichungszeilen), Schritte, konvergiert."""
    t0 = time.perf_counter()
    if dual.reib.k:
        raise NotImplementedError("Reibung: nur der dichte Weg (ama.dicht.loese_reibung)")
    m = dual.m
    I = dual.ungleich
    E = ~I
    mI = int(I.sum())
    d, en = dual.d, dual.en
    Gn = (dual.T.T @ dual.G.toarray()) if dual.rn else None
    sattel = SattelIPM(Fd, Gn, faktor)
    med = float(np.median(np.diag(Fd)))
    delta_E = 1e-12 * med                                      # Gleichungszeilen: F allein muss dort tragen
    # proximale Regularisierung des Newton-Systems (F + D + delta I): F ist nur positiv
    # semidefinit (abhaengige Zeilen); bei geschlossenen Zeilen ist D = z/lam winzig und die
    # Richtung schiesst entlang der Nullrichtungen - Schrittweiten 0,05 (gemessen 17.09.2026)
    delta = prox * med
    D = np.full(m, delta_E + delta)
    # Startwert: alle Zeilen als Gleichungen (auf dem Backend), dann ins Innere geschoben
    if start is not None:
        lam, alpha, z = (np.array(v, float) for v in start)
        log(f"IPM: Fortsetzung mit gegebenem Zustand")
    else:
        sattel.bereit(D)
        lam, alpha = sattel.loese(d, en)
        # Startpunkt weit weg, aber zentriert: theta in der Groesse der weggeschnittenen Zugkraefte
        # (99-%-Quantil von |lam*|). Mit theta = 0,1 * mean|lam*| wollte der erste Newton-Schritt
        # die Zugzeilen um |lam*| ~ 1e3 verschieben, Ratio-Test 1e-4, Stillstand (gemessen 17.09.2026)
        theta = max(float(np.quantile(np.abs(lam[I]), 0.99)), 1e-300) if mI else 1.0
        lam[I] = np.maximum(lam[I], theta)
        z = np.full(mI, theta)
        log(f"IPM: Startwert ({time.perf_counter() - t0:.1f} s), theta {theta:.3e}")
    ok = False
    it = 0
    for it in range(1, max_it + 1):
        t1 = time.perf_counter()
        z_ext = np.zeros(m)
        z_ext[I] = z
        r_d = Fd @ lam - d - z_ext - (Gn.T @ alpha if dual.rn else 0.0)
        r_p = (Gn @ lam - en) if dual.rn else np.zeros(0)
        mu = float(lam[I] @ z) / max(mI, 1)
        rel_d = float(np.linalg.norm(r_d)) / max(float(np.linalg.norm(d)), 1e-300)
        rel_p = (float(np.linalg.norm(r_p)) / max(float(np.linalg.norm(en)), float(np.linalg.norm(Gn @ lam)), 1e-300)) if dual.rn else 0.0
        rel_mu = float(lam[I] @ z) / max(abs(float(d @ lam)), 1e-300)
        # Gleichgewicht: mit der Moden-Regularisierung konvergieren schwache Moden nur langsam
        # (gemessen 17.09.2026: 2,8e-3 bleibt); der exakte Abschluss loest es ohne rho - deshalb
        # reicht hier 1e-2
        if rel_d <= tol and rel_p <= max(tol, 1e-2) and rel_mu <= tol:
            ok = True
            log(f"IPM {it}: konvergiert - Residuum {rel_d:.1e}, Gleichgewicht {rel_p:.1e}, Dualitaetsluecke {rel_mu:.1e}")
            break
        D = np.full(m, delta_E + delta)
        D[I] = z / lam[I] + delta
        sattel.bereit(D)
        rhs1 = -r_d - z_ext
        rhs2 = -r_p
        dl_a, da_a = sattel.loese(rhs1, rhs2)
        dz_a = -z - (z / lam[I]) * dl_a[I]
        a_p = _schritt(lam[I], dl_a[I])
        a_d = _schritt(z, dz_a)
        mu_a = float((lam[I] + a_p * dl_a[I]) @ (z + a_d * dz_a)) / max(mI, 1)
        sigma = min(1.0, max(0.0, (mu_a / mu) ** 3)) if mu > 0 else 0.0
        korr = (sigma * mu - dl_a[I] * dz_a) / lam[I]
        rhs1c = rhs1.copy()
        rhs1c[I] += korr
        dl, da = sattel.loese(rhs1c, rhs2)
        dz = -z + korr - (z / lam[I]) * dl[I]
        # gemeinsamer Schritt: im QP steht lam auch im dualen Residuum (F lam), getrennte
        # Schritte (LP-Regel) zerstoeren die lineare Reduktion von mu (gemessen 17.09.2026:
        # mu stagniert bei 2e-4 trotz Schritten 0,9/0,75)
        a_p = a_d = 0.99 * min(_schritt(lam[I], dl[I]), _schritt(z, dz), 1.0)
        if min(a_p, a_d) < 0.2 and sigma < 0.8:
            # schlecht zentriert (gemessen 17.09.2026: Stillstand bei mu ~ 2e-2 mit Schritten 0,05):
            # reine Zentrierung mit sigma = 0,9, dieselbe Faktorisierung
            korr_z = 0.9 * mu / lam[I]
            rhs_z = rhs1.copy()
            rhs_z[I] += korr_z
            dl_z, da_z = sattel.loese(rhs_z, rhs2)
            dz_z = -z + korr_z - (z / lam[I]) * dl_z[I]
            a_pz = a_dz = 0.99 * min(_schritt(lam[I], dl_z[I]), _schritt(z, dz_z), 1.0)
            if min(a_pz, a_dz) > min(a_p, a_d):
                dl, da, dz, a_p, a_d, sigma = dl_z, da_z, dz_z, a_pz, a_dz, 0.9
        lam = lam + a_p * dl
        alpha = alpha + a_p * da
        z = z + a_d * dz
        if ablage is not None:
            np.savez(ablage, lam=lam, alpha=alpha, z=z, schritt=it)
        a = min(a_p, a_d)
        if a < 0.3:
            ip = int(np.argmin(np.where(dl[I] < 0, lam[I] / np.maximum(-dl[I], 1e-300), np.inf)))
            iz = int(np.argmin(np.where(dz < 0, z / np.maximum(-dz, 1e-300), np.inf)))
            log(f"  blockiert: primal Zeile {ip} lam {lam[I][ip]:.2e} dlam {dl[I][ip]:.2e} z {z[ip]:.2e} F_ii {np.diag(Fd)[I][ip]:.2e}; "
                f"dual Zeile {iz} z {z[iz]:.2e} dz {dz[iz]:.2e} lam {lam[I][iz]:.2e}")
        log(f"IPM {it}: mu {mu:.2e}, Residuum {rel_d:.1e}, Gleichgewicht {rel_p:.1e}, Luecke {rel_mu:.1e}, "
            f"Schritt {a_p:.3f}/{a_d:.3f}, sigma {sigma:.2f}, {int((lam[I] > z).sum())} von {mI} eher geschlossen, "
            f"Nachiterationen {sattel.nachiterationen}, {time.perf_counter() - t1:.1f} s"
            + (f", Backend {' '.join(f'{k} {v:.0f}' for k, v in faktor.zeiten.items())} s" if hasattr(faktor, "zeiten") else ""))
    return lam, alpha, z, it, ok


def abschluss(Fd, dual, lam, alpha, z, tol: float = 1e-9, max_runden: int = 10, log=print):
    """Exakt auf {lam > z}: Sattelsystem, Pruefung, bei Verletzungen die Arbeitsmenge.
    Liefert lam, alpha, Runden, konvergiert."""
    I = dual.ungleich
    C = ~I
    C[I] = lam[I] > z
    lam_e, alpha_e, unzul, _ = dicht.loesung_dicht(Fd, dual, C)
    if unzul:
        log("Abschluss: Koerpermode ohne Halt auf {lam > z} - IPM-Werte bleiben")
        return lam, alpha, 0, False
    sp_ = dicht.spalt_von(Fd, dual, lam_e, alpha_e)
    zug = C & I & (lam_e < -tol * max(float(np.abs(lam_e).max()), 1e-300))
    durch = ~C & I & (sp_ < -tol * max(float(np.abs(sp_).max()), 1e-300))
    log(f"Abschluss: {int((C & I).sum())} geschlossen, Zug {int(zug.sum())}, Durchdringung {int(durch.sum())}")
    if not zug.any() and not durch.any():
        return lam_e, alpha_e, 0, True
    return dicht.arbeitsmenge(Fd, dual, C, zug | durch, lam0=lam_e, alpha0=alpha_e, max_runden=max_runden,
                              band=0.0, fuge_min=0, log=log)


def loese_ipm_dicht(Fd, dual, faktor, tol: float = 1e-9, max_it: int = 60, log=print, start=None, ablage=None) -> dict:
    t0 = time.perf_counter()
    lam, alpha, z, schritte, ok_ipm = loese_ipm(Fd, dual, faktor, tol=tol, max_it=max_it, log=log, start=start, ablage=ablage)
    lam, alpha, runden, ok = abschluss(Fd, dual, lam, alpha, z, log=log)
    alpha_r = dual.T @ alpha if dual.rn else np.zeros(dual.r)
    u = dual.verschiebung(lam, alpha_r)
    return {"lam": dual.skal * lam, "lam_skal": lam, "alpha": alpha_r, "u": u, "schritte": schritte,
            "ipm_konvergiert": ok_ipm, "runden": runden, "konvergiert": ok, "zeit": time.perf_counter() - t0}
