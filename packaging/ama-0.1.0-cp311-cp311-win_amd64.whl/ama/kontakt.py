"""Duales Kontaktproblem ohne Reibung: SMALBE (augmentierte Lagrange-Schleife
fuer G lam = e) mit MPRGP (projizierter Gradient mit Proportionalitaet fuer
lam_ungleich >= 0) nach Dostal, Optimal Quadratic Programming Algorithms, 2009.

Jede Anwendung von F = B K^+ B^T kostet eine Rueckwaertseinsetzung je Koerper -
keine Faktorisierung. Kontaktfindung: einmal alle Zeilen als Gleichungen loesen
(CG, grob), Aktivmenge = positive Kraefte; das ist der Startwert.

Die Zeilen von G = R^T B^T werden orthonormiert (Gn = T^T G mit T aus der
Eigenzerlegung von G G^T): erst dann wirkt die Augmentierung rho * Gn^T Gn mit
rho = ||F|| gleichmaessig (Dostal, TFETI), und der Rang von G G^T zeigt sofort,
welche Starrkoerpermode keine Bedingung hat.
"""
from __future__ import annotations

import time

import numpy as np
import scipy.sparse as sp


class KeinHalt(RuntimeError):
    """Ein Koerper findet in einer Richtung keinen Halt (Grobproblem unloesbar)."""


RICHTUNGEN = ("Verschiebung x", "Verschiebung y", "Verschiebung z",
              "Verdrehung um x", "Verdrehung um y", "Verdrehung um z")


def _diag_mit_boden(kb) -> np.ndarray:
    d = np.abs(kb.K.diagonal())
    rho = float(d.mean()) if len(d) else 1.0
    return np.where(d < 1e-8 * rho, rho, d)


class Dual:
    """Operatoren des dualen Problems auf den freien FHG aller Koerper."""

    def __init__(self, koerper, offsets, B, ungleich, g, f, reib=None):
        from .bedingungen import Reibung

        self.k = koerper
        self.off = np.asarray(offsets, np.int64)
        self.ungleich = np.asarray(ungleich, bool)
        self.reib = reib if reib is not None else Reibung()
        self.f = np.asarray(f, float)
        B = sp.csr_matrix(B)
        self.m, self.n = B.shape
        # Zeilenskalierung ("lumped"): diag(F)_i ~ sum_j B_ij^2 / K_jj wird zu eins. Zeilen mit
        # sehr verschiedener Steifigkeit (Einzel-FHG-Lager neben gewichteten Flaechenzeilen)
        # kaemen sonst mit sehr verschiedenen Krafteinheiten in dasselbe QP. lam = skal * lam_s.
        # FHG ohne Steifigkeit (Stabknoten quer zur Achse: K_jj = 0) bekommen die Nachgiebigkeit
        # der verallgemeinerten Inversen, 1/rho mit rho = mittlere Diagonale des Koerpers - sonst
        # wird die Zeile mit 1e-150 skaliert und verschwindet numerisch (640 Ankerzeilen am
        # Drehlager, gemessen 17.09.2026)
        kdiag = np.concatenate([_diag_mit_boden(kb) for kb in koerper]) if self.n else np.zeros(0)
        B2 = B.multiply(B)
        dF = np.asarray(B2 @ (1.0 / np.maximum(kdiag, 1e-300))).ravel() if self.m else np.zeros(0)
        self.skal = 1.0 / np.sqrt(np.maximum(dF, 1e-300))
        # Reibgruppen: Tangentialzeilen sind weder Schranke noch Gleichung (`tang`); die drei
        # Zeilen einer Gruppe tragen die Skalierung der Normalzeile, damit der Kreis
        # ||lam_t|| <= mu lam_n in skalierten Groessen ein Kreis bleibt
        self.tang = np.zeros(self.m, bool)
        if self.reib.k:
            self.tang[self.reib.t.ravel()] = True
            self.skal[self.reib.t[:, 0]] = self.skal[self.reib.n]
            self.skal[self.reib.t[:, 1]] = self.skal[self.reib.n]
        self.gleich = ~self.ungleich & ~self.tang
        self.B = sp.diags(self.skal) @ B if self.m else B
        self.B = sp.csr_matrix(self.B)
        self.Bt = self.B.T.tocsr()
        self.g = self.skal * np.asarray(g, float)
        self.anwendungen = 0
        self.uf = self.kplus(self.f)
        self.d = self.B @ self.uf - self.g
        bloecke, es, self.r_je = [], [], []
        for i, kb in enumerate(koerper):
            r = kb.R.shape[1] if kb.nf else 0
            self.r_je.append(r)
            if r == 0:
                continue
            a, b = self.off[i], self.off[i + 1]
            bloecke.append(sp.csr_matrix((self.B[:, a:b] @ kb.R).T))
            es.append(kb.R.T @ self.f[a:b])
        self.G = sp.vstack(bloecke).tocsr() if bloecke else sp.csr_matrix((0, self.m))
        self.e = np.concatenate(es) if es else np.zeros(0)
        self.r = self.G.shape[0]
        self.r_off = np.concatenate([[0], np.cumsum(self.r_je)]).astype(np.int64)
        # Orthonormierte Zeilen: Gn = T^T G, en = T^T e; Nullrichtungen von G G^T sind
        # Starrkoerpermoden ohne Bedingung
        self.nullrichtungen: list = []
        if self.r:
            GGt = (self.G @ self.G.T).toarray()
            w, V = np.linalg.eigh((GGt + GGt.T) / 2)
            ok = w > 1e-12 * max(w.max(), 1e-300)
            for v in V[:, ~ok].T:
                self.nullrichtungen.append(v)
            # Gn = T^T G bleibt implizit: G duenn (r x m), T dicht (r x rn) - Gn selbst waere
            # dicht (rn x m; am Drehlager 4000 x 42000 = 1,3 GB)
            self.T = np.ascontiguousarray(V[:, ok] / np.sqrt(w[ok]))
            self.en = self.T.T @ self.e
        else:
            self.T = np.zeros((0, 0))
            self.en = np.zeros(0)
        self.rn = self.T.shape[1]

    def Gn(self, lam):
        """Gn lam = T^T (G lam)."""
        return self.T.T @ (self.G @ lam)

    def Gnt(self, y):
        """Gn^T y = G^T (T y)."""
        return self.G.T @ (self.T @ y)

    def kplus(self, v):
        out = np.zeros_like(v)
        for i, kb in enumerate(self.k):
            a, b = self.off[i], self.off[i + 1]
            if b > a:
                out[a:b] = kb.loese(v[a:b])
        return out

    def F(self, lam):
        self.anwendungen += 1
        return self.B @ self.kplus(self.Bt @ lam)

    def A(self, lam, rho):
        y = self.F(lam)
        if self.rn:
            y = y + rho * self.Gnt(self.Gn(lam))
        return y

    def verschiebung(self, lam, alpha):
        u = self.uf - self.kplus(self.Bt @ lam)
        for i, kb in enumerate(self.k):
            if self.r_je[i]:
                u[self.off[i]:self.off[i + 1]] += kb.R @ alpha[self.r_off[i]:self.r_off[i + 1]]
        return u

    def unwucht(self, lam):
        """Je Koerper Kraft und Moment (6) der Last f - B^T lam auf den Starrkoerpermoden."""
        w = self.f - self.Bt @ lam
        aus = []
        for i, kb in enumerate(self.k):
            if self.r_je[i] == 0:
                aus.append(np.zeros(6))
                continue
            M = kb._starrkoerpermoden()[kb.frei]
            aus.append(M.T @ w[self.off[i]:self.off[i + 1]])
        return aus

    def richtung(self, v):
        """Koerper und physikalische Richtung einer Modenkombination v (Laenge r)."""
        i = max(range(len(self.k)), key=lambda j: np.linalg.norm(v[self.r_off[j]:self.r_off[j + 1]]))
        kb = self.k[i]
        vek = kb.R @ v[self.r_off[i]:self.r_off[i + 1]]
        M = kb._starrkoerpermoden()[kb.frei]
        M = M / np.maximum(np.linalg.norm(M, axis=0), 1e-300)
        return kb.name, RICHTUNGEN[int(np.argmax(np.abs(M.T @ vek)))]


def norm_schaetzung(op, m: int, schritte: int = 15, seed: int = 0) -> float:
    """Potenziteration fuer ||A||."""
    rng = np.random.default_rng(seed)
    x = rng.standard_normal(m)
    x /= np.linalg.norm(x)
    lam = 1.0
    for _ in range(schritte):
        y = op(x)
        lam = np.linalg.norm(y)
        if lam == 0.0:
            return 1.0
        x = y / lam
    return lam


def startwert(dual: Dual, rho: float, schritte: int = 40, tol: float = 1e-3) -> np.ndarray:
    """Alle Zeilen als Gleichungen: CG auf A_rho lam = d + rho Gn^T en, dann
    lam_ungleich = max(lam, 0). Die positiven Kraefte sind die vermutete Aktivmenge."""
    b = dual.d + (rho * dual.Gnt(dual.en) if dual.rn else 0.0)
    lam = np.zeros(dual.m)
    r = b.copy()
    p = r.copy()
    rr = r @ r
    nb = np.linalg.norm(b)
    for _ in range(schritte):
        if np.sqrt(rr) <= tol * nb:
            break
        Ap = dual.A(p, rho)
        pAp = p @ Ap
        if pAp <= 0:
            break
        a = rr / pAp
        lam += a * p
        r -= a * Ap
        rr_neu = r @ r
        p = r + (rr_neu / rr) * p
        rr = rr_neu
    lam[dual.ungleich] = np.maximum(lam[dual.ungleich], 0.0)
    return lam


def pcpg(dual: Dual, C: np.ndarray, lam0: np.ndarray, tol: float, max_it: int, bericht=None):
    """Gleichungsbeschraenktes QP auf der Menge C: min 1/2 lam'F lam - d'lam mit lam_O = 0
    und Gn lam = en, ueber projizierten CG (FETI): Projektor auf ker(Gn_C), Partikulaer-
    loesung fuer die Gleichung. Liefert lam (m), alpha (rn), F lam (m), Iterationen, info."""
    idx = np.flatnonzero(C)
    nC = len(idx)
    info = {"nullrichtungen": 0, "unzulaessig": False, "cg_rel": 0.0}
    if nC == 0:
        # keine Zeile geschlossen: jede belastete Starrkoerpermode ist ohne Halt
        if dual.rn:
            info["nullrichtungen"] = dual.rn
            info["unzulaessig"] = bool(np.linalg.norm(dual.en) > 1e-10 * max(np.linalg.norm(dual.f), 1e-300))
            info["nullvektoren"] = np.eye(dual.rn)
        return np.zeros(dual.m), np.zeros(dual.rn), np.zeros(dual.m), 0, info

    def voll(v):
        w = np.zeros(dual.m)
        w[idx] = v
        return w

    def F_C(v):
        return dual.F(voll(v))

    if dual.rn:
        GC = dual.G[:, idx]                                   # (r x nC) duenn
        GGt = dual.T.T @ (GC @ GC.T).toarray() @ dual.T       # Gn_C Gn_C^T (rn x rn)
        w, V = np.linalg.eigh((GGt + GGt.T) / 2)
        ok = w > 1e-12 * max(w.max(), 1e-300)
        info["nullrichtungen"] = int((~ok).sum())
        if (~ok).any():
            # Moden ohne geschlossene Zeile: neutral, wenn en dort verschwindet
            rest = V[:, ~ok].T @ dual.en
            info["unzulaessig"] = bool(np.abs(rest).max() > 1e-10 * max(np.linalg.norm(dual.en), 1e-300))
            info["nullvektoren"] = V[:, ~ok]
        Winv = V[:, ok] / w[ok]                               # (rn x ok)
        Vok = V[:, ok]

        def GGt_inv(y):
            return Winv @ (Vok.T @ y)

        def Gn_C(v):
            return dual.T.T @ (GC @ v)

        def Gn_Ct(y):
            return GC.T @ (dual.T @ y)

        def P(v):
            return v - Gn_Ct(GGt_inv(Gn_C(v)))

        lam_p = Gn_Ct(GGt_inv(dual.en))
    else:
        def P(v):
            return v

        lam_p = np.zeros(nC)

    rhs = dual.d[idx] - F_C(lam_p)[idx]
    mu = P(lam0[idx] - lam_p)
    r = P(rhs - F_C(mu)[idx])
    p = r.copy()
    rr = r @ r
    # Massstab: die Spaltgroesse |d|, nicht |P rhs| allein - bei gleichmaessigem Druck liegt
    # die rechte Seite fast ganz im Bild von Gn^T, |P rhs| ist dann Rundungsrauschen und ein
    # relatives Kriterium darauf laesst den CG endlos auf Rauschen laufen (17.09.2026)
    norm0 = max(np.linalg.norm(P(rhs)), np.linalg.norm(dual.d), 1e-300)
    it = 0
    while np.sqrt(rr) > tol * norm0 and it < max_it:
        q = P(F_C(p)[idx])
        pq = p @ q
        if pq <= 0.0:
            # Richtung ohne Kruemmung: nur noch Rundung uebrig
            break
        a = rr / pq
        mu += a * p
        r -= a * q
        rr_neu = r @ r
        p = r + (rr_neu / rr) * p
        rr = rr_neu
        it += 1
        if bericht is not None and it % 25 == 0:
            bericht(it, np.sqrt(rr) / norm0)
    lam = voll(lam_p + mu)
    Flam = dual.F(lam)
    alpha = GGt_inv(Gn_C(Flam[idx] - dual.d[idx])) if dual.rn else np.zeros(0)
    info["cg_rel"] = float(np.sqrt(rr) / norm0)
    return lam, alpha, Flam, it, info


def mprgp(A, b, lam0, ungleich, alpha, stop, max_iter: int, gamma: float = 1.0, bericht=None, vorkond=None):
    """min 1/2 lam'A lam - b'lam mit lam_i >= 0 auf `ungleich`. A ist eine Funktion.
    stop(norm_gP, lam, it) -> bool. `bericht(it, ngP, n_aktiv)` alle 50 Schritte.
    `vorkond(phi)` ist ein SPD-Vorkonditionierer; er wirkt nur in der Flaeche (freie
    Komponenten) auf die CG-Richtungen, Expansion und Proportionierung bleiben
    unvorkonditioniert (Dostal 2009, Vorkonditionierung in der Flaeche).
    Liefert lam, g, Iterationen, A-Anwendungen."""
    lam = lam0.copy()
    lam[ungleich] = np.maximum(lam[ungleich], 0.0)
    g = A(lam) - b
    n_A = 1

    def teile(lam, g):
        aktiv = ungleich & (lam <= 0.0)
        phi = np.where(aktiv, 0.0, g)
        beta = np.where(aktiv, np.minimum(g, 0.0), 0.0)
        return phi, beta, aktiv

    def richtung(phi, aktiv):
        if vorkond is None:
            return phi.copy()
        z = vorkond(phi)
        z[aktiv] = 0.0
        return z

    phi, beta, aktiv = teile(lam, g)
    p = richtung(phi, aktiv)
    it = 0
    while True:
        ngP = np.linalg.norm(phi + beta)
        if bericht is not None and it % 50 == 0:
            bericht(it, ngP, int(aktiv.sum()))
        if stop(ngP, lam, it) or it >= max_iter:
            break
        phit = phi.copy()
        frei_i = ungleich & ~aktiv & (phi > 0.0)
        phit[frei_i] = np.minimum(lam[frei_i] / alpha, phi[frei_i])
        if beta @ beta <= gamma * gamma * (phit @ phi):
            Ap = A(p)
            n_A += 1
            pAp = p @ Ap
            if pAp <= 0.0:
                # kein Abstieg in p: Expansion aus phi
                lam = lam - alpha * phi
                lam[ungleich] = np.maximum(lam[ungleich], 0.0)
                g = A(lam) - b
                n_A += 1
                phi, beta, aktiv = teile(lam, g)
                p = richtung(phi, aktiv)
            else:
                a_cg = (g @ p) / pAp
                maske = ungleich & (p > 0.0)
                a_f = np.min(lam[maske] / p[maske]) if maske.any() else np.inf
                if a_cg <= a_f:
                    lam = lam - a_cg * p
                    g = g - a_cg * Ap
                    phi, beta, aktiv = teile(lam, g)
                    z = richtung(phi, aktiv)
                    p = z - ((z @ Ap) / pAp) * p
                else:
                    # zulaessiger Halbschritt, dann Expansion mit der CG-Schrittweite
                    # (projizierter CG-Schritt, Kruzik u. a. 2020): mit 1/|A| wuchs die
                    # Aktivmenge am Drehlager um einzelne Zeilen je Schritt (17.09.2026:
                    # |gP| 2,6e5 -> 1,1e5 in 500 Schritten). Sicherung: faellt das Ziel nicht,
                    # wird der Schritt mit 1/|A| wiederholt.
                    lam_h = lam - a_f * p
                    g_h = g - a_f * Ap
                    f_alt = 0.5 * (lam_h @ g_h) - 0.5 * (lam_h @ b)
                    phi_h, _, _ = teile(lam_h, g_h)
                    lam = lam_h - max(a_cg, alpha) * phi_h
                    lam[ungleich] = np.maximum(lam[ungleich], 0.0)
                    g = A(lam) - b
                    n_A += 1
                    if 0.5 * (lam @ g) - 0.5 * (lam @ b) > f_alt:
                        lam = lam_h - alpha * phi_h
                        lam[ungleich] = np.maximum(lam[ungleich], 0.0)
                        g = A(lam) - b
                        n_A += 1
                    phi, beta, aktiv = teile(lam, g)
                    p = richtung(phi, aktiv)
        else:
            Ab = A(beta)
            n_A += 1
            bAb = beta @ Ab
            a_cg = (g @ beta) / bAb if bAb > 0 else 0.0
            lam = lam - a_cg * beta
            g = g - a_cg * Ab
            phi, beta, aktiv = teile(lam, g)
            p = richtung(phi, aktiv)
        it += 1
    return lam, g, it, n_A


def loese_smalbe(dual: Dual, lam: np.ndarray, mu: np.ndarray, tol: float, max_aussen: int, max_innen: int,
                 log: list, rho_faktor: float, deflation: bool, t0: float) -> dict:
    """SMALBE-M (augmentierte Lagrange-Schleife fuer Gn lam = en) mit MPRGP innen.
    Liefert lam (innere Skalierung), alpha_r (Starrkoerperanteil in der G-Basis), Zaehler, mu."""
    m, r, rn = dual.m, dual.r, dual.rn
    ungleich = dual.ungleich
    normF = norm_schaetzung(dual.F, m)
    rho = rho_faktor * normF
    A = lambda x: dual.A(x, rho)
    alpha_s = 1.0 / norm_schaetzung(A, m, seed=1)
    log.append(f"SMALBE: |F| {normF:.3e}, rho = {rho_faktor:g} |F|, Schrittweite {alpha_s:.3e}, {time.perf_counter() - t0:.1f} s")
    # Deflation der Starrkoerperrichtungen: Q = (I - Pi) + (|F|/rho) Pi mit Pi = Gn^T Gn.
    # A hat auf Bild(Gn^T) die Eigenwerte ~rho, auf dem Kern die von F; Q gleicht das aus,
    # damit die CG-Schritte nicht die steife rho-Richtung abarbeiten muessen.
    vorkond = None
    if deflation and rn:
        def vorkond(phi, faktor=normF / rho):
            pi = dual.Gnt(dual.Gn(phi))
            return phi - pi + faktor * pi
    nd = max(np.linalg.norm(dual.d), 1e-300)
    nf = max(np.linalg.norm(dual.f), np.linalg.norm(dual.e) if r else 0.0, 1e-300)
    eps_g = tol * nd
    eps_e = tol * nf
    lam = lam.copy()
    lam[ungleich] = np.maximum(lam[ungleich], 0.0)
    mu = mu.copy() if len(mu) == rn else np.zeros(rn)

    # M traegt die Einheit von F (Verschiebung je Kraft): M * |Gn lam - en| ist dann wie
    # |gP| eine Verschiebung; mit M = 1 bliebe die innere Genauigkeit bei eta haengen.
    # Die Kappe eta = 0,1 |d| ist gemessen richtig: relativ zum Anfangsgradienten
    # (0,1 max(|d|, |gP0|)) stieg der Aufwand am 16^3-Fall von 62 auf 943 F-Anwendungen,
    # weil die ersten Runden zu grob loesen (17.09.2026).
    M, beta_M, eta = rho, 10.0, 0.1 * nd
    L_alt = None
    innen = 0
    verl_hist = []
    konvergiert = False
    k = 0
    for k in range(max_aussen):
        b = dual.d - (dual.Gnt(mu) if rn else 0.0) + (rho * dual.Gnt(dual.en) if rn else 0.0)

        def stop(ngP, lam_, it, b=b):
            verl = np.linalg.norm(dual.Gn(lam_) - dual.en) if rn else 0.0
            return ngP <= max(min(M * verl, eta), eps_g)

        def bericht(it_, ngP_, n_aktiv, k=k):
            log.append(f"  MPRGP {it_}: |gP| {ngP_:.2e} (Ziel {eps_g:.2e}), {n_aktiv} an der Schranke, "
                       f"{dual.anwendungen} F-Anwendungen, {time.perf_counter() - t0:.0f} s")

        lam, grad, it, nA = mprgp(A, b, lam, ungleich, alpha_s, stop, max_innen, bericht=bericht, vorkond=vorkond)
        innen += it
        verl = (dual.Gn(lam) - dual.en) if rn else np.zeros(0)
        nverl = np.linalg.norm(dual.G @ lam - dual.e) if r else 0.0
        verl_hist.append(nverl)
        aktiv = ungleich & (lam <= 0.0)
        ngP = np.linalg.norm(np.where(aktiv, np.minimum(grad, 0.0), grad))
        log.append(f"SMALBE {k + 1}: MPRGP {it} Schritte, |gP| {ngP:.2e}, |G lam - e| {nverl:.2e}, M {M:.1e}")
        if ngP <= eps_g and nverl <= eps_e:
            konvergiert = True
            break
        L_neu = 0.5 * (lam @ A(lam)) - lam @ b
        if L_alt is not None and L_neu < L_alt + 0.5 * rho * float(verl @ verl):
            M = M / beta_M
        L_alt = L_neu
        mu = mu + rho * verl
        # Stillstand: zehn Runden ohne nennenswerten Fortschritt im Gleichgewicht -
        # dann gibt es keine zulaessige Loesung (ein Koerper hebt ab)
        if len(verl_hist) >= 10 and nverl > 0.9 * verl_hist[-10] and nverl > eps_e:
            break
    if not konvergiert:
        unw = dual.unwucht(lam)
        schlimm = max(range(len(dual.k)), key=lambda i: np.abs(unw[i]).max())
        richt = int(np.argmax(np.abs(unw[schlimm])))
        raise KeinHalt(f"{dual.k[schlimm].name}: kein Gleichgewicht, unausgeglichen in "
                       f"{RICHTUNGEN[richt]} ({unw[schlimm][richt]:.3e}) nach {k + 1} Runden")

    # Starrkoerperanteil aus den aktiven Zeilen: G_A^T alpha = (F lam - d)_A
    alpha_r = np.zeros(r)
    unterbestimmt = False
    if r:
        grad = dual.F(lam) - dual.d
        aktiv = ~ungleich | (lam > 0.0)
        GA = dual.G[:, aktiv].toarray().T
        if GA.shape[0] < r or np.linalg.matrix_rank(GA) < r:
            unterbestimmt = True
        alpha_r = np.linalg.lstsq(GA, grad[aktiv], rcond=None)[0]
    return {"lam": lam, "alpha_r": alpha_r, "aussen": k + 1, "innen": innen, "mu": mu,
            "unterbestimmt": unterbestimmt, "rho": rho}


def loese_aktivmenge(dual: Dual, lam0: np.ndarray, tol: float, max_it: int, log: list,
                     tol_cg_grob: float = 1e-4, t0: float = None) -> dict:
    """Primal-dualer Aktivmengen-Newton auf dem Dual: bei fester Menge C (geschlossene
    Kontakte + Gleichungszeilen) das gleichungsbeschraenkte QP exakt (pcpg), dann
    C_neu = gleich | {lam - Spalt > 0} (Hintermueller/Ito/Kunisch; c = 1 dank Zeilenskalierung).
    Liefert lam, alpha (rn), Flam, newton, cg, konvergiert, zyklus."""
    t0 = time.perf_counter() if t0 is None else t0
    ungleich = dual.ungleich
    gleich = ~ungleich
    m = dual.m
    lam = lam0.copy()
    lam[ungleich] = np.maximum(lam[ungleich], 0.0)
    C = gleich | (lam > 0.0)
    gesehen = set()
    cg_gesamt = 0
    alpha = np.zeros(dual.rn)
    Flam = np.zeros(m)
    for it in range(max_it):
        schluessel = C.tobytes()
        zyklus = schluessel in gesehen
        gesehen.add(schluessel)
        tol_cg = tol if it >= 2 else max(tol, tol_cg_grob)
        lam, alpha, Flam, cg, info = pcpg(dual, C, lam, tol_cg, max_it=2000)
        cg_gesamt += cg
        spalt = Flam - dual.d - (dual.Gnt(alpha) if dual.rn else 0.0)
        if info["unzulaessig"]:
            # ein Koerper ohne geschlossene Zeile, aber mit Last: seine Zeilen mit der
            # groessten Durchdringung aufnehmen; gibt es keine oder wiederholt sich das
            # Spiel (Zeilen aufgenommen, als Zug wieder entlassen), haelt ihn nichts -
            # SMALBE entscheidet dann mit seiner Gleichgewichtsdiagnose
            offen = np.flatnonzero(ungleich & ~C)
            kandidaten = offen[np.argsort(spalt[offen])[:max(6, len(offen) // 100)]] if len(offen) else np.zeros(0, int)
            if len(kandidaten) == 0:
                name, richt = dual.richtung(dual.T @ info["nullvektoren"][:, 0])
                raise KeinHalt(f"{name}: keine Bedingung haelt die {richt}, aber die Last greift dort an - kein Halt")
            if zyklus:
                log.append(f"Newton {it + 1}: Koerpermode ohne Halt wiederholt sich - Rueckfall auf SMALBE")
                return {"lam": lam, "alpha": alpha, "Flam": Flam, "newton": it + 1, "cg": cg_gesamt,
                        "konvergiert": False, "zyklus": True}
            C = C.copy()
            C[kandidaten] = True
            log.append(f"Newton {it + 1}: Koerpermode ohne Halt - {len(kandidaten)} Zeilen aufgenommen")
            continue
        C_neu = gleich | (ungleich & ((lam - spalt) > 0.0))
        wechsel = int((C_neu != C).sum())
        offen = ungleich & ~C
        durchdringung = float(max(0.0, -spalt[offen].min())) if offen.any() else 0.0
        log.append(f"Newton {it + 1}: {int((C & ungleich).sum())} geschlossen, {wechsel} Wechsel, "
                   f"CG {cg} (rel {info['cg_rel']:.1e}), Durchdringung {durchdringung:.2e}, "
                   f"{dual.anwendungen} F-Anwendungen, {time.perf_counter() - t0:.0f} s")
        if wechsel == 0 and info["cg_rel"] <= tol:
            return {"lam": lam, "alpha": alpha, "Flam": Flam, "newton": it + 1, "cg": cg_gesamt,
                    "konvergiert": True, "zyklus": False}
        if zyklus and wechsel > 0:
            log.append(f"Newton {it + 1}: Aktivmenge wiederholt sich - Rueckfall auf SMALBE")
            return {"lam": lam, "alpha": alpha, "Flam": Flam, "newton": it + 1, "cg": cg_gesamt,
                    "konvergiert": False, "zyklus": True}
        lam = np.where(C_neu, lam, 0.0)
        lam[ungleich] = np.maximum(lam[ungleich], 0.0)
        C = C_neu
    return {"lam": lam, "alpha": alpha, "Flam": Flam, "newton": max_it, "cg": cg_gesamt,
            "konvergiert": False, "zyklus": False}


def loese_dual(koerper, offsets, B, ungleich, g, f, tol: float = 1e-8, max_aussen: int = 60,
               max_innen: int = 3000, warm: dict = None, start: str = "gleichungen",
               protokoll: list = None, rho_faktor: float = 1e4, deflation: bool = True,
               verfahren: str = "newton", max_newton: int = 40, reib=None) -> dict:
    """Loest das duale Problem; liefert lam (physikalisch), u (freie FHG aller Koerper),
    alpha, Zaehler und Zustand fuer den Warmstart. `verfahren`: "newton" (Aktivmengen-Newton,
    Rueckfall SMALBE) oder "smalbe". Wirft KeinHalt, wenn ein Koerper keinen Halt findet."""
    t0 = time.perf_counter()
    log = protokoll if protokoll is not None else []
    if reib is not None and getattr(reib, "k", 0):
        raise NotImplementedError("Reibung: nur der dichte Weg (ama.dicht.loese_reibung)")
    dual = Dual(koerper, offsets, B, ungleich, g, f)
    m, r, rn = dual.m, dual.r, dual.rn
    log.append(f"Dual aufgebaut: {m} Zeilen, {r} Starrkoerpermoden, {time.perf_counter() - t0:.1f} s")

    # a priori: eine Starrkoerpermode ohne Bedingung (Nullrichtung von G G^T) ist nur
    # dann ein Fehler, wenn die Last in ihr angreift; sonst ist die Bewegung dort
    # unbestimmt (neutrales Gleichgewicht, z. B. reibungsfreies Gleiten) und wird null
    for v in dual.nullrichtungen:
        name, richt = dual.richtung(v)
        if abs(v @ dual.e) > tol * max(np.linalg.norm(f), 1e-300):
            raise KeinHalt(f"{name}: keine Bedingung haelt die {richt}, aber die Last greift dort an - kein Halt")
        log.append(f"{name}: {richt} unbestimmt (keine Bedingung, keine Last) - wird null gesetzt")

    if m == 0:
        for i, kb in enumerate(koerper):
            if dual.r_je[i] and np.linalg.norm(dual.e[dual.r_off[i]:dual.r_off[i + 1]]) > tol * max(np.linalg.norm(f), 1e-300):
                raise KeinHalt(f"{kb.name}: frei und belastet, keine Bedingung haelt")
        return {"lam": np.zeros(0), "u": dual.uf.copy(), "alpha": np.zeros(0), "aussen": 0, "innen": 0,
                "newton": 0, "anwendungen": 0, "zustand": {"lam": np.zeros(0), "mu": np.zeros(0)},
                "start_aktiv": np.zeros(0, bool), "unterbestimmt": False, "rho": 0.0, "verfahren": verfahren,
                "zeit": time.perf_counter() - t0, "protokoll": log}

    # Startwert: Warmstart, sonst alle Zeilen als Gleichungen (grob), positive Kraefte aktiv
    if warm is not None and len(warm.get("lam", [])) == m:
        lam = np.asarray(warm["lam"], float).copy()
        mu = np.asarray(warm.get("mu", np.zeros(rn)), float).copy()
        log.append("Warmstart aus dem vorigen Zustand")
    else:
        mu = np.zeros(rn)
        if start == "gleichungen":
            lam, _, _, it0, _ = pcpg(dual, np.ones(m, bool), np.zeros(m), tol=1e-3, max_it=40)
            lam[ungleich] = np.maximum(lam[ungleich], 0.0)
            log.append(f"Startwert (alle Zeilen als Gleichungen, {it0} CG-Schritte): {int((lam > 0).sum())} von {m} aktiv, "
                       f"{time.perf_counter() - t0:.1f} s")
        else:
            lam = np.zeros(m)
    start_aktiv = lam > 0.0

    verf = verfahren
    newton_it, aussen, innen = 0, 0, 0
    alpha_r = np.zeros(r)
    unterbestimmt = False
    rho = 0.0
    if verfahren == "newton":
        erg_n = loese_aktivmenge(dual, lam, tol, max_newton, log, t0=t0)
        newton_it, innen = erg_n["newton"], erg_n["cg"]
        lam = erg_n["lam"]
        if erg_n["konvergiert"]:
            alpha_r = dual.T @ erg_n["alpha"] if rn else np.zeros(r)
        else:
            log.append("Aktivmengen-Newton nicht konvergiert - Rueckfall auf SMALBE")
            verf = "newton+smalbe"
    if verf != "newton":
        erg_s = loese_smalbe(dual, lam, mu, tol, max_aussen, max_innen, log, rho_faktor, deflation, t0)
        lam, alpha_r, mu = erg_s["lam"], erg_s["alpha_r"], erg_s["mu"]
        aussen, innen = erg_s["aussen"], innen + erg_s["innen"]
        unterbestimmt, rho = erg_s["unterbestimmt"], erg_s["rho"]

    u = dual.verschiebung(lam, alpha_r)
    # nach aussen die physikalischen Kraefte (Zeilenskalierung zurueckgenommen); der Zustand
    # fuer den Warmstart bleibt in der inneren Skalierung
    return {"lam": dual.skal * lam, "u": u, "alpha": alpha_r, "aussen": aussen, "innen": innen,
            "newton": newton_it, "anwendungen": dual.anwendungen,
            "zustand": {"lam": lam.copy(), "mu": mu.copy()}, "start_aktiv": start_aktiv,
            "unterbestimmt": unterbestimmt, "rho": rho, "verfahren": verf,
            "zeit": time.perf_counter() - t0, "protokoll": log}
