"""Vektorisierte Elementsteifigkeiten: alle Elemente eines Typs auf einmal
(numpy-einsum), kein Python je Element. Einheiten SI (m, N, Pa).

Hex8 hier ohne inkompatible Moden (Statik3D nutzt sie); fuer die Messung des
Kerns zaehlt das Muster, nicht die Formulierung. Knotenreihenfolge Hex8:
(-,-,-),(+,-,-),(+,+,-),(-,+,-),(-,-,+),(+,-,+),(+,+,+),(-,+,+).
"""
from __future__ import annotations

import itertools

import numpy as np

from . import ama_kern


def elastizitaet(E, nu) -> np.ndarray:
    """D-Matrix (..., 6, 6) fuer Voigt-Reihenfolge xx, yy, zz, xy, yz, zx."""
    E = np.asarray(E, float)
    nu = np.asarray(nu, float)
    lam = E * nu / ((1 + nu) * (1 - 2 * nu))
    mu = E / (2 * (1 + nu))
    D = np.zeros(np.broadcast(E, nu).shape + (6, 6))
    for i in range(3):
        for j in range(3):
            D[..., i, j] = lam
        D[..., i, i] = lam + 2 * mu
        D[..., 3 + i, 3 + i] = mu
    return D


def _b_matrix(dNx: np.ndarray) -> np.ndarray:
    """dNx (n_el, nk, 3) -> B (n_el, 6, 3*nk)."""
    n_el, nk, _ = dNx.shape
    B = np.zeros((n_el, 6, 3 * nk))
    for a in range(nk):
        gx, gy, gz = dNx[:, a, 0], dNx[:, a, 1], dNx[:, a, 2]
        B[:, 0, 3 * a] = gx
        B[:, 1, 3 * a + 1] = gy
        B[:, 2, 3 * a + 2] = gz
        B[:, 3, 3 * a] = gy
        B[:, 3, 3 * a + 1] = gx
        B[:, 4, 3 * a + 1] = gz
        B[:, 4, 3 * a + 2] = gy
        B[:, 5, 3 * a] = gz
        B[:, 5, 3 * a + 2] = gx
    return B


_HEX_VZ = np.array([[-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
                    [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]], float)


def hex8_steifigkeit(X: np.ndarray, E, nu) -> np.ndarray:
    """X (n_el, 8, 3) -> K (n_el, 24, 24), 2x2x2 Gauss."""
    X = np.asarray(X, float)
    n_el = X.shape[0]
    D = np.broadcast_to(elastizitaet(E, nu), (n_el, 6, 6))
    K = np.zeros((n_el, 24, 24))
    g = 1.0 / np.sqrt(3.0)
    for r, s, t in itertools.product((-g, g), repeat=3):
        dN = np.empty((8, 3))
        dN[:, 0] = _HEX_VZ[:, 0] * (1 + _HEX_VZ[:, 1] * s) * (1 + _HEX_VZ[:, 2] * t) / 8
        dN[:, 1] = _HEX_VZ[:, 1] * (1 + _HEX_VZ[:, 0] * r) * (1 + _HEX_VZ[:, 2] * t) / 8
        dN[:, 2] = _HEX_VZ[:, 2] * (1 + _HEX_VZ[:, 0] * r) * (1 + _HEX_VZ[:, 1] * s) / 8
        J = np.einsum("ai,eaj->eij", dN, X)           # J_ij = d x_j / d xi_i
        detJ = np.linalg.det(J)
        if np.any(detJ <= 0):
            raise ValueError("Hex8 mit nicht positiver Jacobi-Determinante")
        dNx = np.einsum("eij,aj->eai", np.linalg.inv(J), dN)
        B = _b_matrix(dNx)
        K += np.einsum("eia,eij,ejb,e->eab", B, D, B, detJ)
    return K


_TET_DN = np.array([[-1, -1, -1], [1, 0, 0], [0, 1, 0], [0, 0, 1]], float)


def tet4_steifigkeit(X: np.ndarray, E, nu) -> np.ndarray:
    """X (n_el, 4, 3) -> K (n_el, 12, 12), konstante Dehnung."""
    X = np.asarray(X, float)
    n_el = X.shape[0]
    D = np.broadcast_to(elastizitaet(E, nu), (n_el, 6, 6))
    J = np.einsum("ai,eaj->eij", _TET_DN, X)
    V = np.linalg.det(J) / 6.0
    if np.any(V <= 0):
        raise ValueError("Tet4 mit nicht positivem Volumen (Knotenreihenfolge)")
    dNx = np.einsum("eij,aj->eai", np.linalg.inv(J), _TET_DN)
    B = _b_matrix(dNx)
    return np.einsum("eia,eij,ejb,e->eab", B, D, B, V)


def gitter_hex8(m: int, laenge: float):
    """Wuerfel aus m^3 Hex8: Knoten X ((m+1)^3, 3), Elemente EL (m^3, 8)."""
    k = m + 1
    z, y, x = np.meshgrid(np.arange(k), np.arange(k), np.arange(k), indexing="ij")
    X = np.column_stack([x.ravel(), y.ravel(), z.ravel()]).astype(float) * (laenge / m)

    def idx(i, j, l):
        return i + k * (j + k * l)

    i, j, l = np.meshgrid(np.arange(m), np.arange(m), np.arange(m), indexing="ij")
    i, j, l = i.ravel(), j.ravel(), l.ravel()
    EL = np.column_stack([idx(i, j, l), idx(i + 1, j, l), idx(i + 1, j + 1, l), idx(i, j + 1, l),
                          idx(i, j, l + 1), idx(i + 1, j, l + 1), idx(i + 1, j + 1, l + 1), idx(i, j + 1, l + 1)])
    return X, EL.astype(np.int64)


def wuerfel_system(m: int, E: float = 210e9, nu: float = 0.3):
    """Wuerfel m^3 Hex8, Flaeche z=0 gehalten, -1 kN je Knoten auf z=L:
    unteres Dreieck K (csc), Lastvektor f, Assemblierzeit."""
    import time

    import scipy.sparse as sp

    X, EL = gitter_hex8(m, 1.0)
    Ke = hex8_steifigkeit(X[EL], E, nu)
    n = 3 * len(X)
    dofs = (3 * EL[:, :, None] + np.arange(3)[None, None, :]).reshape(len(EL), 24)
    fest_knoten = np.isclose(X[:, 2], 0.0)
    frei = np.repeat(~fest_knoten, 3)
    neu = -np.ones(n, dtype=np.int64)
    neu[frei] = np.arange(int(frei.sum()))
    nf = int(frei.sum())
    t0 = time.perf_counter()
    indptr, indices, data = ama_kern.assembliere(
        nf, 24, np.ascontiguousarray(neu[dofs].ravel()), np.ascontiguousarray(Ke.ravel()))
    t_ass = time.perf_counter() - t0
    K = sp.csc_matrix((data, indices, indptr), shape=(nf, nf))
    f = np.zeros(nf)
    oben = np.flatnonzero(np.isclose(X[:, 2], 1.0) & ~fest_knoten)
    f[neu[3 * oben + 2]] = -1000.0
    return K, f, t_ass
