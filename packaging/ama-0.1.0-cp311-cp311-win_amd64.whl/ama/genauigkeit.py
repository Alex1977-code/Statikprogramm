"""Genauigkeitsstufen: eine Zusage, daraus alle Toleranzen, und der Nachweis danach.

Die Stufe sagt zu, wie genau gerechnet wird. Sie setzt Residuum-Schranke, Zahl der
Nachiterationen und Rechenart; jeder dieser Werte laesst sich einzeln uebersteuern. Nach dem
Lauf steht im `Nachweis`, was erreicht wurde - gemessen, nicht behauptet.

Die Namen und Schranken sind die, die Statik3D schon kennt (`solver_residuum`), damit es nicht
zwei Bedienelemente fuer dieselbe Sache gibt.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace

# Rueckfall, wenn die Zusage nicht erreicht wird
RUECKFALL = ("genauer", "lockern")

# zulaessige Werte fuer die rechenart-Uebersteuerung
RECHENARTEN = ("double", "float32")


@dataclass(frozen=True)
class Stufe:
    """Ein Eintrag der Tabelle: Schranke fuer das relative Residuum, Rechenart, Nachiterationen."""
    residuum: float
    rechenart: str  # "float32" wirkt erst mit Plan 2; bis dahin rechnet der Kern in double
    nachiterationen: int


# Die Tabelle. `rechenart` "float32" wirkt erst mit Plan 2; bis dahin rechnet der Kern in
# double und der Nachweis nennt "double" als tatsaechliche Rechenart.
STUFEN = {
    "streng": Stufe(1e-8, "double", 3),
    "normal": Stufe(1e-6, "float32", 6),
    "fein": Stufe(1e-5, "float32", 6),
    "locker": Stufe(1e-4, "float32", 4),
    "sehr locker": Stufe(1e-3, "float32", 3),
}


@dataclass(frozen=True)
class Vorgabe:
    """Was der Loeser fuer diesen Lauf einhalten soll."""
    stufe: str
    residuum: float
    rechenart: str
    nachiterationen: int
    rueckfall: str
    sigma_bezug: float | None = None

    @property
    def ziel_n_mm2(self) -> float | None:
        """Die Zusage in Spannungseinheiten, wenn der Massstab bekannt ist."""
        return None if self.sigma_bezug is None else self.residuum * self.sigma_bezug


def aufloesen(stufe: str | None = None, ziel_n_mm2: float | None = None,
              sigma_bezug: float | None = None, residuum: float | None = None,
              rechenart: str | None = None, nachiterationen: int | None = None,
              rueckfall: str = "genauer") -> Vorgabe:
    """Stufe und Uebersteuerungen zu einer `Vorgabe` aufloesen.

    Ohne Angabe gilt "normal". `ziel_n_mm2` braucht `sigma_bezug` (der Loeser kennt keine
    Knotenflaechen und raet keine). Ausdruecklich gesetzte Werte gehen der Stufe vor.
    """
    if rueckfall not in RUECKFALL:
        raise ValueError(f"Rueckfall '{rueckfall}' unbekannt - moeglich: {', '.join(RUECKFALL)}")
    if stufe is not None and ziel_n_mm2 is not None:
        raise ValueError("stufe und ziel_n_mm2 zusammen sind mehrdeutig - gib eines von beiden an")
    if ziel_n_mm2 is not None:
        if sigma_bezug is None or sigma_bezug <= 0.0:
            raise ValueError("ziel_n_mm2 braucht sigma_bezug > 0 (Spannungsmassstab der Loesung) - "
                             "ohne ihn kann der Loeser N/mm^2 nicht in ein Residuum umrechnen")
        grund = Stufe(float(ziel_n_mm2) / float(sigma_bezug), "float32", 6)
        name = "ziel"
    else:
        name = stufe or "normal"
        if name not in STUFEN:
            raise ValueError(f"Stufe '{name}' unbekannt - moeglich: {', '.join(STUFEN)}")
        grund = STUFEN[name]
    v = Vorgabe(stufe=name, residuum=grund.residuum, rechenart=grund.rechenart,
                nachiterationen=grund.nachiterationen, rueckfall=rueckfall, sigma_bezug=sigma_bezug)
    if residuum is not None:
        v = replace(v, residuum=float(residuum))
    if rechenart is not None:
        if rechenart not in RECHENARTEN:
            raise ValueError(f"Rechenart '{rechenart}' unbekannt - moeglich: {', '.join(RECHENARTEN)}")
        v = replace(v, rechenart=str(rechenart))
    if nachiterationen is not None:
        v = replace(v, nachiterationen=int(nachiterationen))
    return v


@dataclass(frozen=True)
class Nachweis:
    """Was dieser Lauf tatsaechlich erreicht hat."""
    stufe: str
    ziel: float
    erreicht: float
    rechenart: str
    nachiterationen: int
    gehalten: bool
    rueckfall: str | None = None
    ziel_n_mm2: float | None = None
    erreicht_n_mm2: float | None = None

    def als_dict(self) -> dict:
        return asdict(self)


def bewerte(vorgabe: Vorgabe, residuum: float, rechenart: str, nachiterationen: int,
            rueckfall: str | None = None) -> Nachweis:
    """Aus Vorgabe und gemessenem Residuum den Nachweis bilden."""
    erreicht = float(residuum)
    sb = vorgabe.sigma_bezug
    return Nachweis(stufe=vorgabe.stufe, ziel=vorgabe.residuum, erreicht=erreicht,
                    rechenart=str(rechenart), nachiterationen=int(nachiterationen),
                    gehalten=erreicht <= vorgabe.residuum, rueckfall=rueckfall,
                    ziel_n_mm2=vorgabe.ziel_n_mm2,
                    erreicht_n_mm2=None if sb is None else erreicht * sb)


def zeile(nachweis: Nachweis) -> str:
    """Eine Zeile fuer das Protokoll - immer dieselbe Form, damit man sie vergleichen kann.

    Das Format ist Vertrag: Tests pruefen genau diesen Wortlaut, also nicht versehentlich
    aendern. Ziel und erreicht werden mit derselben Nachkommastellenzahl gedruckt - sonst
    sehen zwei verschiedene Zahlen an der Schranke wie dieselbe aus.
    """
    n = nachweis
    text = (f"Genauigkeit: Stufe {n.stufe}, Ziel {n.ziel:.2e}, erreicht {n.erreicht:.2e}"
            f" ({'gehalten' if n.gehalten else 'NICHT gehalten'})")
    if n.ziel_n_mm2 is not None:
        text += f"; in Spannung: Ziel {n.ziel_n_mm2:.3g} N/mm^2, erreicht {n.erreicht_n_mm2:.3g} N/mm^2"
    text += f"; {n.rechenart}, {n.nachiterationen} Nachiterationen"
    if n.rueckfall:
        text += f"; Rueckfall {n.rueckfall}"
    return text
