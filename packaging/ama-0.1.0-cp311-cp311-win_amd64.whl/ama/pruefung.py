"""Pruefwerte eines Ergebnisses - bei jedem Lauf, damit 'genau' belegt ist:
Residuum K u = f - B^T lam je Koerper (bei schwebenden Koerpern zugleich das
Gleichgewicht), Durchdringung, Komplementaritaet lam * Spalt, Verletzung der
Gleichheitszeilen; mit Reibung Kegel, Haftverschiebung und Gleitrichtung."""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp


def pruefe(koerper, offsets, B, ungleich, g, f, lam, u, reib=None) -> dict:
    bl = B.T @ lam if len(lam) else np.zeros_like(f)
    w = f - bl
    # Bezug je Koerper: die Kraefte, die an ihm angreifen (Last und Bedingungskraefte),
    # mindestens 1e-6 der groessten im System. Das Netto w_b taugt nicht: ein Anker
    # traegt 1e5 N durch, sein Netto ist die Setzung mal EA/L; ein unbelasteter
    # Koerper (w_b = 0, u_b = Rundung) waere ein Residuum von 1e289
    skala = max(float(np.linalg.norm(f)), float(np.linalg.norm(bl)), 1e-300)
    residuen = []
    for i, kb in enumerate(koerper):
        a, b = offsets[i], offsets[i + 1]
        if b == a:
            residuen.append(0.0)
            continue
        Kv = kb.K + sp.tril(kb.K, -1).T
        bezug = max(np.linalg.norm(f[a:b]), np.linalg.norm(bl[a:b]), 1e-6 * skala)
        residuen.append(float(np.linalg.norm(Kv @ u[a:b] - w[a:b]) / bezug))
    aus = {"residuum": max(residuen) if residuen else 0.0, "residuum_je_koerper": residuen,
           "durchdringung": 0.0, "lam_min": 0.0, "komplementaritaet": 0.0, "gleichheit": 0.0}
    if len(lam) == 0:
        return aus
    spalt = g - B @ u
    ung = np.asarray(ungleich, bool)
    if ung.any():
        aus["durchdringung"] = float(max(0.0, -spalt[ung].min()))
        aus["lam_min"] = float(lam[ung].min())
        # normiert auf Kraft- mal Verschiebungsmassstab; max|Spalt| taugt nicht, wenn alle
        # Paare geschlossen sind (dann ist er Rundungsrauschen)
        skala = float(np.abs(lam[ung]).max() * max(np.abs(u).max(), 1e-300))
        aus["komplementaritaet"] = float(np.abs(lam[ung] * spalt[ung]).max() / max(skala, 1e-300))
    tang = np.zeros(len(lam), bool)
    if reib is not None and reib.k:
        tang[reib.t.ravel()] = True
    gl = ~ung & ~tang
    if gl.any():
        aus["gleichheit"] = float(np.abs(spalt[gl]).max())
    # Reibung (Stufe 3): Kegel ||lam_t|| <= mu lam_n, Haften w = 0, Gleiten laengs der Kraft
    aus.update({"kegel": 0.0, "haften": 0.0, "gleiten": 0.0})
    if reib is not None and reib.k:
        w = -spalt[reib.t]                                    # w = B_t u (g = 0)
        lt = lam[reib.t]                                      # (k, 2)
        ln = lam[reib.n]
        psi = reib.mu * np.maximum(ln, 0.0)
        norm_t = np.linalg.norm(lt, axis=1)
        skala_l = max(float(np.abs(lam).max()), 1e-300)
        skala_u = max(float(np.abs(u).max()), 1e-300)
        aus["kegel"] = float(np.maximum(norm_t - psi, 0.0).max() / skala_l)
        haft = norm_t < psi * (1.0 - 1e-9)
        if haft.any():
            aus["haften"] = float(np.linalg.norm(w[haft], axis=1).max() / skala_u)
        gleit = ~haft & (psi > 0.0)
        if gleit.any():
            s_ = lt[gleit] / np.maximum(norm_t[gleit], 1e-300)[:, None]
            aus["gleiten"] = float(np.maximum(-(w[gleit] * s_).sum(axis=1), 0.0).max() / skala_u)
    return aus
