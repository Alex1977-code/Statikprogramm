"""Ein Koerper: Knoten, Elementsteifigkeiten (oder eine fertige Steifigkeit),
beidseitige Lager, Nullraum, Faktorisierung.

Beidseitig gehaltene FHG werden eliminiert (Index -1 in der Assemblierung).
Der Nullraum der freien Steifigkeit - die Starrkoerpermoden, die kein Lager
sperrt - wird aus der Geometrie gebildet, auf die freien FHG eingeschraenkt
und ueber die Energie R^T K R geprueft: nur Moden ohne Energie bleiben.
Die Faktorisierung wird ueber Fixierknoten regularisiert (Brzobohaty, Dostal,
Kozubek, Kovar, Markopoulos, IJNME 2011): S = K + rho * R~ R~^T auf den FHG
weniger, weit auseinander liegender Knoten. S^-1 ist eine verallgemeinerte
Inverse von K (K S^-1 K = K), weil Bild(K) und Bild(R~ R~^T) sich nur in 0
schneiden - Herleitung in docs/kontakt.md.
"""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp

from . import ama_kern, kern


class Koerper:
    def __init__(self, index: int, knoten, fhg_je_knoten: int = 3, name: str = ""):
        self.index = int(index)
        self.name = name or f"Koerper {index}"
        self.knoten = np.asarray(knoten, float).reshape(-1, 3)
        self.nk = len(self.knoten)
        self.fj = int(fhg_je_knoten)
        self.n = self.nk * self.fj
        self._bloecke: list = []
        self._K_voll = None
        self.fest = np.zeros(self.n, bool)
        self.abgeschlossen = False

    # ---- Aufbau ------------------------------------------------------------
    def fhg(self, knoten, richtung: int) -> np.ndarray:
        """Lokale FHG-Nummern der Knoten in einer Richtung (0..fj-1)."""
        return self.fj * np.asarray(knoten, np.int64) + int(richtung)

    def elemente(self, art: str, knoten, K) -> None:
        """Elementbloecke: knoten (n_el, nk_e), K (n_el, ne, ne) mit ne = nk_e * fj."""
        knoten = np.asarray(knoten, np.int64)
        K = np.asarray(K, float)
        n_el, nk_e = knoten.shape
        ne = nk_e * self.fj
        if K.shape != (n_el, ne, ne):
            raise ValueError(f"{art}: Bloecke {K.shape}, erwartet ({n_el}, {ne}, {ne})")
        idx = (self.fj * knoten[:, :, None] + np.arange(self.fj)[None, None, :]).reshape(n_el, ne)
        self._bloecke.append((ne, idx, K))

    def steifigkeit(self, K) -> None:
        """Fertige Steifigkeit (n x n, lokale volle Nummerierung, symmetrisch)."""
        K = sp.csc_matrix(K)
        if K.shape != (self.n, self.n):
            raise ValueError(f"Steifigkeit {K.shape}, erwartet ({self.n}, {self.n})")
        self._K_voll = K

    def lager(self, knoten, richtungen=(0, 1, 2)) -> None:
        """Beidseitig gehaltene FHG (Wert 0)."""
        for r in richtungen:
            self.fest[self.fhg(knoten, r)] = True

    # ---- Abschluss ---------------------------------------------------------
    def abschliessen(self, threads: int = 0) -> None:
        self.frei = np.flatnonzero(~self.fest)
        self.nf = len(self.frei)
        self.lokal_zu_frei = -np.ones(self.n, np.int64)
        self.lokal_zu_frei[self.frei] = np.arange(self.nf)
        K = sp.csc_matrix((self.nf, self.nf))
        for ne, idx, bl in self._bloecke:
            indptr, indices, data = ama_kern.assembliere(
                self.nf, ne, np.ascontiguousarray(self.lokal_zu_frei[idx].ravel()),
                np.ascontiguousarray(bl.ravel()))
            K = K + sp.csc_matrix((data, indices, indptr), shape=(self.nf, self.nf))
        if self._K_voll is not None:
            K = K + self._K_voll[self.frei][:, self.frei]
        self.K = kern.unteres_dreieck(K)
        self.R = self._nullraum()
        self.fixier = np.zeros(0, np.int64)
        S = self.K
        if self.R.shape[1] > 0:
            S = self._regularisiert()
        self.symbolik = kern.Symbolik(S)
        try:
            self.faktor = self.symbolik.faktorisiere(threads=threads)
        except RuntimeError as ex:
            # Pivotfehler des Kerns nennt den freien FHG; hier kommen Koerper, Knoten
            # und Richtung dazu - das ist die Meldung, die der Anwender braucht
            text = str(ex)
            import re
            m = re.search(r"Freiheitsgrad (\d+)", text)
            if m:
                fhg = self.frei[int(m.group(1))]
                text += (f" - {self.name}, Knoten {fhg // self.fj} ({self.knoten[fhg // self.fj]}), Richtung {fhg % self.fj}: "
                         f"kein Halt (Mechanismus oder Starrkoerpermode ohne Regularisierung)")
            raise RuntimeError(text) from None
        self.abgeschlossen = True

    def loese(self, b_frei) -> np.ndarray:
        """K^+ b auf den freien FHG (S^-1 b)."""
        return self.faktor.loese(np.asarray(b_frei, float))

    def voll(self, u_frei) -> np.ndarray:
        """Freie Werte in die volle lokale Nummerierung (gehaltene = 0)."""
        u = np.zeros(self.n)
        u[self.frei] = u_frei
        return u

    # ---- Nullraum ----------------------------------------------------------
    def _starrkoerpermoden(self) -> np.ndarray:
        """(n, 6): drei Verschiebungen, drei Verdrehungen um den Schwerpunkt."""
        alle = np.arange(self.nk)
        p = self.knoten - self.knoten.mean(axis=0)
        R = np.zeros((self.n, 6))
        for d in range(3):
            R[self.fhg(alle, d), d] = 1.0
        # u = w x p
        R[self.fhg(alle, 1), 3] = -p[:, 2]
        R[self.fhg(alle, 2), 3] = p[:, 1]
        R[self.fhg(alle, 0), 4] = p[:, 2]
        R[self.fhg(alle, 2), 4] = -p[:, 0]
        R[self.fhg(alle, 0), 5] = -p[:, 1]
        R[self.fhg(alle, 1), 5] = p[:, 0]
        if self.fj >= 6:
            for d in range(3):
                R[self.fhg(alle, 3 + d), 3 + d] = 1.0
        return R

    def _nullraum(self) -> np.ndarray:
        if self.nf == 0:
            return np.zeros((0, 0))
        Rall = self._starrkoerpermoden()[self.frei]
        U, s, _ = np.linalg.svd(Rall, full_matrices=False)
        Q = U[:, s > 1e-10 * s[0]]
        if Q.shape[1] == 0:
            return np.zeros((self.nf, 0))
        Kv = self.K + sp.tril(self.K, -1).T
        E = Q.T @ (Kv @ Q)
        w, V = np.linalg.eigh((E + E.T) / 2)
        skala = np.abs(Kv.diagonal()).mean()
        kernmoden = w <= 1e-8 * skala
        return Q @ V[:, kernmoden]

    # ---- Fixierknoten ------------------------------------------------------
    def _fixierknoten(self, mindestens: int = 4) -> np.ndarray:
        """Knoten mit lauter freien FHG, weit auseinander: erst der weiteste vom
        Schwerpunkt, dann der weiteste von ihm, dann der weiteste von der Geraden,
        dann der weiteste von der Ebene; weitere immer der weiteste vom Satz."""
        kand = np.flatnonzero(~self.fest.reshape(self.nk, self.fj).any(axis=1))
        if len(kand) == 0:
            kand = np.arange(self.nk)
        X = self.knoten[kand]
        gew = [int(np.argmax(np.linalg.norm(X - X.mean(axis=0), axis=1)))]
        gew.append(int(np.argmax(np.linalg.norm(X - X[gew[0]], axis=1))))
        a = X[gew[0]]
        t = X[gew[1]] - a
        if np.linalg.norm(t) > 0:
            t = t / np.linalg.norm(t)
            d = np.linalg.norm((X - a) - np.outer((X - a) @ t, t), axis=1)
            gew.append(int(np.argmax(d)))
            nrm = np.cross(t, X[gew[2]] - a)
            if np.linalg.norm(nrm) > 0:
                nrm = nrm / np.linalg.norm(nrm)
                gew.append(int(np.argmax(np.abs((X - a) @ nrm))))
        gew = list(dict.fromkeys(gew))
        while len(gew) < min(mindestens, len(kand)):
            abst = np.min(np.linalg.norm(X[:, None, :] - X[gew][None, :, :], axis=2), axis=1)
            gew.append(int(np.argmax(abst)))
        return kand[gew]

    def _regularisiert(self):
        r = self.R.shape[1]
        knoten = self._fixierknoten(4)
        for _ in range(12):
            fix = np.concatenate([self.lokal_zu_frei[self.fhg(knoten, d)] for d in range(self.fj)])
            fix = np.unique(fix[fix >= 0])
            Rt = self.R[fix]
            sig = np.linalg.svd(Rt, compute_uv=False)
            if len(sig) == r and sig[-1] > 1e-6 * sig[0]:
                break
            knoten = self._fixierknoten(len(knoten) + 1)
        else:
            raise RuntimeError(f"{self.name}: Fixierknoten spannen den Nullraum nicht auf")
        self.fixier = fix
        rho = np.abs(self.K.diagonal()).mean()
        M = rho * (Rt @ Rt.T)
        ii, jj = np.meshgrid(fix, fix, indexing="ij")
        return (self.K + sp.tril(self.K, -1).T
                + sp.coo_matrix((M.ravel(), (ii.ravel(), jj.ravel())), shape=(self.nf, self.nf))).tocsc()
