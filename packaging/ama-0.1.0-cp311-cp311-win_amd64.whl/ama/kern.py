"""Python-Seite des Kerns: scipy-Matrizen hinein, Faktor heraus.

Analyse (Ordnung, Symbolik) und Numerik sind getrennt: eine `Symbolik` wird
fuer jede Matrix mit demselben Muster wiederverwendet (Theorie II. Ordnung,
Eigenwerte mit Verschiebung). Das lineare System wird direkt und damit bis
auf Rundung exakt geloest.
"""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp

from . import ama_kern


def unteres_dreieck(K) -> sp.csc_matrix:
    """Unteres Dreieck als CSC mit sortierten Zeilen, ohne Duplikate und mit
    vollstaendiger Diagonale (auch Nullen) - die Eingabeform des Kerns."""
    K = sp.coo_matrix(K)
    if K.shape[0] != K.shape[1]:
        raise ValueError(f"Matrix ist nicht quadratisch: {K.shape}")
    n = K.shape[0]
    m = K.row >= K.col
    diag = np.arange(n)
    T = sp.coo_matrix(
        (np.concatenate([K.data[m], np.zeros(n)]),
         (np.concatenate([K.row[m], diag]), np.concatenate([K.col[m], diag]))),
        shape=(n, n),
    ).tocsc()
    T.sum_duplicates()
    T.sort_indices()
    return T


class Symbolik:
    """Ordnung und Struktur der Faktorisierung fuer ein Muster."""

    def __init__(self, K, relax_nullen: int = 8, relax_breite: int = 16):
        T = unteres_dreieck(K)
        self.muster = T
        self.n = T.shape[0]
        self._sym = ama_kern.analysiere(
            self.n,
            T.indptr.astype(np.int64),
            T.indices.astype(np.int64),
            np.ascontiguousarray(T.data, dtype=np.float64),
            relax_nullen,
            relax_breite,
        )

    nnz_l = property(lambda self: self._sym.nnz_l)
    nnz_l_gespeichert = property(lambda self: self._sym.nnz_l_gespeichert)
    flops = property(lambda self: self._sym.flops)
    anzahl_superknoten = property(lambda self: self._sym.anzahl_superknoten)

    def perm(self) -> np.ndarray:
        return self._sym.perm()

    def faktorisiere(self, K=None, pivot_rel: float = 1e-14, threads: int = 0,
                     stoerung_rel: float = 0.0, skalieren: bool = True, vorgabe=None) -> "Faktor":
        """Numerik auf diesem Muster; ohne K die Werte der Analyse.

        `skalieren`: symmetrisch mit D = diag(1/sqrt(|K_jj|)) vorskalieren (Jacobi). Damit ist
        jede Diagonale 1 und die Pivotschwelle misst ueberall dasselbe. Ohne sie traf die
        Schwelle bei Statik3Ds Straffedern (diag 1e8 bis 4e17) die falschen Zeilen: 50 statt 14
        Pivots galten als singulaer und die Loesung war um das 2,3-fache falsch, bei Residuum
        1e-14 (der Unterschied lag im Nullraum; gemessen 18.09.2026). Die Traegheit bleibt
        gleich (Sylvester), `pivot_min` bezieht sich auf die skalierte Matrix.

        `stoerung_rel > 0`: statische Pivotisierung - ein Pivot unter der Schwelle wird auf
        `stoerung_rel * max|diag|` gehoben statt die Faktorisierung abzubrechen (wie MKL
        PARDISO). `Faktor.gestoert` zaehlt sie; die Genauigkeit holt eine Nachiteration
        beim Aufrufer zurueck."""
        T = self.muster if K is None else unteres_dreieck(K)
        if K is not None and (T.shape != self.muster.shape
                              or not np.array_equal(T.indptr, self.muster.indptr)
                              or not np.array_equal(T.indices, self.muster.indices)):
            raise ValueError("Muster der neuen Matrix weicht von der Analyse ab - neue Symbolik noetig")
        skal = None
        data = T.data
        if skalieren:
            d = np.sqrt(np.abs(T.diagonal()))
            gross = float(d.max()) if self.n else 1.0
            d[d <= 1e-300 * max(gross, 1.0)] = 1.0          # leere Zeile: unskaliert lassen
            skal = 1.0 / d
            zeilen = T.indices
            spalten = np.repeat(np.arange(self.n), np.diff(T.indptr))
            data = T.data * skal[zeilen] * skal[spalten]
        f = self._sym.faktorisiere(np.ascontiguousarray(data, dtype=np.float64), pivot_rel, threads,
                                   64, stoerung_rel)
        voll = None
        if vorgabe is not None:
            # Fuer die Nachiteration wird die volle Matrix gebraucht, nicht nur ihr unteres Dreieck
            voll = (sp.csr_matrix(K) if K is not None
                    else (self.muster + sp.tril(self.muster, -1).T).tocsr())
            if K is not None:
                voll = (sp.tril(voll) + sp.tril(voll, -1).T).tocsr()
        fak = Faktor(self, f, skal, vorgabe=vorgabe, K=voll)
        # Die Matrix selbst gehoert nicht hier hinein: sie liegt als `voll` schon in `Faktor._K`
        # (fuer die Nachiteration). Der Rueckfall leitet sie im Bedarfsfall von dort ab.
        fak._argumente = {"pivot_rel": pivot_rel, "threads": threads,
                          "stoerung_rel": stoerung_rel, "skalieren": skalieren}
        return fak


class Faktor:
    """LDL^T-Faktor; `loese` nimmt einen Vektor oder eine Matrix rechter Seiten.

    Wurde symmetrisch skaliert (`skal`), rechnet `loese` die rechte Seite hinein und das
    Ergebnis wieder heraus - nach aussen loest der Faktor immer das urspruengliche System."""

    def __init__(self, symbolik: Symbolik, f, skal=None, vorgabe=None, K=None):
        self.symbolik = symbolik
        self._f = f
        self.n = symbolik.n
        self.skal = skal
        self.vorgabe = vorgabe
        self._K = K
        self._argumente = {}
        self._rueckfall_erlaubt = True    # eigenes Feld: von _argumente unabhaengig (siehe loese)
        self.nachweis = None    # nur der letzte `loese`-Aufruf; bei Wiederverwendung ueberschrieben

    traegheit = property(lambda self: self._f.traegheit)
    pivot_min = property(lambda self: self._f.pivot_min)
    gestoert = property(lambda self: self._f.gestoert)
    zeit_numerik = property(lambda self: self._f.zeit_numerik)
    threads = property(lambda self: self._f.threads)

    def d(self) -> np.ndarray:
        """D des urspruenglichen Systems in der Nummerierung von K: die Skalierung wird
        herausgerechnet (K = (S^-1 L S) (S^-2 D') (...)^T mit S = diag(skal))."""
        d = self._f.d()
        return d if self.skal is None else d / self.skal ** 2

    def _loese_einmal(self, b) -> np.ndarray:
        b = np.asarray(b, dtype=np.float64)
        einzeln = b.ndim == 1
        B = b.reshape(-1, 1) if einzeln else b
        if B.ndim != 2 or B.shape[0] != self.n:
            raise ValueError(f"rechte Seite hat Form {b.shape}, erwartet ({self.n},) oder ({self.n}, m)")
        m = B.shape[1]
        if self.skal is not None:
            B = B * self.skal[:, None]
        x = self._f.loese(np.asfortranarray(B).ravel(order="F"), m)
        X = x.reshape((self.n, m), order="F")
        if self.skal is not None:
            X = X * self.skal[:, None]
        return X[:, 0] if einzeln else X

    def loese(self, b) -> np.ndarray:
        """K^+ b. Mit Vorgabe wird nachiteriert, bis das relative Residuum die Schranke
        unterschreitet oder die Schritte aufgebraucht sind; `nachweis` nennt das Ergebnis
        dieses Aufrufs - bei Wiederverwendung des Faktors (mehrere `loese`) ueberschreibt
        jeder Aufruf den `nachweis` des vorigen.

        Bei mehreren rechten Seiten (Spalten) wird je Spalte gemessen und die schlechteste
        entscheidet ueber Abbruch und Nachweis: eine gemeinsame Norm ueber alle Spalten ist
        eine Mittelung und kann eine ungeloeste Spalte hinter einer grossen gut geloesten
        verstecken (gemessen: gemeinsam 1e-9 und 'gehalten', je Spalte 1e-15 bzw. 1.0 -
        ama/dicht.py loest in Bloecken von 64 rechten Seiten, dort waere das sonst wertlos)."""
        x = self._loese_einmal(b)
        if self.vorgabe is None or self._K is None:
            return x
        from . import genauigkeit as gen
        b = np.asarray(b, dtype=np.float64)
        einzeln = b.ndim == 1
        B = b.reshape(-1, 1) if einzeln else b
        bezug = np.maximum(np.linalg.norm(B, axis=0), 1e-300)

        def rest(x):
            X = x.reshape(-1, 1) if einzeln else x
            return float(np.max(np.linalg.norm(self._K @ X - B, axis=0) / bezug))

        r = rest(x)
        schritte = 0
        for schritte in range(1, self.vorgabe.nachiterationen + 1):
            if r <= self.vorgabe.residuum:
                schritte -= 1
                break
            xn = x + self._loese_einmal(b - self._K @ x)
            rn = rest(xn)
            if rn >= r:                        # keine Verbesserung mehr: Rundungsgrenze
                break
            x, r = xn, rn
        rueck = None
        if r > self.vorgabe.residuum and self.vorgabe.rueckfall == "genauer" and self._rueckfall_erlaubt:
            # Noch einmal mit mehr Schritten und angepasster Pivotschwelle. Mit Plan 2 ist das
            # der Wechsel von float32 auf double; bis dahin hilft nur die Schwelle. Kleinere
            # Schwelle laesst mehr Pivots unveraendert durch (weniger werden gestoert) -
            # gedeckelt auf np.finfo(float).eps (~2,22e-16, die Rundungsgrenze von double):
            # darunter ist ein Pivot nicht mehr von Rundungsrauschen zu unterscheiden, eine
            # noch kleinere Schwelle haette keine Wirkung mehr (bei pivot_rel 1e-14 waere
            # *1e-2 = 1e-16 sonst schon darunter und wirkungslos).
            arg = dict(self._argumente)
            arg["pivot_rel"] = max(arg["pivot_rel"] * 1e-2, np.finfo(float).eps)
            v2 = _replace_vorgabe(self.vorgabe, nachiterationen=2 * self.vorgabe.nachiterationen)
            zweit = self.symbolik.faktorisiere(self._K, vorgabe=v2, **arg)
            # Genau ein Rueckfallversuch: v2 behaelt rueckfall="genauer", also wuerde
            # zweit.loese ohne diese Sperre selbst wieder hierher kommen und bei dauerhaft
            # unerreichbarer Schranke unbegrenzt weiter rekursieren (test_rueckfall_rekursion_
            # ist_begrenzt haelt die Zahl der Faktorisierungen bei 2 fest).
            zweit._rueckfall_erlaubt = False
            x2 = zweit.loese(b)
            if zweit.nachweis.erreicht < r:
                x, r, schritte = x2, zweit.nachweis.erreicht, zweit.nachweis.nachiterationen
                rueck = "genauer"
            else:
                rueck = "genauer ohne Wirkung"
        elif r > self.vorgabe.residuum and self.vorgabe.rueckfall == "lockern":
            rueck = "lockern"
        self.nachweis = gen.bewerte(self.vorgabe, residuum=r, rechenart="double",
                                    nachiterationen=schritte, rueckfall=rueck)
        return x


def faktorisiere(K, pivot_rel: float = 1e-14, threads: int = 0, stoerung_rel: float = 0.0,
                 skalieren: bool = True, vorgabe=None, **symbolik_kw) -> Faktor:
    """Analyse und Numerik in einem Schritt."""
    return Symbolik(K, **symbolik_kw).faktorisiere(K, pivot_rel=pivot_rel, threads=threads,
                                                   stoerung_rel=stoerung_rel, skalieren=skalieren,
                                                   vorgabe=vorgabe)


def _replace_vorgabe(vorgabe, **aenderungen):
    """Eine Vorgabe mit geaenderten Feldern (die Vorgabe selbst ist unveraenderlich)."""
    from dataclasses import replace
    return replace(vorgabe, **aenderungen)
