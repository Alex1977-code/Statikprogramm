"""Bedingungen ueber die freien FHG aller Koerper: Zeilen B u <= g (ungleich),
B u = g (gleich) und Reibgruppen (Normalzeile + Tangentialpaar mit Reibbeiwert).
Eine Zeile ist eine Liste von Termen (koerper, lokaler_fhg, koeffizient). Gehaltene
FHG (u = 0) fallen beim Aufbau weg; Zeilen ohne verbleibende Terme werden entfernt
und gezaehlt."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import scipy.sparse as sp


@dataclass
class Reibung:
    """Reibgruppen (Coulomb): Normalzeile n (k,), Tangentialpaar t (k, 2), Reibbeiwert mu (k,) -
    Zeilenindizes in B nach dem Aufbau. Die Tangentialzeilen sind weder Schranke noch Gleichung,
    sondern Teil des Kreises ||lam_t|| <= mu * lam_n."""
    n: np.ndarray = field(default_factory=lambda: np.zeros(0, np.int64))
    t: np.ndarray = field(default_factory=lambda: np.zeros((0, 2), np.int64))
    mu: np.ndarray = field(default_factory=lambda: np.zeros(0))

    @property
    def k(self) -> int:
        return len(self.n)


class Bedingungen:
    def __init__(self):
        self.terme: list[list[tuple[int, int, float]]] = []
        self.ungleich: list[bool] = []
        self.g: list[float] = []
        self.marken: list[str] = []
        self.gruppen: list[tuple[int, int, int, float]] = []
        self.reib = Reibung()
        self.entfernt = 0

    @property
    def m(self) -> int:
        return len(self.g)

    def hinzu(self, terme, ungleich: bool, g: float, marke: str = "") -> int:
        self.terme.append([(int(k), int(f), float(c)) for k, f, c in terme])
        self.ungleich.append(bool(ungleich))
        self.g.append(float(g))
        self.marken.append(marke)
        return len(self.g) - 1

    def hinzu_reibung(self, terme_n, terme_t1, terme_t2, g: float, mu: float, haften: bool = False,
                      marke: str = "Reibung") -> int:
        """Normalzeile (einseitig, Spalt g) und Tangentialpaar w = (t1.u, t2.u). mu > 0: Coulomb-
        Gruppe; haften: Verbund in der Ebene, die Tangentialzeilen sind Gleichungen ohne Grenze."""
        i_n = self.hinzu(terme_n, True, g, marke)
        i_1 = self.hinzu(terme_t1, False, 0.0, marke + " t1")
        i_2 = self.hinzu(terme_t2, False, 0.0, marke + " t2")
        if not haften and mu > 0.0:
            self.gruppen.append((i_n, i_1, i_2, float(mu)))
        return i_n

    def aufbauen(self, koerper: list, offsets: np.ndarray):
        """B (csr, m x n_frei), ungleich (bool), g - nur Zeilen mit freien FHG."""
        zeilen, spalten, werte = [], [], []
        gueltig = []
        for i, terme in enumerate(self.terme):
            treffer = 0
            for k, f, c in terme:
                fi = koerper[k].lokal_zu_frei[f]
                if fi < 0:
                    continue
                zeilen.append(len(gueltig))
                spalten.append(offsets[k] + fi)
                werte.append(c)
                treffer += 1
            if treffer:
                gueltig.append(i)
        self.entfernt = self.m - len(gueltig)
        n = int(offsets[-1])
        B = sp.csr_matrix((werte, (zeilen, spalten)), shape=(len(gueltig), n))
        B.sum_duplicates()
        gueltig = np.array(gueltig, int)
        self.gueltig = gueltig
        # Reibgruppen auf die neuen Zeilennummern abbilden; Gruppen mit entfernter Zeile fallen weg
        neu = -np.ones(self.m, np.int64)
        neu[gueltig] = np.arange(len(gueltig))
        n_, t_, mu_ = [], [], []
        for i_n, i_1, i_2, mu in self.gruppen:
            if neu[i_n] >= 0 and neu[i_1] >= 0 and neu[i_2] >= 0:
                n_.append(neu[i_n])
                t_.append((neu[i_1], neu[i_2]))
                mu_.append(mu)
        self.reib = Reibung(np.array(n_, np.int64), np.array(t_, np.int64).reshape(-1, 2), np.array(mu_, float))
        return B, np.array(self.ungleich, bool)[gueltig], np.array(self.g, float)[gueltig]
