"""ama - Gleichungsloeser fuer Statik3D."""
from dataclasses import dataclass, field

import numpy as np

from . import ama_kern  # noqa: F401  (Rust-Kern)
from . import dicht, kontakt, pruefung
from .bedingungen import Bedingungen
from .koerper import Koerper

__version__ = ama_kern.version()


@dataclass
class Ergebnis:
    """Verschiebungen je Koerper (nk, fj) in voller lokaler Nummerierung, Kontaktkraefte
    lam (eine je Bedingungszeile), Aktivmenge, Spalt, Pruefwerte, Zaehler, Zustand.

    `genauigkeit` ist der Nachweis der Genauigkeitsstufe (`ama.genauigkeit.Nachweis` als dict):
    Stufe, Ziel, gemessenes `erreicht`, `gehalten` und gegebenenfalls `rueckfall`; mit
    `sigma_bezug` auch `ziel_n_mm2` und `erreicht_n_mm2`. Leer bedeutet nicht geprueft, nicht
    verfehlt - nur Wege, die eine Stufe kennen (`loesen_dicht`), fuellen das Feld."""
    u: list
    lam: np.ndarray
    aktiv: np.ndarray
    spalt: np.ndarray
    pruefung: dict
    iterationen: dict
    zeit: float
    zustand: dict
    genauigkeit: dict = field(default_factory=dict)
    protokoll: list = field(default_factory=list)


class System:
    """Baugruppe aus Koerpern mit Bedingungen (Kontakt, Kopplung, einseitige Lager)."""

    def __init__(self, threads=None):
        self.threads = ama_kern.threads_setzen(0 if threads is None else int(threads))
        self.koerper_liste: list[Koerper] = []
        self.bedingungen = Bedingungen()

    def koerper(self, knoten, fhg_je_knoten: int = 3, name: str = "") -> Koerper:
        k = Koerper(len(self.koerper_liste), knoten, fhg_je_knoten, name)
        self.koerper_liste.append(k)
        return k

    # ---- Bedingungen ---------------------------------------------------------
    def kontakt(self, paare, normalen, spalt, marke: str = "Kontakt") -> None:
        """Nichtdurchdringung n.(u_B - u_A) >= -spalt, als Zeile n.u_A - n.u_B <= spalt.
        paare (m, 4): (koerper_A, knoten_A, koerper_B, knoten_B); normalen (m, 3) von A
        nach B; spalt (m,) >= 0 Anfangsspalt, < 0 Uebermass."""
        paare = np.asarray(paare, np.int64).reshape(-1, 4)
        normalen = np.asarray(normalen, float).reshape(-1, 3)
        spalt = np.broadcast_to(np.asarray(spalt, float), (len(paare),))
        for (kA, nA, kB, nB), n, g in zip(paare, normalen, spalt):
            A, Bk = self.koerper_liste[kA], self.koerper_liste[kB]
            terme = [(kA, A.fhg(nA, d), n[d]) for d in range(3)] + [(kB, Bk.fhg(nB, d), -n[d]) for d in range(3)]
            self.bedingungen.hinzu(terme, True, g, marke)

    def einseitig(self, k: int, knoten, richtung, spalt=0.0, marke: str = "einseitiges Lager") -> None:
        """richtung.u <= spalt: der Knoten bewegt sich hoechstens um spalt in Richtung
        `richtung` (ein Lager, das nur drueckt)."""
        n = np.asarray(richtung, float)
        n = n / np.linalg.norm(n)
        kb = self.koerper_liste[k]
        for kn in np.atleast_1d(knoten):
            self.bedingungen.hinzu([(k, kb.fhg(kn, d), n[d]) for d in range(3)], True, float(spalt), marke)

    def reibung(self, paare, normalen, tangenten, mu, spalt=0.0, haften: bool = False,
                marke: str = "Reibung") -> None:
        """Kontakt mit Coulomb-Reibung: Normalzeile wie `kontakt`, dazu die Relativverschiebung
        w = t.(u_A - u_B) fuer die zwei Tangenten t (paare (m, 4), normalen (m, 3),
        tangenten (m, 2, 3), mu skalar oder (m,)). haften: Verbund in der Ebene ohne Grenze."""
        paare = np.asarray(paare, np.int64).reshape(-1, 4)
        normalen = np.asarray(normalen, float).reshape(-1, 3)
        tangenten = np.asarray(tangenten, float).reshape(-1, 2, 3)
        mu = np.broadcast_to(np.asarray(mu, float), (len(paare),))
        spalt = np.broadcast_to(np.asarray(spalt, float), (len(paare),))
        for (kA, nA, kB, nB), n, t, m_, g in zip(paare, normalen, tangenten, mu, spalt):
            A, Bk = self.koerper_liste[kA], self.koerper_liste[kB]

            def zeile(v):
                return [(kA, A.fhg(nA, d), v[d]) for d in range(3)] + [(kB, Bk.fhg(nB, d), -v[d]) for d in range(3)]

            self.bedingungen.hinzu_reibung(zeile(n), zeile(t[0]), zeile(t[1]), float(g), float(m_), haften, marke)

    def kopplung(self, kA: int, nA: int, kB: int, nB: int, richtungen=(0, 1, 2), marke: str = "Kopplung") -> None:
        """u_A[nA] = u_B[nB] in den Richtungen - starre Verbindung, exakt."""
        A, Bk = self.koerper_liste[kA], self.koerper_liste[kB]
        for d in richtungen:
            self.bedingungen.hinzu([(kA, A.fhg(nA, d), 1.0), (kB, Bk.fhg(nB, d), -1.0)], False, 0.0, marke)

    def bedingung(self, terme, ungleich: bool, g: float, marke: str = "") -> int:
        """Allgemeine Zeile: sum c * u[koerper, lokaler_fhg] <= g (ungleich) bzw. = g."""
        return self.bedingungen.hinzu(terme, ungleich, g, marke)

    # ---- Aufbau --------------------------------------------------------------
    def faktorisieren(self) -> None:
        for k in self.koerper_liste:
            k.abschliessen(self.threads)
        self.offsets = np.concatenate([[0], np.cumsum([k.nf for k in self.koerper_liste])]).astype(np.int64)
        self.B, self.ungleich, self.g = self.bedingungen.aufbauen(self.koerper_liste, self.offsets)
        self.reib = self.bedingungen.reib

    def lastvektor(self, lasten: dict) -> np.ndarray:
        """{koerper: F (n_lokal,)} -> f auf den freien FHG aller Koerper."""
        f = np.zeros(int(self.offsets[-1]))
        for k, Fk in lasten.items():
            kb = self.koerper_liste[int(k)]
            Fk = np.asarray(Fk, float).reshape(-1)
            if Fk.shape != (kb.n,):
                raise ValueError(f"{kb.name}: Last hat {Fk.shape}, erwartet ({kb.n},)")
            f[self.offsets[k]:self.offsets[k + 1]] = Fk[kb.frei]
        return f

    # ---- Loesen --------------------------------------------------------------
    def loesen(self, lasten: dict, warm: dict = None, tol: float = 1e-8, start: str = "gleichungen") -> Ergebnis:
        """Loest die Baugruppe fuer die Lasten {koerper: F (n_lokal,)}; `warm` ist
        `Ergebnis.zustand` eines vorigen Laufs.

        Dieser Weg kennt keine Genauigkeitsstufe, sondern allein `tol`; `Ergebnis.genauigkeit`
        bleibt deshalb leer - nicht geprueft, nicht verfehlt. Wer eine Zusage und ihren Nachweis
        braucht, nimmt `loesen_dicht`."""
        f = self.lastvektor(lasten)
        log: list = []
        erg = kontakt.loese_dual(self.koerper_liste, self.offsets, self.B, self.ungleich, self.g, f,
                                 tol=tol, warm=warm, start=start, protokoll=log)
        pr = pruefung.pruefe(self.koerper_liste, self.offsets, self.B, self.ungleich, self.g, f, erg["lam"], erg["u"])
        u = [kb.voll(erg["u"][self.offsets[i]:self.offsets[i + 1]]).reshape(kb.nk, kb.fj)
             for i, kb in enumerate(self.koerper_liste)]
        spalt = self.g - self.B @ erg["u"] if len(erg["lam"]) else np.zeros(0)
        aktiv = self.ungleich & (erg["lam"] > 0.0) if len(erg["lam"]) else np.zeros(0, bool)
        log.append(f"Pruefung: Residuum {pr['residuum']:.1e}, Durchdringung {pr['durchdringung']:.1e}, "
                   f"Komplementaritaet {pr['komplementaritaet']:.1e}, {int(aktiv.sum())} von {len(aktiv)} Bedingungen aktiv")
        return Ergebnis(u=u, lam=erg["lam"], aktiv=aktiv, spalt=spalt, pruefung=pr,
                        iterationen={"newton": erg["newton"], "aussen": erg["aussen"], "innen": erg["innen"],
                                     "anwendungen": erg["anwendungen"], "verfahren": erg["verfahren"]},
                        zeit=erg["zeit"], zustand=erg["zustand"], protokoll=log)

    def loesen_dicht(self, lasten: dict, Fd=None, stufe: str = None, ziel_n_mm2: float = None,
                     sigma_bezug: float = None, rueckfall: str = "genauer", **toleranzen) -> Ergebnis:
        """Dichter Weg (Stufe 3): F = B K+ B^T einmal je Modell (oder `Fd` uebergeben),
        Zustands-Newton mit Coulomb-Reibung und exakter Abschluss (`ama.dicht`).

        `stufe` waehlt die Genauigkeit (siehe `ama.genauigkeit.STUFEN`), `ziel_n_mm2` mit
        `sigma_bezug` gibt die Zusage direkt in Spannungseinheiten. `rueckfall` sagt, was
        geschieht, wenn die Zusage nicht erreicht wird. `Ergebnis.genauigkeit` nennt danach,
        was erreicht wurde; `zustand["reib"]` traegt Zustaende, Richtungen und psi.

        Von den technischen Uebersteuerungen der Stufe wirkt auf diesem Weg allein `residuum=`:
        es setzt die Abbruchschranke des Zustands-Newton und des Abschlusses. `nachiterationen=`
        bleibt hier ohne Wirkung - es steuert die Nachiteration des Kerns (`ama.kern.Faktor`),
        und die Faktorisierung je Koerper ist zum Zeitpunkt des Loesens laengst geschehen:
        `faktorisieren` ruft `Koerper.abschliessen` ohne Vorgabe auf. `rechenart=` wirkt noch
        nirgends; die Faktorisierung rechnet in double, und der Nachweis nennt "double" als
        tatsaechliche Rechenart (float32 kommt mit Plan 2). Beide werden trotzdem angenommen,
        damit dieselbe Vorgabe fuer Kern und Kontaktloeser taugt."""
        from . import genauigkeit as gen
        try:
            vorgabe = gen.aufloesen(stufe=stufe, ziel_n_mm2=ziel_n_mm2, sigma_bezug=sigma_bezug,
                                    rueckfall=rueckfall, **toleranzen)
        except TypeError as ex:
            # sonst nennt die Meldung `aufloesen`, eine Funktion, die der Aufrufer nicht kennt
            erlaubt = ("residuum", "rechenart", "nachiterationen")
            falsch = ", ".join(n for n in toleranzen if n not in erlaubt)
            if not falsch:
                raise                            # ein anderer TypeError - unveraendert weiter
            raise TypeError(f"loesen_dicht: Angabe '{falsch}' unbekannt - moeglich sind stufe, "
                            f"ziel_n_mm2, sigma_bezug, rueckfall und die Uebersteuerungen "
                            f"{', '.join(erlaubt)}") from ex
        log: list = []
        erg = dicht.loese_reibung_system(self, lasten, Fd=Fd, log=log.append, vorgabe=vorgabe)
        pr = erg["pruefung"]
        lam = erg["lam"]
        spalt = self.g - self.B @ erg["u_flach"] if len(lam) else np.zeros(0)
        aktiv = self.ungleich & (lam > 0.0) if len(lam) else np.zeros(0, bool)
        log.append(f"Pruefung: Residuum {pr['residuum']:.1e}, Durchdringung {pr['durchdringung']:.1e}, "
                   f"Komplementaritaet {pr['komplementaritaet']:.1e}, Kegel {pr['kegel']:.1e}, "
                   f"{int(aktiv.sum())} von {len(aktiv)} Bedingungen aktiv")
        return Ergebnis(u=erg["u"], lam=lam, aktiv=aktiv, spalt=spalt, pruefung=pr,
                        iterationen={"newton": erg["newton"], "runden": erg["runden"], "verfahren": "dicht"},
                        zeit=erg["zeit"], zustand={"reib": erg["reib"], "konvergiert": erg["konvergiert"]},
                        genauigkeit=erg["genauigkeit"], protokoll=log)
