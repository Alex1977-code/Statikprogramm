"""Dichte duale Stufe: die explizite Nachgiebigkeitsmatrix F = B K^+ B^T der Kontaktflaechen
(lastunabhaengig, einmal je Modell) und darauf exakte Loeser.

* `nachgiebigkeit`: F koerperweise mit Bloecken rechter Seiten (BLAS-3).
* `Sattel`: das Sattelpunktsystem [F_SS, -Gn_S^T; Gn_S, 0] einer Menge S geschlossener Zeilen -
  Cholesky von F_SS (Verschiebung eps*median(diag) fuer abhaengige Zeilen, Nachiteration gegen
  das unverschobene F_SS), Schur-System der Starrkoerpermoden mit Eigenzerlegung; Nullrichtungen
  sind Moden ohne Halt in S.
* `newton_dicht`: Aktivmengen-Newton (PDAS) mit exakten Schritten.
* `arbeitsmenge`: der exakte Abschluss. Die Zeilen, ueber die der Newton noch streitet, bilden
  die unsichere Menge U; die sicheren geschlossenen Zeilen S (und alle Gleichungen) werden
  eliminiert, uebrig bleibt ein kleines konvexes QP in lam_U >= 0 mit der Schur-Matrix
  S_U = F_UU - W^T K_SS^-1 W. Das loest der projizierte Newton (`qp_klein`, monoton im QP-Ziel,
  Warmstart) exakt, NNLS (Lawson-Hanson) ist der Rueckfall; danach wird die Loesung auf ganz F
  geprueft, Verletzungen (Zug in S, Durchdringung im Offenen) wandern nach U, bis keine bleibt.
  U waechst nur, das Verfahren endet also.
* `loese_dicht`: Startwert -> Newton bis wenige Wechsel -> Arbeitsmenge.
"""
from __future__ import annotations

import pathlib
import time
import warnings

import numpy as np
import scipy.sparse as sp
import scipy.linalg as sla
import scipy.optimize as sopt


def nachgiebigkeit(dual, block: int = 64, F=None, log=None):
    """F = B K^+ B^T (m x m) koerperweise mit Bloecken von `block` rechten Seiten; F darf ein
    memmap in Fortran-Ordnung sein (wird genullt und gefuellt)."""
    m = dual.m
    if F is None:
        F = np.zeros((m, m), order="F")
    else:
        F[:] = 0.0
    for i, kb in enumerate(dual.k):
        a, b = dual.off[i], dual.off[i + 1]
        if b == a:
            continue
        Bb = dual.B[:, a:b].tocsr()
        zeilen = np.unique(Bb.nonzero()[0])
        if len(zeilen) == 0:
            continue
        Bb_z = Bb[zeilen]
        t1 = time.perf_counter()
        for j0 in range(0, len(zeilen), block):
            blk = zeilen[j0:j0 + block]
            E = np.asarray(Bb[blk].T.todense(), order="F")           # (nf_b x nb)
            X = kb.loese(E)                                           # K^+ B^T e_blk
            F[np.ix_(zeilen, blk)] += Bb_z @ X                        # nur Zeilen dieses Koerpers
        if log is not None:
            log(f"  {kb.name}: {kb.nf} FHG, {len(zeilen)} Zeilen, {time.perf_counter() - t1:.1f} s")
    return F


def _2d(v):
    v = np.asarray(v, float)
    return (v[:, None], True) if v.ndim == 1 else (v, False)


class Sattel:
    """[F_SS, -Gn_S^T; Gn_S, 0] auf der Zeilenmenge idx (sortiert)."""

    def __init__(self, Fd, dual, idx):
        self.idx = np.asarray(idx, np.int64)
        n = len(self.idx)
        self.rn = dual.rn
        self.FSS = np.array(Fd[np.ix_(self.idx, self.idx)], order="F") if n else np.zeros((0, 0))
        self.eps = 0.0
        self.cho = None
        skala = float(np.median(np.diag(self.FSS))) if n else 1.0
        for eps in (1e-12, 1e-10, 1e-8, 1e-6):
            try:
                A = self.FSS + (eps * skala) * np.eye(n)
                self.cho = sla.cho_factor(A, lower=True, overwrite_a=True, check_finite=False)
                self.eps = eps
                break
            except np.linalg.LinAlgError:
                pass
        if self.cho is None and n:
            raise RuntimeError("F_SS auch mit Verschiebung nicht positiv definit")
        if self.rn:
            self.GnS = (dual.T.T @ dual.G[:, self.idx].toarray()) if n else np.zeros((self.rn, 0))
            self.Y = self._chol(self.GnS.T)                              # F_SS^-1 Gn_S^T
            S = self.GnS @ self.Y
            w, V = np.linalg.eigh((S + S.T) / 2)
            self.w, self.V = w, V
            # Schwelle absolut zur Groesse einer ganz gehaltenen Mode: die Zeilen von Gn sind
            # orthonormiert (|Zeile|^2 = 1), also w ~ 1/F-Skala. Nur relativ zum groessten
            # Eigenwert wuerden bei lauter Moden ohne Halt (S = eine Kopplungszeile innerhalb
            # eines Koerpers, Gn_S ~ 1e-16) Rundungseigenwerte ~1e-31 als Halt gelten und 1/w
            # die Reduktion sprengen (gemessen 17.09.2026: F_red mit Eigenwerten 1e31)
            self.ok = w > 1e-12 * max(float(w.max()), 1.0 / max(skala, 1e-300))
            self.nullv = V[:, ~self.ok]                                   # Moden ohne Halt in S
        else:
            self.GnS = np.zeros((0, n))
            self.nullv = np.zeros((0, 0))

    @property
    def vollrangig(self) -> bool:
        return self.nullv.shape[1] == 0

    def unzulaessig(self, en) -> bool:
        """Eine Mode ohne Halt in S traegt Last: das QP auf S hat keine Loesung."""
        if self.vollrangig:
            return False
        return bool(np.abs(self.nullv.T @ en).max() > 1e-10 * max(np.linalg.norm(en), 1e-300))

    def _chol(self, r):
        if len(self.idx) == 0:
            return np.zeros_like(r)
        return sla.cho_solve(self.cho, r, check_finite=False)

    def _schritt(self, r1, r2):
        x = self._chol(r1)
        if not self.rn:
            return x, np.zeros((0, r1.shape[1]))
        Vo = self.V[:, self.ok]
        da = Vo @ ((Vo.T @ (r2 - self.GnS @ x)) / self.w[self.ok][:, None])
        return x + self.Y @ da, da

    def loese(self, r1, r2, nachiteration: int = 2):
        """(lam_S, alpha) mit F_SS lam_S - Gn_S^T alpha = r1 und Gn_S lam_S = r2; r1 (n,) oder
        (n, k), r2 (rn,) oder (rn, k). Nachiteration gegen das unverschobene F_SS."""
        r1, eins = _2d(r1)
        r2 = _2d(r2)[0] if self.rn else np.zeros((0, r1.shape[1]))
        x, a = self._schritt(r1, r2)
        # Nachiteration: alle Schritte laufen (an der Rundungsgrenze von r1 schwankt das Residuum,
        # waehrend r2 noch von 8e-16 auf 5e-22 faellt - eine Abbruchregel "nur solange r1 faellt"
        # liess den psi-Fixpunkt bei 2e-10 pendeln, gemessen 17.09.2026); nur wenn das relative
        # Residuum beider Gleichungen um mehr als das Zehnfache waechst (inkonsistente Zeilen:
        # der Nullraumanteil wuechse je Schritt um c/eps), bleibt der beste Iterierte
        s1 = max(float(np.linalg.norm(r1)), 1e-300)
        s2 = max(float(np.linalg.norm(r2)), 1e-300) if self.rn else 1.0

        def residuum(x_, a_):
            e1 = np.linalg.norm(r1 - self.FSS @ x_ + self.GnS.T @ a_) / s1
            e2 = (np.linalg.norm(r2 - self.GnS @ x_) / s2) if self.rn else 0.0
            return max(e1, e2)

        res = residuum(x, a)
        best = (x, a, res)
        for _ in range(nachiteration):
            dx, da = self._schritt(r1 - self.FSS @ x + self.GnS.T @ a, r2 - self.GnS @ x)
            xn, an = x + dx, a + da
            res = residuum(xn, an)
            if res > 10.0 * best[2]:
                x, a = best[0], best[1]
                break
            x, a = xn, an
            if res < best[2]:
                best = (x, a, res)
        return (x[:, 0], a[:, 0]) if eins else (x, a)


def loesung_dicht(Fd, dual, C, nachiteration: int = 2, lam_bekannt=None, bekannt=None):
    """Exakte Loesung des gleichungsbeschraenkten QP auf C (Spalt = 0 auf C, lam = 0 sonst).
    Zeilen `bekannt` tragen die vorgegebene Kraft lam_bekannt (Gleitkraefte mu lam_n s) und
    wandern auf die rechte Seite. Liefert lam (m), alpha (rn), unzulaessig, Sattel."""
    idx = np.flatnonzero(C)
    lam = np.zeros(dual.m)
    rhs1 = dual.d
    rhs2 = dual.en
    if bekannt is not None and np.any(bekannt):
        idk = np.flatnonzero(bekannt)
        lam[idk] = np.asarray(lam_bekannt, float)[idk]
        rhs1 = rhs1 - Fd[:, idk] @ lam[idk]
        if dual.rn:
            rhs2 = rhs2 - dual.T.T @ (dual.G[:, idk] @ lam[idk])
    sattel = Sattel(Fd, dual, idx)
    if len(idx) == 0:
        return lam, np.zeros(dual.rn), sattel.unzulaessig(rhs2), sattel
    lamC, alpha = sattel.loese(rhs1[idx], rhs2, nachiteration)
    lam[idx] = lamC
    return lam, alpha, sattel.unzulaessig(rhs2), sattel


def spalt_von(Fd, dual, lam, alpha):
    return Fd @ lam - dual.d - (dual.Gnt(alpha) if dual.rn else 0.0)


def merit_von(dual, lam, spalt) -> float:
    phi = np.where(dual.ungleich, np.minimum(lam, spalt), spalt)
    return float(np.linalg.norm(phi))


def newton_dicht(Fd, dual, lam0, max_it: int = 30, schwelle: float = 0.0, gedaechtnis: int = 3,
                 tol: float = 1e-12, log=print):
    """Aktivmengen-Newton mit exakten Schritten (ungedaempft). Konvergiert bei 0 Wechseln oder
    wenn der Merit ||min(lam, Spalt)|| unter tol * max(||d||, ||lam||) liegt (schwach aktive
    Zeilen mit lam = Spalt = 0 wechseln sonst endlos bei Rundungsrauschen). Bricht ab, wenn die
    Wechsel unter `schwelle` (Anteil der Zeilen) fallen. Liefert lam, alpha, C, Schritte,
    konvergiert, und die Zeilen, die in den letzten `gedaechtnis` Schritten gewechselt haben."""
    ungleich = dual.ungleich
    gleich = dual.gleich
    lam = lam0.copy()
    lam[ungleich] = np.maximum(lam[ungleich], 0.0)
    C = gleich | (lam > 0.0)
    t0 = time.perf_counter()
    alpha = np.zeros(dual.rn)
    geaendert = []
    it = 0
    for it in range(1, max_it + 1):
        t1 = time.perf_counter()
        lam_n, alpha_n, unzul, sattel = loesung_dicht(Fd, dual, C)
        t_loes = time.perf_counter() - t1
        if unzul:
            sp_ = spalt_von(Fd, dual, lam_n, alpha_n)
            offen = np.flatnonzero(ungleich & ~C)
            kand = offen[np.argsort(sp_[offen])[:max(6, len(offen) // 100)]]
            C = C.copy()
            C[kand] = True
            log(f"Newton {it}: Koerpermode ohne Halt - {len(kand)} Zeilen aufgenommen")
            continue
        lam, alpha = lam_n, alpha_n
        sp_ = spalt_von(Fd, dual, lam, alpha)
        C_neu = gleich | (ungleich & ((lam - sp_) > 0.0))
        wechsel = C_neu != C
        geaendert.append(wechsel)
        offen = ungleich & ~C
        durchdringung = float(max(0.0, -sp_[offen].min())) if offen.any() else 0.0
        neg = float(min(0.0, lam[ungleich & C].min())) if (ungleich & C).any() else 0.0
        mer = merit_von(dual, lam, sp_)
        log(f"Newton {it}: {int((C & ungleich).sum())} geschlossen, {int(wechsel.sum())} Wechsel, "
            f"Merit {mer:.2e}, Durchdringung {durchdringung:.2e}, min lam {neg:.2e}, "
            f"eps {sattel.eps:g}, Loesung {t_loes:.1f} s, {time.perf_counter() - t0:.0f} s")
        if not wechsel.any() or mer <= tol * max(np.linalg.norm(dual.d), np.linalg.norm(lam)):
            return lam, alpha, C, it, True, np.zeros(dual.m, bool)
        if wechsel.sum() <= schwelle * dual.m:
            break
        C = C_neu
    letzte = np.zeros(dual.m, bool)
    for w in geaendert[-gedaechtnis:]:
        letzte |= w
    return lam, alpha, C, it, False, letzte


def nnls_qp(S, c, A_eq=None, b_eq=None, max_iter=None):
    """min 1/2 lam^T S lam - c^T lam, lam >= 0, S symmetrisch positiv semidefinit: als NNLS
    ||R lam - b|| mit S = R^T R (Cholesky mit kleinster noetiger Verschiebung). Gleichungen
    A_eq lam = b_eq (Moden ohne Halt in S) als stark gewichtete Zeilen; die Werte poliert
    danach die exakte Loesung auf der gefundenen Aktivmenge."""
    n = len(c)
    if n == 0:
        return np.zeros(0)
    skala = max(float(np.median(np.diag(S))), 1e-300)
    R = None
    for eps in (1e-13, 1e-11, 1e-9, 1e-7):
        try:
            R = np.linalg.cholesky(S + (eps * skala) * np.eye(n)).T          # S = R^T R
            break
        except np.linalg.LinAlgError:
            pass
    if R is None:
        raise RuntimeError("Schur-Matrix der Arbeitsmenge nicht positiv semidefinit")
    b = sla.solve_triangular(R, c, trans="T", check_finite=False)              # R^T b = c
    if A_eq is not None and len(A_eq):
        gew = np.sqrt(1e8 * float(np.abs(np.diag(S)).max()) / max(float((A_eq ** 2).sum(axis=1).max()), 1e-300))
        R = np.vstack([R, gew * A_eq])
        b = np.concatenate([b, gew * b_eq])
    lam, _ = sopt.nnls(R, b, maxiter=max_iter or 50 * n)
    return lam


def qp_klein(S, c, lam0=None, tol: float = 1e-10, max_it: int = 200):
    """min q(lam) = 1/2 lam^T S lam - c^T lam, lam >= 0, S dicht positiv semidefinit:
    projizierter Newton (Bertsekas) - freie Menge {lam > 0 oder Gradient < 0}, Newton-Schritt
    auf ihr, Armijo-Abstieg von q entlang der Projektion. q faellt monoton, deshalb keine
    Zyklen; Warmstart mit lam0. Liefert lam und ob die KKT-Bedingungen erreicht sind."""
    n = len(c)
    if n == 0:
        return np.zeros(0), True, 0
    lam = np.zeros(n) if lam0 is None else np.maximum(np.asarray(lam0, float), 0.0)
    skala = max(float(np.abs(np.diag(S)).max()), 1e-300)
    normc = max(float(np.linalg.norm(c)), 1e-300)

    def q(x):
        return 0.5 * float(x @ (S @ x)) - float(c @ x)

    g = S @ lam - c
    qk = q(lam)
    it = 0
    for it in range(1, max_it + 1):
        frei = (lam > 0.0) | (g < 0.0)
        # KKT: Gradient null auf der freien Menge, nicht negativ auf der gebundenen
        if np.linalg.norm(g[frei]) <= tol * normc and (g[~frei] >= -tol * normc).all():
            return lam, True, it
        idx = np.flatnonzero(frei)
        d = np.zeros(n)
        SFF = S[np.ix_(idx, idx)]
        try:
            cho = sla.cho_factor(SFF + (1e-14 * skala) * np.eye(len(idx)), lower=True, check_finite=False)
            d[idx] = -sla.cho_solve(cho, g[idx], check_finite=False)
        except np.linalg.LinAlgError:
            d[idx] = -sla.lstsq(SFF, g[idx], cond=1e-13, lapack_driver="gelsd", check_finite=False)[0]
        if float(g @ d) >= 0.0:                          # kein Abstieg (Rundung): projizierter Gradient
            d = -g
            d[~frei] = 0.0
        t = 1.0
        angenommen = False
        for _ in range(40):
            lam_t = np.maximum(lam + t * d, 0.0)
            q_t = q(lam_t)
            if q_t <= qk + 1e-4 * float(g @ (lam_t - lam)):
                angenommen = True
                break
            t *= 0.5
        if not angenommen:
            return lam, False, it
        lam, qk = lam_t, q_t
        g = S @ lam - c
    return lam, False, it


def qp_aktiv(S, c, lam0=None, A_eq=None, b_eq=None, tol: float = 1e-12, max_it: int = 3000):
    """Exaktes primales Aktivmengenverfahren fuer min 1/2 lam^T S lam - c^T lam, lam >= 0,
    A_eq lam = b_eq (Moden ohne Halt in S, exakt im KKT-System der freien Flaeche - keine
    Strafe): Minimierer auf der freien Flaeche, Ratio-Test statt Abschneiden - der Schritt endet
    an der ersten Schranke, die Zeile wird gebunden; am Flaechenminimum werden alle gebundenen
    Zeilen mit negativem reduziertem Gradienten frei. q faellt streng monoton, keine Flaeche
    wiederholt sich: endlich. Steife Richtungen (S_U mit Eintraegen bis 1e11) bleiben im
    Gleichungssystem. Liefert lam, konvergiert, Schritte."""
    n = len(c)
    if n == 0:
        return np.zeros(0), True, 0
    k = 0 if A_eq is None else len(A_eq)
    lam = np.zeros(n) if lam0 is None else np.maximum(np.asarray(lam0, float), 0.0)
    frei = lam > 0.0
    if k and not frei.any():
        frei[:] = True
    normc = max(float(np.linalg.norm(c)), 1e-300)
    skala = max(float(np.abs(np.diag(S)).max()), 1e-300)
    mu = np.zeros(k)
    it = 0

    def q(x):
        return 0.5 * float(x @ (S @ x)) - float(c @ x)

    q_alt = q(lam)
    stillstand = 0
    for it in range(1, max_it + 1):
        # Endlichkeit lebt vom strengen Abstieg von q; auf entarteten Flaechen (singulaeres S_FF)
        # faellt q numerisch nicht mehr - dann abbrechen, NNLS uebernimmt
        if it % 10 == 0:
            q_neu = q(lam)
            if q_neu >= q_alt - 1e-14 * abs(q_alt):
                stillstand += 1
                if stillstand >= 3:
                    return lam, False, it
            else:
                stillstand = 0
            q_alt = q_neu
        idx = np.flatnonzero(frei)
        if len(idx):
            SFF = S[np.ix_(idx, idx)]
            if k:
                AF = A_eq[:, idx]
                K = np.block([[SFF + (1e-14 * skala) * np.eye(len(idx)), AF.T], [AF, np.zeros((k, k))]])
                rhs = np.concatenate([c[idx], b_eq])
                import warnings
                with warnings.catch_warnings():
                    warnings.simplefilter("error", sla.LinAlgWarning)
                    try:
                        xm = sla.solve(K, rhs, assume_a="sym", check_finite=False)
                    except (np.linalg.LinAlgError, ValueError, sla.LinAlgWarning):
                        xm = sla.lstsq(K, rhs, cond=1e-13, lapack_driver="gelsd", check_finite=False)[0]
                x, mu = xm[:len(idx)], xm[len(idx):]           # S x + A^T mu = c
            else:
                try:
                    cho = sla.cho_factor(SFF + (1e-14 * skala) * np.eye(len(idx)), lower=True, check_finite=False)
                    x = sla.cho_solve(cho, c[idx], check_finite=False)
                except np.linalg.LinAlgError:
                    x = sla.lstsq(SFF, c[idx], cond=1e-13, lapack_driver="gelsd", check_finite=False)[0]
            d = x - lam[idx]
            neg = d < 0.0
            t = 1.0
            if neg.any():
                t = min(1.0, float(np.min(lam[idx][neg] / -d[neg])))
            if t < 1.0:
                lam_neu = lam[idx] + t * d
                # alle Zeilen, die (bis auf Rundung) die Schranke erreichen, werden gebunden
                blockiert = neg & (lam_neu <= 1e-12 * max(float(lam_neu.max()), 1e-300))
                lam_neu[blockiert] = 0.0
                lam[idx] = lam_neu
                frei[idx[blockiert]] = False
                continue
            lam[idx] = np.maximum(x, 0.0)
        g = S @ lam - c
        if k:
            g = g + A_eq.T @ mu                            # reduzierter Gradient
        kandidaten = ~frei & (g < -tol * normc)
        if not kandidaten.any():
            return lam, True, it
        frei |= kandidaten
    return lam, False, it


def qp_u(S, c, lam0=None, A_eq=None, b_eq=None, log=None, ablage=None):
    """QP der Arbeitsmenge: projizierter Newton mit Warmstart, Aktivmenge mit Ratio-Test als
    Rueckfall, NNLS als letzter. Gleichungen (Moden ohne Halt in S) loest die Aktivmenge exakt im
    KKT-System; NNLS bekaeme sie als starke Strafe. `ablage`: Pfad, unter dem S, c, lam0
    abgelegt werden (Messungen am echten Problem)."""
    if ablage is not None:
        np.savez(ablage, S=S, c=c, lam0=np.zeros(len(c)) if lam0 is None else lam0)
    mit_gl = A_eq is not None and len(A_eq) > 0
    t0 = time.perf_counter()
    if mit_gl:
        # Strafform nur als Warmstart fuer die exakte Aktivmenge
        w = 1e8 * float(np.abs(np.diag(S)).max()) / max(float((A_eq ** 2).sum(axis=1).max()), 1e-300)
        lam, ok, it = qp_klein(S + w * (A_eq.T @ A_eq), c + w * (A_eq.T @ b_eq), lam0, max_it=60)
        ok = False
    else:
        lam, ok, it = qp_klein(S, c, lam0, max_it=60)
    if log is not None:
        log(f"  projizierter Newton: {it} Schritte, {'konvergiert' if ok else 'NICHT konvergiert'}, "
            f"{int((lam > 0).sum())} von {len(c)} geschlossen, {time.perf_counter() - t0:.1f} s")
    if ok:
        return lam
    t0 = time.perf_counter()
    lam2, ok2, it2 = qp_aktiv(S, c, lam, A_eq if mit_gl else None, b_eq if mit_gl else None)
    if log is not None:
        log(f"  Aktivmenge mit Ratio-Test: {it2} Schritte, {'konvergiert' if ok2 else 'NICHT konvergiert'}, "
            f"{int((lam2 > 0).sum())} von {len(c)} geschlossen, {time.perf_counter() - t0:.1f} s")
    if ok2:
        return lam2
    if mit_gl:
        w = 1e8 * float(np.abs(np.diag(S)).max()) / max(float((A_eq ** 2).sum(axis=1).max()), 1e-300)
        return nnls_qp(S + w * (A_eq.T @ A_eq), c + w * (A_eq.T @ b_eq))
    return nnls_qp(S, c)


def zeilen_koerper(dual):
    """Je Zeile die (bis zu zwei) Koerper, die sie beruehrt: (m, 2), -1 = keiner."""
    B = dual.B.tocsr()
    kol = np.searchsorted(dual.off, B.indices, side="right") - 1
    zk = np.full((dual.m, 2), -1, np.int64)
    voll = np.diff(B.indptr) > 0
    start = B.indptr[:-1][voll]
    zk[voll, 0] = np.minimum.reduceat(kol, start)
    zk[voll, 1] = np.maximum.reduceat(kol, start)
    return zk


def _median_je_koerper(werte, zk, maske, n_koerper):
    """Median der Werte der maskierten Zeilen je Koerper (Zeile zaehlt fuer beide Koerper)."""
    med = np.full(n_koerper, np.nan)
    idx = np.flatnonzero(maske)
    if len(idx) == 0:
        return med
    k = np.concatenate([zk[idx, 0], zk[idx, 1]])
    w = np.concatenate([werte[idx], werte[idx]])
    gut = k >= 0
    k, w = k[gut], w[gut]
    o = np.argsort(k, kind="stable")
    k, w = k[o], w[o]
    grenzen = np.flatnonzero(np.diff(k)) + 1
    for kk, teil in zip(np.concatenate([[k[0]], k[grenzen]]) if len(k) else [], np.split(w, grenzen)):
        med[kk] = np.median(teil)
    return med


def unsicher(dual, lam, spalt, S, U, band: float = 0.1, zk=None):
    """Zeilen mit kleiner Reserve, je Koerper normiert: geschlossene mit lam unter `band` mal dem
    Median der geschlossenen Zeilen ihres Koerpers, offene mit Spalt unter `band` mal dem Median
    der offenen ihres Koerpers. Ein globaler Massstab taugt nicht: kleinen, schwach belasteten
    Koerpern naehme er alle Haltezeilen weg, S hielte sie kaum noch und die reduzierte
    Nachgiebigkeit spraenge auf 1e11 (gemessen 17.09.2026)."""
    ungleich = dual.ungleich
    zu = S & ungleich
    offen = ~S & ~U & ungleich
    if zk is None:
        zk = zeilen_koerper(dual)
    nk = len(dual.k)
    aus = np.zeros(dual.m, bool)

    def schwelle(werte, maske):
        med = _median_je_koerper(werte, zk, maske, nk)
        m0 = np.where(zk[:, 0] >= 0, med[np.maximum(zk[:, 0], 0)], np.nan)
        m1 = np.where(zk[:, 1] >= 0, med[np.maximum(zk[:, 1], 0)], np.nan)
        return band * np.fmin(m0, m1)                    # kleinerer Koerpermassstab zaehlt

    if zu.any():
        aus |= zu & (lam < np.nan_to_num(schwelle(lam, zu), nan=-np.inf))
    if offen.any():
        aus |= offen & (spalt < np.nan_to_num(schwelle(spalt, offen), nan=-np.inf))
    return aus


def arbeitsmenge(Fd, dual, C, U, lam0=None, alpha0=None, max_runden: int = 40, tol: float = 1e-9,
                 band: float = 0.1, fuge_min: int = 20, fuge_max: int = 1500, log=print, ablage=None):
    """Exakter Abschluss: sichere geschlossene Zeilen S = C ohne U (und alle Gleichungen) eliminiert,
    QP auf U mit NNLS (Moden ohne Halt in S als Gleichungen auf lam_U), Werte exakt auf der
    gefundenen Menge, Verletzungen ausserhalb U nach U, bis keine bleibt.
    Liefert lam, alpha, Runden, konvergiert."""
    ungleich = dual.ungleich
    gleich = dual.gleich
    U = np.asarray(U, bool) & ungleich
    S = (np.asarray(C, bool) | gleich) & ~U
    t0 = time.perf_counter()
    lam = np.zeros(dual.m) if lam0 is None else np.asarray(lam0, float).copy()
    alpha = np.zeros(dual.rn)
    zk = zeilen_koerper(dual)
    klebrig = np.zeros(dual.m, bool)                 # einmal verletzte Zeilen verlassen U nicht mehr
    if lam0 is not None and alpha0 is not None and band > 0:
        # Zeilen mit kleiner Reserve von vornherein nach U: die Verletzungen kaemen sonst
        # Runde fuer Runde schichtweise (gemessen 17.09.2026: 14 Runden, U 1.030 -> 5.030)
        sp0 = spalt_von(Fd, dual, lam, np.asarray(alpha0, float))
        zusatz = unsicher(dual, lam, sp0, S, U, band, zk)
        U |= zusatz
        S &= ~U
        log(f"Arbeitsmenge: {int(zusatz.sum())} Zeilen mit kleiner Reserve dazu, |U| {int(U.sum())}")
    for runde in range(1, max_runden + 1):
        t1 = time.perf_counter()
        idxS = np.flatnonzero(S)
        idxU = np.flatnonzero(U)
        sattel = Sattel(Fd, dual, idxS)
        p1, p2 = sattel.loese(dual.d[idxS], dual.en)
        t_sattel = time.perf_counter() - t1
        t_nnls = 0.0
        if len(idxU):
            W1 = np.array(Fd[np.ix_(idxS, idxU)], order="F")                   # (|S| x |U|)
            W2 = dual.T.T @ dual.G[:, idxU].toarray() if dual.rn else np.zeros((0, len(idxU)))
            Qx, Qa = sattel.loese(W1, W2, nachiteration=0)      # O(eps) = 1e-12 reicht fuer die Reduktion
            SU = np.array(Fd[np.ix_(idxU, idxU)]) - W1.T @ Qx + W2.T @ Qa
            SU = (SU + SU.T) / 2
            cU = dual.d[idxU] - W1.T @ p1 + W2.T @ p2
            t_red = time.perf_counter() - t1 - t_sattel
            t2 = time.perf_counter()
            if sattel.vollrangig:
                lamU = qp_u(SU, cU, lam[idxU], log=log, ablage=ablage if runde == 1 else None)
                t_nnls = time.perf_counter() - t2
                A = lamU > 0.0
                if A.any():                                    # exakt auf der NNLS-Menge
                    lamU = _poliert(SU, cU, lamU, A)
                lamS = p1 - Qx @ lamU
                alpha = p2 - Qa @ lamU
                lam = np.zeros(dual.m)
                lam[idxS] = lamS
                lam[idxU] = lamU
                eps = sattel.eps
            else:
                # Moden ohne Halt in S: ihr Gleichgewicht ist eine Gleichung auf lam_U
                N = sattel.nullv
                lamU = qp_u(SU, cU, lam[idxU], N.T @ W2, N.T @ dual.en, log=log, ablage=ablage if runde == 1 else None)
                t_nnls = time.perf_counter() - t2
                A = lamU > 0.0
                Cn = S.copy()
                Cn[idxU[A]] = True
                lam, alpha, unzul, sattel_c = loesung_dicht(Fd, dual, Cn)
                eps = sattel_c.eps
                if unzul:
                    log(f"Arbeitsmenge {runde}: Mode ohne Halt auch nach NNLS - NNLS-Werte behalten")
                    lam = np.zeros(dual.m)
                    lam[idxS] = p1 - Qx @ lamU
                    lam[idxU] = lamU
                    alpha = p2 - Qa @ lamU
        else:
            lam = np.zeros(dual.m)
            lam[idxS] = p1
            alpha = p2
            eps = sattel.eps
            t_red = 0.0
        sp_ = spalt_von(Fd, dual, lam, alpha)
        skala_l = max(float(np.abs(lam).max()), 1e-300)
        skala_g = max(float(np.abs(sp_).max()), 1e-300)
        zug = S & ungleich & (lam < -tol * skala_l)
        offen = ~S & ~U & ungleich
        durch = offen & (sp_ < -tol * skala_g)
        innen_zug = U & (lam < -tol * skala_l)
        innen_durch = U & (lam <= 0.0) & (sp_ < -tol * skala_g)
        log(f"Arbeitsmenge {runde}: |S| {len(idxS)}, |U| {len(idxU)}, davon {int((lam[idxU] > 0).sum())} geschlossen; "
            f"Zug in S {int(zug.sum())}, Durchdringung offen {int(durch.sum())}, in U {int(innen_zug.sum())}/{int(innen_durch.sum())}, "
            f"Merit {merit_von(dual, lam, sp_):.2e}, eps {eps:g}, Sattel {t_sattel:.1f} s, Reduktion {t_red:.1f} s, "
            f"NNLS {t_nnls:.1f} s, Runde {time.perf_counter() - t1:.1f} s, {time.perf_counter() - t0:.0f} s")
        if not zug.any() and not durch.any() and not innen_zug.any() and not innen_durch.any():
            return lam, alpha, runde, True
        # Welche Koerper streiten: die drei mit den meisten verletzten Zeilen
        verl = np.flatnonzero(zug | durch)
        kz = np.concatenate([zk[verl, 0], zk[verl, 1]])
        kz = kz[kz >= 0]
        if len(kz):
            werte, anzahl = np.unique(kz, return_counts=True)
            o = np.argsort(-anzahl)[:3]
            log("  streitende Koerper: " + ", ".join(f"{dual.k[int(werte[i])].name} ({int(anzahl[i])})" for i in o))
        # Beides aufnehmen: nur Zugzeilen aus S zu nehmen laesst Koerper kippen (gemessen
        # 17.09.2026: 19 Zugzeilen weg -> 2.135 Durchdringungen in der naechsten Runde).
        # Klar entschiedene Zeilen verlassen U wieder (lam bzw. Spalt ueber dem Band ihres
        # Koerpers): sonst waechst U auf 5.000, S verliert Haltezeilen, S_U wird schlecht
        # konditioniert und der projizierte Newton steht (gemessen 17.09.2026, Runde 8)
        if band > 0:
            entschieden = U & ~unsicher(dual, lam, sp_, U & (lam > 0.0), np.zeros(dual.m, bool), band, zk)                 & ~unsicher(dual, lam, sp_, np.zeros(dual.m, bool), np.zeros(dual.m, bool), band, zk)
            # geschlossen mit grossem lam -> S, offen mit grossem Spalt -> O
            entschieden &= ~klebrig
            zu_s = entschieden & (lam > 0.0)
            zu_o = entschieden & (lam <= 0.0)
            U = U & ~entschieden
            S = S | zu_s
            if zu_s.any() or zu_o.any():
                log(f"  {int(zu_s.sum())} Zeilen aus U nach S, {int(zu_o.sum())} nach offen")
        # Streitet eine Fuge (Koerperpaar) mit vielen Zeilen, kommt sie ganz nach U: die
        # Kontaktgrenze auf einer ebenen Fuge wandert sonst je Runde nur eine Schicht weit
        # (gemessen 17.09.2026, Fuge 48/92: 98 -> 438 Durchdringungen, Runde fuer Runde)
        neu_ = zug | durch
        if fuge_min > 0:
            paar = zk[:, 0] * (len(dual.k) + 1) + zk[:, 1]
            pv, nv = np.unique(paar[neu_], return_counts=True)
            for pp, nn in zip(pv, nv):
                ganze = (paar == pp) & ungleich
                if nn >= fuge_min and ganze.sum() <= fuge_max:
                    log(f"  Fuge {dual.k[int(pp // (len(dual.k) + 1))].name} / "
                        f"{dual.k[int(pp % (len(dual.k) + 1))].name}: {int(nn)} Verletzungen, "
                        f"alle {int(ganze.sum())} Zeilen nach U")
                    neu_ |= ganze
        klebrig |= neu_
        U = U | neu_
        S = S & ~U
    return lam, alpha, max_runden, False


def _poliert(S, c, lam, A):
    """Werte auf der Aktivmenge A exakt nachrechnen (Minimum-Norm-Kleinste-Quadrate, auch fuer
    singulaeres oder inkonsistentes S_AA); angenommen nur, wenn lam_A >= 0 bleibt und das
    Residuum S lam - c auf A nicht waechst - sonst bleiben die NNLS-Werte."""
    SAA = S[np.ix_(A, A)]
    cA = c[A]
    lamA = sla.lstsq(SAA, cA, cond=1e-13, lapack_driver="gelsd", check_finite=False)[0]
    if lamA.min() < 0.0:
        return lam
    if np.linalg.norm(SAA @ lamA - cA) > np.linalg.norm(SAA @ lam[A] - cA):
        return lam
    aus = np.zeros(len(lam))
    aus[A] = lamA
    return aus


def loese_dicht(Fd, dual, lam0=None, max_newton: int = 30, schwelle: float = 0.01,
                max_runden: int = 40, band: float = 0.1, fuge_min: int = 20, fuge_max: int = 1500,
                log=print, ablage=None) -> dict:
    """Startwert (alle Zeilen als Gleichungen, Zug weggeschnitten) -> Newton, bis die Wechsel
    unter `schwelle` * m liegen -> Arbeitsmenge (exakt). lam physikalisch (skal * lam)."""
    t0 = time.perf_counter()
    if lam0 is None:
        lam0, _, _, _ = loesung_dicht(Fd, dual, np.ones(dual.m, bool))
        lam0[dual.ungleich] = np.maximum(lam0[dual.ungleich], 0.0)
        log(f"Startwert: {int((lam0 > 0).sum())} von {dual.m} aktiv ({time.perf_counter() - t0:.0f} s)")
    lam, alpha, C, newton, ok, letzte = newton_dicht(Fd, dual, lam0, max_it=max_newton,
                                                     schwelle=schwelle, log=log)
    runden = 0
    if not ok:
        sp_ = spalt_von(Fd, dual, lam, alpha)
        U = letzte | (C & dual.ungleich & (lam < 0.0)) | (~C & dual.ungleich & (sp_ < 0.0))
        lam, alpha, runden, ok = arbeitsmenge(Fd, dual, C, U, lam0=lam, alpha0=alpha, max_runden=max_runden,
                                              band=band, fuge_min=fuge_min, fuge_max=fuge_max,
                                              log=log, ablage=ablage)
    alpha_r = dual.T @ alpha if dual.rn else np.zeros(dual.r)
    u = dual.verschiebung(lam, alpha_r)
    return {"lam": dual.skal * lam, "lam_skal": lam, "alpha": alpha_r, "u": u, "newton": newton,
            "runden": runden, "konvergiert": ok, "zeit": time.perf_counter() - t0}


# ---- Stufe 3: Coulomb-Reibung ---------------------------------------------------------------
OFFEN, HAFTEN, GLEITEN = 0, 1, 2
ABLAGE_QP = None            # Pfad: reduziertes QP der Arbeitsmenge ablegen (Messungen)
# Boden fuer die psi-Konsistenz gleitender Gruppen: der psi-Fixpunkt kommt nicht tiefer
# (gemessen 18.09.2026: bei 8e-9 blieben 120-430 Gruppen stehen), darunter misst man sein
# Rauschen. Die Schranke der Vorgabe geht darueber hinaus mit, siehe `arbeitsmenge_reibung`.
PSI_BODEN = 1e-7


def _reib_mengen(dual, zustand, s, psi, C_sonst):
    """Gleichungsmenge C und bekannte Kraefte der gleitenden Gruppen (Spec 5): geschlossene
    Normalzeilen und haftende Tangentialzeilen sind Gleichungen, gleitende Gruppen tragen
    lam_t = psi * s auf der rechten Seite."""
    r = dual.reib
    C = C_sonst.copy()
    bekannt = np.zeros(dual.m, bool)
    lam_b = np.zeros(dual.m)
    if r.k:
        zu = zustand != OFFEN
        C[r.n[zu]] = True
        C[r.n[~zu]] = False
        C[r.t[zustand == HAFTEN].ravel()] = True
        C[r.t[zustand != HAFTEN].ravel()] = False
        gl = zustand == GLEITEN
        if gl.any():
            bekannt[r.t[gl].ravel()] = True
            lam_b[r.t[gl, 0]] = psi[gl] * s[gl, 0]
            lam_b[r.t[gl, 1]] = psi[gl] * s[gl, 1]
    return C, bekannt, lam_b


def newton_reibung(Fd, dual, lam0, max_it: int = 40, anteil: float = 0.1, sperre: int = 2,
                   tol: float = 1e-9, log=print, alpha0=None):
    """Zustands-Newton (Spec 5): je Reibknoten offen / haften / gleiten mit Richtung s; ein Schritt
    = exaktes Sattelsystem mit den Gleitkraeften psi * s (psi = mu lam_n des vorigen Schritts) auf
    der rechten Seite; Zustandsupdate nach Coulomb. Je Schritt geht hoechstens der Anteil `anteil`
    der haftenden Knoten ins Gleiten (staerkster Verstoss zuerst), Richtungen bleiben `sperre`
    Schritte fest. Liefert lam, alpha, zustand (k,), s (k, 2), psi (k,), C, Schritte, konvergiert."""
    r = dual.reib
    k = r.k
    ungleich_sonst = dual.ungleich.copy()
    if k:
        ungleich_sonst[r.n] = False                   # Normalzeilen der Gruppen laufen ueber den Zustand
    gleich = dual.gleich
    lam = lam0.copy()
    lam[dual.ungleich] = np.maximum(lam[dual.ungleich], 0.0)
    zustand = np.where(lam[r.n] > 0.0, HAFTEN, OFFEN).astype(int) if k else np.zeros(0, int)
    s = np.zeros((k, 2))
    psi = r.mu * np.maximum(lam[r.n], 0.0) if k else np.zeros(0)
    frist = np.zeros(k, int)
    C_sonst = gleich | (ungleich_sonst & (lam > 0.0))
    alpha = np.zeros(dual.rn) if alpha0 is None else np.asarray(alpha0, float).copy()
    C = C_sonst
    t0 = time.perf_counter()
    it = 0
    for it in range(1, max_it + 1):
        t1 = time.perf_counter()
        C, bekannt, lam_b = _reib_mengen(dual, zustand, s, psi, C_sonst)
        lam_n, alpha_n, unzul, sattel = loesung_dicht(Fd, dual, C, lam_bekannt=lam_b, bekannt=bekannt)
        if unzul:
            sp_ = spalt_von(Fd, dual, lam_n, alpha_n)
            offen = np.flatnonzero(ungleich_sonst & ~C)
            kand = offen[np.argsort(sp_[offen])[:max(6, len(offen) // 100)]]
            C_sonst = C_sonst.copy()
            C_sonst[kand] = True
            zu_neu = (zustand == OFFEN) & (sp_[r.n] < 0.0) if k else np.zeros(0, bool)
            zustand[zu_neu] = HAFTEN
            log(f"Reibung {it}: Koerpermode ohne Halt - {len(kand)} Zeilen und {int(zu_neu.sum())} Knoten aufgenommen")
            continue
        lam, alpha = lam_n, alpha_n
        sp_ = spalt_von(Fd, dual, lam, alpha)
        # gewoehnliche Zeilen: PDAS-Regel
        C_neu = gleich | (ungleich_sonst & ((lam - sp_) > 0.0))
        wechsel = int((C_neu != C_sonst)[ungleich_sonst].sum())
        C_sonst = C_neu
        # Reibknoten
        neu = zustand.copy()
        wechsel_r = 0
        d_psi = 0.0
        if k:
            ln = lam[r.n]
            lt = lam[r.t]                                       # (k, 2)
            w = -sp_[r.t]                                       # Relativverschiebung (g = 0)
            gn = sp_[r.n]
            psi_neu = r.mu * np.maximum(ln, 0.0)
            # offen -> haften bei Durchdringung; geschlossen -> offen bei Zug
            neu[(zustand == OFFEN) & (gn < 0.0)] = HAFTEN
            neu[(zustand != OFFEN) & (ln < 0.0)] = OFFEN
            # haften -> gleiten: staerkste Verstoesse zuerst, hoechstens `anteil` der haftenden
            haft = np.flatnonzero((zustand == HAFTEN) & (neu == HAFTEN))
            if len(haft):
                nt = np.linalg.norm(lt[haft], axis=1)
                verstoss = nt / np.maximum(psi_neu[haft], 1e-300)
                ueber = verstoss > 1.0 + tol
                if ueber.any():
                    nmax = max(1, int(np.ceil(anteil * len(haft))))
                    reihe = np.argsort(-verstoss)
                    kand = haft[reihe[ueber[reihe]][:nmax]]
                    neu[kand] = GLEITEN
                    s[kand] = lt[kand] / np.maximum(np.linalg.norm(lt[kand], axis=1), 1e-300)[:, None]
                    frist[kand] = sperre
            # gleiten: Richtung nachfuehren oder zurueck nach haften
            gl = np.flatnonzero((zustand == GLEITEN) & (neu == HAFTEN * 0 + GLEITEN))
            if len(gl):
                ws = (w[gl] * s[gl]).sum(axis=1)
                # Hysterese: zurueck nach haften nur bei merklicher Bewegung gegen die Kraft;
                # Gleiten ohne Bewegung (w ~ 0 am Kegelrand) ist ein gueltiger Zustand
                tol_w = tol * max(float(np.abs(w).max()), 1e-300)
                neu[gl[ws < -tol_w]] = HAFTEN
                frei = gl[(ws > tol_w) & (frist[gl] == 0)]
                nw = np.linalg.norm(w[frei], axis=1)
                ok_w = nw > 0.0
                s[frei[ok_w]] = w[frei[ok_w]] / nw[ok_w][:, None]
            frist = np.maximum(frist - 1, 0)
            wechsel_r = int((neu != zustand).sum())
            d_psi = float(np.abs(psi_neu - psi).max() / max(float(psi_neu.max()), 1e-300))
            zustand, psi = neu, psi_neu
        log(f"Reibung {it}: {int((zustand == HAFTEN).sum())} haften, {int((zustand == GLEITEN).sum())} gleiten, "
            f"{int((zustand == OFFEN).sum())} offen; Wechsel {wechsel_r} + {wechsel} sonst, dpsi {d_psi:.1e}, "
            f"eps {sattel.eps:g}, {time.perf_counter() - t1:.1f} s, {time.perf_counter() - t0:.0f} s")
        if wechsel_r == 0 and wechsel == 0 and d_psi <= tol:
            return lam, alpha, zustand, s, psi, C, it, True
    return lam, alpha, zustand, s, psi, C, it, False


def projektion_kegel(x, schranke, gruppen, psi):
    """Zeilenweise Projektion: Schranken x >= 0, Kreise ||x[g]|| <= psi_g (radial)."""
    y = np.asarray(x, float).copy()
    y[schranke] = np.maximum(y[schranke], 0.0)
    if len(gruppen):
        v = y[gruppen]
        nv = np.linalg.norm(v, axis=1)
        f = np.where(nv > psi, psi / np.maximum(nv, 1e-300), 1.0)
        y[gruppen] = v * f[:, None]
    return y


def qp_kegel(S, c, lam0, schranke, gruppen, psi, tol: float = 1e-10, max_it: int = 500, tol_skala=None,
             A=None, b=None, alpha0=None, log=None, log_alle: int = 1, mu=None, n_pos=None):
    """Loest in skalierten Variablen x = a y (a = Kreisradius bzw. |c|/|S|): in den winzigen
    dualen Einheiten kleiner Aufgaben (q ~ 1e-12, Fortschritt ~ 1e-27) blieb die Armijo-Suche
    sonst an der Rundungsgrenze stehen (gemessen 17.09.2026: 500 Schritte bis 1e-9, skaliert
    5 Schritte bis 1e-13). Mit A, b: Modengleichung A x = b (Moden ohne Halt in S), alpha als
    Unbekannte im Sattel-Newton der Flaeche. Mit mu, n_pos: Coulomb-Radius psi = mu max(x_n, 0)
    statt festem psi (Tresca). Liefert x, ok, Schritte (ohne A) bzw. x, alpha, ok, Schritte (mit A)."""
    coulomb = mu is not None
    psi = np.zeros(len(gruppen)) if coulomb else np.asarray(psi, float)
    a = max(float(psi.max()) if len(psi) else 0.0,
            float(np.abs(c).max()) / max(float(np.abs(S).max()), 1e-300),
            float(np.abs(lam0).max()) if (coulomb and lam0 is not None) else 0.0, 1e-300)
    x0 = None if lam0 is None else np.asarray(lam0, float) / a
    ts = None if tol_skala is None else tol_skala / a
    mu_ = None if not coulomb else np.asarray(mu, float)
    if A is None or len(A) == 0:
        y, ok, it = _qp_kegel_roh(S, c / a, x0, schranke, gruppen, psi / a, tol=tol, max_it=max_it, tol_skala=ts,
                                  log=log, log_alle=log_alle, mu=mu_, n_pos=n_pos)
        return a * y, ok, it
    al0 = None if alpha0 is None else np.asarray(alpha0, float) / a
    y, al, ok, it = _qp_kegel_roh(S, c / a, x0, schranke, gruppen, psi / a, tol=tol, max_it=max_it, tol_skala=ts,
                                  A=A, b=np.asarray(b, float) / a, alpha0=al0, log=log, log_alle=log_alle,
                                  mu=mu_, n_pos=n_pos)
    return a * y, a * al, ok, it


def _qp_kegel_roh(S, c, lam0, schranke, gruppen, psi, tol: float = 1e-10, max_it: int = 500, tol_skala=None,
                  A=None, b=None, alpha0=None, log=None, log_alle: int = 1, mu=None, n_pos=None):
    """min 1/2 x^T S x - c^T x ueber Schranken (x >= 0) und Kreisen (||x[g]|| <= psi_g), mit
    Modengleichung A x = b (alpha als Multiplikator, Spalt g = S x - c - A^T alpha): semiglatter
    Newton auf Phi(x, alpha) = x - P_K(x - D g) = 0 und A x = b (D = 1/diag S, je Paar gleich, damit
    der Kreis ein Kreis bleibt). Verallgemeinerte Ableitung der Projektion: Schranke 1 (innen) /
    0 (an der Schranke), Kreis innen I, aussen psi/|v| (I - v v^T/|v|^2). Newton-System
    [(I - J) + J D S, -J D A^T; A, 0], Liniensuche auf |Phi|^2 + |r|^2, Rueckfall projizierter
    Gradientenschritt x <- P_K(v). Konvergenz am projizierten Gradienten |P_K(x - g) - x| wie
    bisher. Liefert x, [alpha,] konvergiert, Schritte."""
    n = len(c)
    mit_a = A is not None and len(A) > 0
    A = np.asarray(A, float) if mit_a else np.zeros((0, n))
    b = np.asarray(b, float) if mit_a else np.zeros(0)
    k = len(b)
    kg = len(gruppen)
    g0 = gruppen[:, 0] if kg else np.zeros(0, np.int64)
    g1 = gruppen[:, 1] if kg else np.zeros(0, np.int64)
    coulomb = mu is not None and kg > 0
    if coulomb:
        mu = np.asarray(mu, float)
        n_pos = np.asarray(n_pos, np.int64)

    def radius(x):
        return mu * np.maximum(x[n_pos], 0.0) if coulomb else psi

    psi = np.asarray(psi, float)
    x = np.zeros(n) if lam0 is None else np.asarray(lam0, float).copy()
    if coulomb:
        x[schranke] = np.maximum(x[schranke], 0.0)
    x = projektion_kegel(x, schranke, gruppen, radius(x))
    alpha = np.zeros(k) if (alpha0 is None or not mit_a) else np.asarray(alpha0, float).copy()
    normc = max(float(np.linalg.norm(c)) if tol_skala is None else float(tol_skala), 1e-300)
    dS = np.maximum(np.abs(np.diag(S)), 1e-300 * max(float(np.abs(S).max()), 1e-300))
    D = 1.0 / dS
    if kg:
        Dg = 2.0 / (dS[g0] + dS[g1])
        D[g0] = Dg
        D[g1] = Dg
    DS = D[:, None] * S
    DAt = D[:, None] * A.T if mit_a else np.zeros((n, 0))

    def normb(v):
        return max(float(np.linalg.norm(b)), float(np.linalg.norm(A @ v)), 1e-300) if mit_a else 1.0

    def stand(x, al):
        g = S @ x - c - (A.T @ al if mit_a else 0.0)
        v = x - D * g
        Phi = x - projektion_kegel(v, schranke, gruppen, radius(x))
        r = A @ x - b if mit_a else np.zeros(0)
        return g, v, Phi, r

    def merit(Phi, r):
        return float(Phi @ Phi) + float(r @ r)

    # Konvergenz zeilenweise: |Phi_i| (Spalt in Krafteinheiten der Zeile) relativ zu |x_i|, beim
    # Kreis zum Radius psi, mit Boden 1e-6 max|x| - nicht relativ zu |c|: am Drehlager tragen
    # offene Lager 40 mm entfernt d ~ 1e8, der Spalt geschlossener Zeilen liegt bei 1e-3, und
    # 1e-10 |c| liess Spalte von 1 auf geschlossenen Zeilen durch (gemessen 17.09.2026)
    tol_zeile = tol
    skala_x = np.ones(n)

    def fehler(x, Phi):
        boden = 1e-6 * max(float(np.abs(x).max()), 1e-300)
        sk = np.maximum(np.abs(x), boden)
        if kg:
            ps = radius(x)
            sk[g0] = np.maximum(sk[g0], ps)
            sk[g1] = np.maximum(sk[g1], ps)
        return float((np.abs(Phi) / sk).max())

    it = 0
    nr_alt = np.inf
    stau_r = 0
    for it in range(1, max_it + 1):
        g, v, Phi, r = stand(x, alpha)
        nr = float(np.linalg.norm(r))
        f_z = fehler(x, Phi)
        # Modenresiduum stagniert (Newton-Schritte senken nur Phi, die Mode traegt die
        # Flaeche nicht): dualer Aufstieg erzwingen (am Drehlager blieb |r| 30 Schritte bei
        # 0,79 stehen, gemessen 18.09.2026)
        stau_r = stau_r + 1 if (mit_a and nr > tol * normb(x) and nr > 0.9 * nr_alt) else 0
        nr_alt = nr
        psi_x = radius(x)
        if log is not None and it % log_alle == 0:
            pg = projektion_kegel(x - g, schranke, gruppen, psi_x) - x
            log(f"      QP {it}: Fehler je Zeile {f_z:.1e}, |pg| {np.linalg.norm(pg) / normc:.1e}, |r| {nr / normb(x) if mit_a else 0:.1e}, "
                f"frei {int((schranke & (v > 0)).sum())}/{int(schranke.sum())} Schranken, Rand "
                f"{int((np.linalg.norm(v[gruppen], axis=1) >= psi_x).sum()) if kg else 0}/{kg} Kreise")
        if f_z <= tol_zeile and (not mit_a or nr <= tol * normb(x)):
            return (x, alpha, True, it) if mit_a else (x, True, it)
        # verallgemeinerte Ableitung J der Projektion an v (blockdiagonal: 1x1 und 2x2)
        jd = np.ones(n)                                              # freie Zeilen: 1
        jd[schranke] = (v[schranke] > 0.0).astype(float)
        J = sp.lil_matrix((n, n))
        if kg:
            vg = v[gruppen]
            nv = np.linalg.norm(vg, axis=1)
            aussen = (nv >= psi_x) & (psi_x > 0.0)
            fest = psi_x <= 0.0
            jd[g0[fest]] = 0.0
            jd[g1[fest]] = 0.0
            for gi in np.flatnonzero(aussen):
                i0, i1 = g0[gi], g1[gi]
                sd = vg[gi] / nv[gi]
                f = psi_x[gi] / nv[gi]
                jd[i0] = f * (1.0 - sd[0] * sd[0])
                jd[i1] = f * (1.0 - sd[1] * sd[1])
                J[i0, i1] = -f * sd[0] * sd[1]
                J[i1, i0] = -f * sd[0] * sd[1]
        J = (J + sp.diags(jd)).tocsr()
        M = J @ DS                                                  # J D S (dicht, O(n^2))
        M = np.asarray(M)
        M[np.arange(n), np.arange(n)] += 1.0 - jd
        # Nebendiagonale von (I - J) fuer Kreispaare aussen; Coulomb: P_t = psi v_hat haengt
        # ueber psi = mu x_n von der Normalzeile ab -> dPhi_t/dx_n = -mu v_hat (x_n > 0)
        if kg:
            for gi in np.flatnonzero(aussen):
                i0, i1 = g0[gi], g1[gi]
                M[i0, i1] -= J[i0, i1]
                M[i1, i0] -= J[i1, i0]
                if coulomb and x[n_pos[gi]] > 0.0:
                    sd = vg[gi] / nv[gi]
                    M[i0, n_pos[gi]] -= mu[gi] * sd[0]
                    M[i1, n_pos[gi]] -= mu[gi] * sd[1]
        if mit_a:
            K = np.zeros((n + k, n + k))
            K[:n, :n] = M
            K[:n, n:] = -np.asarray(J @ DAt)
            K[n:, :n] = A
            rhs = -np.concatenate([Phi, r])
        else:
            K = M
            rhs = -Phi
        # singulaer (Flaeche haelt eine Mode nicht: Schrankenzeilen an 0 tragen sie nicht,
        # Randkreise nur quer zur Last): LU mit Tikhonov-Verschiebung statt SVD-Ausgleich
        # (gelsd braucht bei 10.000 Zeilen Minuten je Schritt, gemessen 17.09.2026); die
        # Liniensuche und der duale Aufstieg unten fangen einen unbrauchbaren Schritt ab
        dz = None
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", sla.LinAlgWarning)
            for delta in (0.0, 1e-12, 1e-8):
                try:
                    Kd = K if delta == 0.0 else K + (delta * max(float(np.abs(np.diag(K)).max()), 1e-300)) * np.eye(K.shape[0])
                    dz = sla.solve(Kd, rhs, check_finite=False)
                    if np.all(np.isfinite(dz)) and np.abs(dz).max() <= 1e12 * max(float(np.abs(x).max()), float(np.abs(rhs).max()), 1e-300):
                        break
                    dz = None
                except (np.linalg.LinAlgError, ValueError):
                    dz = None
        if dz is None:
            dz = np.zeros(K.shape[0])
        dx, dal = dz[:n], dz[n:]
        m0 = merit(Phi, r)
        ok = False
        t = 1.0
        for _ in range(30):
            xt = x + t * dx
            alt_ = alpha + t * dal
            _, _, Phit, rt = stand(xt, alt_)
            if merit(Phit, rt) <= (1.0 - 1e-4 * t) * m0:
                x, alpha, ok = xt, alt_, True
                break
            t *= 0.5
        if (not ok or stau_r >= 3) and mit_a and nr > tol * normb(x):
            # dualer Aufstieg: alpha entlang -r bis die naechste Zeile die Mode tragen kann -
            # Schrankenzeile an 0, deren v_i = x_i - D_i g_i positiv wird, oder gleitender Kreis,
            # der nach innen kommt (|v_t| < psi: haften, dann traegt er Kraft in jede Richtung;
            # am Drehlager blieb ein Stift mit lauter gleitenden Knoten bei |r| 0,8 stehen,
            # gemessen 18.09.2026) - Ratio-Test wie im Sattel-Newton
            dN = -r
            w = D * (A.T @ dN)
            kand = schranke & (v <= 0.0) & (w > 0.0)
            tN, wo = np.inf, -1
            if kand.any():
                tN = float((-v[kand] / w[kand]).min())
                wo = int(np.flatnonzero(kand)[np.argmin(-v[kand] / w[kand])])
            if kg:
                vg = v[gruppen]
                wg = w[gruppen]
                nv = np.linalg.norm(vg, axis=1)
                for gi in np.flatnonzero((nv >= psi_x) & (psi_x > 0.0)):
                    # |v + t w|^2 = psi^2: kleinste positive Wurzel
                    a2 = float(wg[gi] @ wg[gi])
                    if a2 <= 0.0:
                        continue
                    b2 = 2.0 * float(vg[gi] @ wg[gi])
                    c2 = float(vg[gi] @ vg[gi]) - psi_x[gi] ** 2
                    disc = b2 * b2 - 4.0 * a2 * c2
                    if disc < 0.0:
                        continue
                    t1 = (-b2 - np.sqrt(disc)) / (2.0 * a2)
                    if t1 > 0.0 and t1 < tN:
                        tN, wo = t1, int(g0[gi])
            if np.isfinite(tN):
                alpha = alpha + 1.000001 * tN * dN
                stau_r = 0
                if log is not None:
                    log(f"      QP {it}: dualer Aufstieg t {tN:.2e} auf Zeile {wo}")
                continue
        if not ok:
            # Rueckfall: projizierter Gradientenschritt (Fixpunkt x <- P_K(v))
            xn = projektion_kegel(v, schranke, gruppen, psi_x)
            aln = alpha
            _, _, Phin, rn_ = stand(xn, aln)
            if merit(Phin, rn_) >= m0 * (1.0 - 1e-12):
                # kein Fortschritt mehr messbar: an der Rundungsgrenze; gilt als konvergiert,
                # wenn der Fehler je Zeile wenigstens 1e-5 erreicht hat
                fein = f_z <= 1e-5 and (not mit_a or nr <= 1e-6 * normb(x))
                return (x, alpha, bool(fein), it) if mit_a else (x, bool(fein), it)
            x, alpha = xn, aln
    return (x, alpha, False, it) if mit_a else (x, False, it)


def _nachrechnen_reibung(Fd, dual, zustand, s, psi, C_z, tol_fix: float = 1e-13, max_fix: int = 30):
    """Exaktes Nachrechnen (Spec 6): Sattelsystem mit allen Zustaenden, gleitende Gruppen mit
    psi * s auf der rechten Seite, psi = mu lam_n als Fixpunkt auf demselben Sattelsystem (nur
    die rechte Seite aendert sich, die Faktorisierung bleibt). Wird die rechte Seite im Fixpunkt
    fuer eine Mode ohne Halt inkonsistent, bleibt die letzte konsistente Loesung. Der Fixpunkt
    endet bei tol_fix oder wenn er zweimal nacheinander nicht mehr halbiert (Rundungsgrenze:
    bei Spiel >> elastischer Verformung ist lam nur auf ~1e-16 * Spiel/Verformung bestimmt,
    gemessen 17.09.2026 am Stapel: 1e-10). Liefert lam, alpha, unzulaessig, psi, Fixpunktschritte."""
    r = dual.reib
    psi = np.asarray(psi, float).copy()
    C_all, bekannt, lam_b = _reib_mengen(dual, zustand, s, psi, C_z)
    idx = np.flatnonzero(C_all)
    idk = np.flatnonzero(bekannt)
    sattel = Sattel(Fd, dual, idx)
    gl = np.flatnonzero(zustand == GLEITEN) if r.k else np.zeros(0, int)
    lam = np.zeros(dual.m)
    alpha = np.zeros(dual.rn)
    vorher = None
    fix = 0
    d_alt = np.inf
    stau = 0
    for fix in range(1, (max_fix if len(gl) else 1) + 1):
        lam = np.zeros(dual.m)
        lam[idk] = lam_b[idk]
        rhs1 = dual.d - (Fd[:, idk] @ lam[idk] if len(idk) else 0.0)
        rhs2 = dual.en - ((dual.T.T @ (dual.G[:, idk] @ lam[idk])) if (len(idk) and dual.rn) else 0.0)
        unzul = sattel.unzulaessig(rhs2)
        if unzul:
            if vorher is not None:
                lam, alpha, psi = vorher
                return lam, alpha, False, psi, fix
            return lam, alpha, True, psi, fix
        if len(idx):
            lamC, alpha = sattel.loese(rhs1[idx], rhs2)
            lam[idx] = lamC
        else:
            alpha = np.zeros(dual.rn)
        if not len(gl):
            break
        psi_neu = psi.copy()
        psi_neu[gl] = r.mu[gl] * np.maximum(lam[r.n[gl]], 0.0)
        d = float(np.abs(psi_neu[gl] - psi[gl]).max() / max(float(psi_neu[gl].max()), 1e-300))
        vorher = (lam, alpha, psi)
        psi = psi_neu
        lam_b[r.t[gl, 0]] = psi[gl] * s[gl, 0]
        lam_b[r.t[gl, 1]] = psi[gl] * s[gl, 1]
        if d <= tol_fix:
            break
        stau = stau + 1 if d > 0.5 * d_alt else 0
        if stau >= 2:
            break
        d_alt = d
    return lam, alpha, False, psi, fix


def _halter_waehlen(dual, N, lam, zustand, U_g, U_z_frei, verbraucht, verbraucht_z, log, marke=""):
    """Zeilen und Gruppen, die die Moden ohne Halt (Spalten von N, in der Gn-Basis) tragen.

    Statt je Halter neu zu faktorisieren wird der Nullraum deflationiert: der beste Kandidat
    deckt eine Richtung ab, diese wird aus dem Rest herausprojiziert, der naechste deckt die
    naechste. Bewertung: Anteil an den verbleibenden Richtungen, Gruppen mit Haftreserve
    psi - ||lam_t|| und Zeilen mit grosser Kraft bevorzugt (ein Halter ohne Reserve muesste
    gleiten und wird beim Nachrechnen verworfen). Liefert (Gruppen, Zeilen) als Listen."""
    r = dual.reib
    kand_g = np.flatnonzero(U_g & ~verbraucht & (lam[r.n] > 0.0)) if r.k else np.zeros(0, np.int64)
    kand_z = np.flatnonzero(U_z_frei & ~verbraucht_z & (lam > 0.0))
    if not len(kand_g) and not len(kand_z):
        return [], []
    # Spalten in der Modenbasis: je Gruppe drei, je Zeile eine
    Sp_g = [dual.T.T @ dual.G[:, zeilen].toarray() for zeilen in
            ((r.n[kand_g], r.t[kand_g, 0], r.t[kand_g, 1]) if len(kand_g) else ())]
    Sp_z = dual.T.T @ dual.G[:, kand_z].toarray() if len(kand_z) else np.zeros((dual.rn, 0))
    # Vorzug: Reserve bzw. Kraft
    if len(kand_g):
        nt = np.linalg.norm(lam[r.t[kand_g]], axis=1)
        ps = r.mu[kand_g] * lam[r.n[kand_g]]
        reserve = (ps - nt) / np.maximum(ps, 1e-300)
        vorzug_g = np.where(reserve > 0.0, 1.0 + np.minimum(reserve, 1.0), 1e-3)
    else:
        reserve = np.zeros(0)
        vorzug_g = np.zeros(0)
    vorzug_z = 1.0 + np.minimum(lam[kand_z] / max(float(lam[kand_z].max()), 1e-300), 1.0) if len(kand_z) else np.zeros(0)
    rest = np.array(N, float)                                  # (rn x kN), orthonormale Spalten
    frei_g = np.ones(len(kand_g), bool)
    frei_z = np.ones(len(kand_z), bool)
    gewaehlt_g, gewaehlt_z = [], []
    while rest.shape[1] and (frei_g.any() or frei_z.any()):
        sc_g = np.zeros(len(kand_g))
        if frei_g.any():
            for Sp in Sp_g:
                sc_g += np.linalg.norm(rest.T @ Sp, axis=0) ** 2
            sc_g = np.sqrt(sc_g) * frei_g
        sc_z = np.abs(np.linalg.norm(rest.T @ Sp_z, axis=0)) * frei_z if frei_z.any() else np.zeros(len(kand_z))
        s_max = max(float(sc_g.max()) if len(sc_g) else 0.0, float(sc_z.max()) if len(sc_z) else 0.0)
        if s_max <= 1e-12:
            break
        w_g = sc_g / s_max * vorzug_g if len(sc_g) else np.zeros(0)
        w_z = sc_z / s_max * vorzug_z if len(sc_z) else np.zeros(0)
        gruppe = len(w_g) and (not len(w_z) or w_g.max() >= w_z.max())
        if gruppe:
            i_ = int(np.argmax(w_g))
            spalten = np.column_stack([Sp[:, i_] for Sp in Sp_g])
            gewaehlt_g.append(int(kand_g[i_]))
            frei_g[i_] = False
            log(f"{marke}Haltegruppe {int(kand_g[i_])} (Anteil {sc_g[i_] / s_max:.2f}, Reserve {reserve[i_]:.2f})")
        else:
            i_ = int(np.argmax(w_z))
            spalten = Sp_z[:, [i_]]
            gewaehlt_z.append(int(kand_z[i_]))
            frei_z[i_] = False
            log(f"{marke}Haltezeile {int(kand_z[i_])} (Anteil {sc_z[i_] / s_max:.2f}, lam {lam[kand_z[i_]]:.3e})")
        # abgedeckte Richtungen aus dem Rest herausprojizieren
        Y = rest.T @ spalten                                   # (kRest x c)
        u, sw, _ = np.linalg.svd(Y, full_matrices=False)
        u = u[:, sw > 1e-10 * max(float(sw.max()), 1e-300)]
        if not u.shape[1]:
            continue
        rest = rest - (rest @ u) @ u.T
        q, rr = np.linalg.qr(rest)
        halten = np.abs(np.diag(rr)) > 1e-10 * max(float(np.abs(np.diag(rr)).max()), 1e-300)
        rest = q[:, halten]
    return gewaehlt_g, gewaehlt_z


def verletzungen(dual, lam, spalt, zustand, s, psi, tol: float, tol_psi: float) -> dict:
    """Wie weit verletzt (lam, spalt) mit den Zustaenden (zustand, s, psi) die Kontaktbedingungen?

    Eine Stelle fuer alle, die es wissen muessen: `arbeitsmenge_reibung` erweitert damit seine
    Arbeitsmenge (es braucht die Masken, welche Zeilen und welche Gruppen verletzt sind) und
    `loese_reibung` bildet daraus den Nachweis (er braucht das groesste Mass). Getrennt gerechnet
    laufen die beiden auseinander: dem Nachweis fehlte zuerst die psi-Konsistenz, und weil ein zu
    gross gebliebenes psi die Abweichung vor der Kegelpruefung verdeckt (die verlangt nur
    ||lam_t|| <= psi), meldete er "gehalten" fuer einen Zustand mit 2,5e-2 Abweichung.

    Masse sind relativ: Kraefte auf max |lam|, Wege auf max |Spalt|, Boden 1e-300 gegen Null.
    Die Masken sind die Bedingungen mit Toleranz, die Masse die blanke Groesse - ein Verstoss
    unter der Toleranz steht im Nachweis als kleine Zahl, nicht als Null. `tol_psi` gilt nur fuer
    die psi-Konsistenz (Boden des Fixpunkts), alles andere misst in `tol`.

    Liefert die Massstaebe, die Zeilenbedingungen `zug_z` und `durch_z` (ohne Zustandsmenge - wer
    eine hat, schneidet sie selbst dazu), je Gruppenart Maske und Mass in `art`, die Gruppen mit
    irgendeiner Verletzung in `gruppe` und das groesste Mass ueber alles in `mass`.
    """
    r = dual.reib
    lam = np.asarray(lam, float)
    spalt = np.asarray(spalt, float)
    skala_l = max(float(np.abs(lam).max()), 1e-300)
    skala_g = max(float(np.abs(spalt).max()), 1e-300)
    ungleich_sonst = dual.ungleich.copy()
    if r.k:
        ungleich_sonst[r.n] = False                 # Normalzeilen der Gruppen laufen ueber den Zustand

    def hoch(wert, wo, skala) -> float:
        """Groesster einseitiger Verstoss auf `wo`, relativ zu `skala`; leere Menge = 0."""
        v = wert[wo]
        return float(np.maximum(v, 0.0).max()) / skala if v.size else 0.0

    # Zug und Durchdringung brauchen die Zustandsmenge nicht: die Partition C erzeugt jede Loesung
    # mit Spalt = 0 auf den geschlossenen und Kraft = 0 auf den offenen Zeilen, also kann je Zeile
    # hoechstens die eine Seite anschlagen. Das gilt auch ohne Konvergenz, denn C ist gesetzt,
    # bevor geloest wird - nicht erst an der Loesung.
    masse = [hoch(-lam, ungleich_sonst, skala_l), hoch(-spalt, ungleich_sonst, skala_g),
             hoch(np.abs(spalt), dual.gleich, skala_g)]
    art = {}
    if r.k:
        ln = lam[r.n]
        gn = spalt[r.n]
        nt = np.linalg.norm(lam[r.t], axis=1)
        ws = (-spalt[r.t] * s).sum(axis=1)          # Relativverschiebung entlang der Gleitrichtung
        d_psi = np.abs(nt - r.mu * np.maximum(ln, 0.0))
        zu = zustand != OFFEN
        ha = zustand == HAFTEN
        gl = zustand == GLEITEN
        art = {
            "Zug an geschlossener Normalzeile": (zu & (ln < -tol * skala_l), hoch(-ln, zu, skala_l)),
            "Durchdringung offen": (~zu & (gn < -tol * skala_g), hoch(-gn, ~zu, skala_g)),
            "Haften ueber Kegel": (ha & (nt > psi * (1 + tol) + tol * skala_l), hoch(nt - psi, ha, skala_l)),
            "Gleiten gegen Kraft": (gl & (ws < -tol * skala_g), hoch(-ws, gl, skala_g)),
            # psi = mu lam_n nur bis zum Fixpunktboden tol_psi
            "Gleiten psi != mu lam_n": (gl & (d_psi > tol_psi * skala_l), hoch(d_psi, gl, skala_l)),
        }
        masse += [m for _, m in art.values()]
    gruppe = np.zeros(r.k, bool)
    for maske, _ in art.values():
        gruppe |= maske
    return {"skala_l": skala_l, "skala_g": skala_g,
            "zug_z": lam < -tol * skala_l, "durch_z": spalt < -tol * skala_g,
            "art": art, "gruppe": gruppe, "mass": max(masse)}


def arbeitsmenge_reibung(Fd, dual, C, zustand, s, psi, lam0, alpha0, max_runden: int = 40,
                         tol: float = 1e-9, tresca: int = 30, log=print, ablage=None,
                         weiter: bool = False, tol_qp: float = 1e-10):
    """Exakter Abschluss mit Reibung (Spec 6). U = unsichere gewoehnliche Zeilen + unsichere
    Reibgruppen (ganz). Sicher: geschlossene Normalzeilen und haftende Tangentialzeilen ausserhalb
    U als Gleichungen, gleitende Gruppen ausserhalb U mit bekannter Kraft psi * s. Reduziertes QP
    ueber U mit Schranken (Normalzeilen) und Kreisen (Tangentialpaare, psi = mu lam_n als
    Tresca-Fixpunkt innen); haelt S keine Mode, steht ihr Gleichgewicht als Gleichung im QP
    (erweiterte Lagrange-Funktion). Zustaende der U-Gruppen aus dem QP (Kreisrand = Gleiten),
    dann exaktes Nachrechnen mit psi-Fixpunkt. Verletzte Zeilen und Gruppen (`verletzungen`:
    Zug, Durchdringung, Kegel, Gleiten gegen die Kraft, psi-Konsistenz) wandern nach U, das nur
    waechst. Liefert lam, alpha, zustand, s, psi, Runden, konvergiert."""
    r = dual.reib
    k = r.k
    ungleich_sonst = dual.ungleich.copy()
    if k:
        ungleich_sonst[r.n] = False
    gleich = dual.gleich
    lam = np.asarray(lam0, float).copy()
    alpha = np.asarray(alpha0, float).copy()
    zustand = np.asarray(zustand, int).copy()
    s = np.asarray(s, float).copy()
    psi = np.asarray(psi, float).copy()
    C = np.asarray(C, bool)
    sp_ = spalt_von(Fd, dual, lam, alpha)
    # Bei lockeren Stufen geht die psi-Schwelle mit `tol` mit, sonst waere sie dort strenger als
    # alles andere; bei strengen bleibt PSI_BODEN stehen, statt stille Untergrenze in einer
    # Bedingung zu sein, die sich sonst an `tol` haelt.
    tol_psi = max(tol, PSI_BODEN)
    # Start-U: Zeilen und Gruppen mit Verletzung im Startzustand
    v = verletzungen(dual, lam, sp_, zustand, s, psi, tol, tol_psi)
    U_z = ungleich_sonst & ((C & v["zug_z"]) | (~C & v["durch_z"]))
    U_g = v["gruppe"].copy()
    t0 = time.perf_counter()
    it_qp = 0
    runde0 = 0
    verbraucht = np.zeros(k, bool)
    verbraucht_z = np.zeros(dual.m, bool)
    if weiter and ablage is not None and pathlib.Path(str(ablage)).exists():
        z = np.load(str(ablage))
        lam, alpha, zustand, s, psi, C, U_z, U_g = (z[k_] for k_ in ("lam", "alpha", "zustand", "s", "psi", "C", "U_z", "U_g"))
        if len(alpha) != dual.rn:                        # Modenbasis hat sich geaendert
            alpha = np.zeros(dual.rn)
        if "verbraucht" in z.files:
            verbraucht = z["verbraucht"]
        if "verbraucht_z" in z.files:
            verbraucht_z = z["verbraucht_z"]
        runde0 = int(z["runde"])
        log(f"Arbeitsmenge: Fortsetzung nach Runde {runde0} aus {pathlib.Path(str(ablage)).name}")
    for runde in range(runde0 + 1, max_runden + 1):
        t1 = time.perf_counter()
        S_z = (C & ungleich_sonst & ~U_z) | gleich
        # Haelt S eine Mode nicht (alle Zeilen eines Koerpers unsicher), bleibt die U-Gruppe
        # dieses Koerpers mit der groessten Haftreserve psi - |lam_t| als Halter (haftend) in S;
        # erweist sie sich beim Nachrechnen als falsch, ist sie verbraucht und die naechste
        # uebernimmt. Die Modengleichung im QP bleibt Rueckfall (am Drehlager pendelte sie:
        # Aufstieg schliesst eine Zeile, der Newton-Schritt oeffnet sie wieder, 18.09.2026)
        halt = np.zeros(k, bool)
        halt_z = np.zeros(dual.m, bool)                 # Halter unter den gewoehnlichen Zeilen
        # mehrere Durchgaenge: nach dem Aufnehmen der Halter faellt gelegentlich eine weitere
        # Mode unter die Rangschwelle (die Deflation kostet nur eine Faktorisierung je Durchgang,
        # am Drehlager 4 s; frueher war es eine je Halter, 408 s, gemessen 18.09.2026)
        for _v in range(12):
            zust_eff = np.where(U_g & ~halt, OFFEN, zustand)
            zust_eff[halt] = HAFTEN
            C_sich, bekannt, lam_b = _reib_mengen(dual, zust_eff, s, psi, S_z | halt_z)
            Uz = U_z & ~halt_z
            if k:
                Uz[r.n[U_g & ~halt]] = True
                Uz[r.t[U_g & ~halt].ravel()] = True
            idxS = np.flatnonzero(C_sich & ~Uz)
            sattel = Sattel(Fd, dual, idxS)
            if sattel.vollrangig or not dual.rn:
                break
            g_neu, z_neu = _halter_waehlen(dual, sattel.nullv, lam, zustand, U_g & ~halt,
                                           U_z & ~halt_z & ungleich_sonst, verbraucht, verbraucht_z,
                                           log, marke=f"Arbeitsmenge {runde}: ")
            if not g_neu and not z_neu:
                break
            for g_ in g_neu:
                halt[g_] = True
                zustand[g_] = HAFTEN
            for z_ in z_neu:
                halt_z[z_] = True
            log(f"Arbeitsmenge {runde}: {len(g_neu)} Gruppen und {len(z_neu)} Zeilen halten "
                f"{sattel.nullv.shape[1]} Moden ({time.perf_counter() - t1:.0f} s)")
        U_g_eff = U_g & ~halt
        S_z = S_z | halt_z
        idxU = np.flatnonzero(Uz)
        idxK = np.flatnonzero(bekannt & ~Uz)
        rhs1 = dual.d - (Fd[:, idxK] @ lam_b[idxK] if len(idxK) else 0.0)
        rhs2 = dual.en - ((dual.T.T @ (dual.G[:, idxK] @ lam_b[idxK])) if (len(idxK) and dual.rn) else 0.0)
        p1, p2 = sattel.loese(rhs1[idxS], rhs2)
        log(f"Arbeitsmenge {runde}: |S| {len(idxS)}, |U| {len(idxU)} ({int(U_g_eff.sum())} Gruppen), |K| {len(idxK)}, "
            f"Sattel {'vollrangig' if sattel.vollrangig else str(sattel.nullv.shape[1]) + ' Moden ohne Halt'}, "
            f"{time.perf_counter() - t1:.0f} s")
        fix = 0
        if len(idxU):
            W1 = np.array(Fd[np.ix_(idxS, idxU)], order="F")
            W2 = dual.T.T @ dual.G[:, idxU].toarray() if dual.rn else np.zeros((0, len(idxU)))
            Qx, Qa = sattel.loese(W1, W2, nachiteration=0)
            SU = np.array(Fd[np.ix_(idxU, idxU)]) - W1.T @ Qx + W2.T @ Qa
            SU = (SU + SU.T) / 2
            cU = rhs1[idxU] - W1.T @ p1 + W2.T @ p2
            A_eq = b_eq = None
            if not sattel.vollrangig:
                # Moden ohne Halt in S: ihr Gleichgewicht steht als Gleichung A_eq lam_U = b_eq im
                # reduzierten QP - erweiterte Lagrange-Funktion (Strafe wq + Multiplikator-
                # Iteration), damit die Gleichung exakt gilt
                N = sattel.nullv
                A_eq = N.T @ W2
                b_eq = N.T @ rhs2
            pos = {int(j): i for i, j in enumerate(idxU)}
            schranke = np.array([ungleich_sonst[j] for j in idxU], bool)
            gr = np.flatnonzero(U_g_eff)
            gruppen = np.array([[pos[int(r.t[g, 0])], pos[int(r.t[g, 1])]] for g in gr], np.int64).reshape(-1, 2)
            n_pos = np.array([pos[int(r.n[g])] for g in gr], np.int64)
            schranke[n_pos] = True
            lamU = lam[idxU]
            psi_U = r.mu[gr] * np.maximum(lamU[n_pos], 0.0) if len(gr) else np.zeros(0)
            psi_alt = psi_U
            ok_qp = True
            alpha_N = np.zeros(0 if A_eq is None else len(b_eq))
            if ABLAGE_QP is not None:
                np.savez(ABLAGE_QP, S=SU, c=cU, lam0=lam[idxU], schranke=schranke, gruppen=gruppen, psi=psi_U,
                         n_pos=n_pos, mu=r.mu[gr], idxU=idxU, idxS=idxS, idxK=idxK,
                         A_eq=np.zeros((0, len(idxU))) if A_eq is None else A_eq,
                         b_eq=np.zeros(0) if A_eq is None else b_eq)
            # Coulomb direkt im QP-Newton (psi = mu lam_n mit Ableitung), keine Tresca-Schleife
            t_qp = time.perf_counter()
            if A_eq is None:
                lamU, ok_qp, it_qp = qp_kegel(SU, cU, lamU, schranke, gruppen, None, tol=tol_qp, log=log,
                                              log_alle=10, mu=r.mu[gr], n_pos=n_pos)
            else:
                lamU, alpha_N, ok_qp, it_qp = qp_kegel(SU, cU, lamU, schranke, gruppen, None, A=A_eq, b=b_eq,
                                                       alpha0=alpha_N, tol=tol_qp, log=log, log_alle=10,
                                                       mu=r.mu[gr], n_pos=n_pos)
            psi_U = r.mu[gr] * np.maximum(lamU[n_pos], 0.0) if len(gr) else np.zeros(0)
            psi_alt = psi_U
            n_tresca = 1
            d_tresca = 0.0
            log(f"    Reduktion {t_qp - t1:.0f} s, QP {it_qp} Schritte {int(ok_qp)} in {time.perf_counter() - t_qp:.0f} s")
            # Schranken nach der PDAS-Regel lam - Spalt > 0 einstufen, nicht nach lam > 0: das QP
            # laesst Zeilen mit winzigem lam > 0 und grossem Spalt stehen (praktisch offen; der
            # projizierte Gradient ist dort klein), und "geschlossen" erzwaenge beim Nachrechnen
            # Spalt = 0 (gemessen 17.09.2026 am Drehlager: Spalt 1e-2 auf "geschlossenen" U-Zeilen,
            # Nachrechnen 46 % neben dem QP)
            spU = SU @ lamU - cU - (A_eq.T @ alpha_N if A_eq is not None else 0.0)
            zu_U = schranke & ((lamU - spU) > 0.0)
            if len(gr):
                ltU = lamU[gruppen]
                lnU = lamU[n_pos]
                ntU = np.linalg.norm(ltU, axis=1)
                zustand[gr] = np.where(~zu_U[n_pos], OFFEN, np.where(ntU >= psi_alt * (1 - 1e-9), GLEITEN, HAFTEN))
                for i_, g_ in enumerate(gr):
                    if zustand[g_] == GLEITEN:
                        s[g_] = ltU[i_] / max(float(ntU[i_]), 1e-300)
                psi[gr] = psi_U
            C_z = (C & ungleich_sonst & ~U_z) | gleich | halt_z
            C_z[idxU[zu_U]] = True
            C_z[idxU[schranke & ~zu_U]] = False
            if k:
                C_z[r.n] = False
                C_z[r.t.ravel()] = False
            # Kontrolle der Reduktion: die reduzierte Loesung im vollen System - Spalt auf S und
            # auf den geschlossenen U-Zeilen muss null sein, sonst ist Qx (eps-Shift) ungenau
            lam_red = np.zeros(dual.m)
            lam_red[idxK] = lam_b[idxK]
            lam_red[idxS] = p1 - Qx @ lamU
            lam_red[idxU] = lamU
            alpha_red = p2 - Qa @ lamU
            sp_red = spalt_von(Fd, dual, lam_red, alpha_red)
            sk_g = max(float(np.abs(sp_red).max()), 1e-300)
            zu_idx = idxU[zu_U]
            log(f"    Reduktion: Spalt auf S max {np.abs(sp_red[idxS]).max() / sk_g if len(idxS) else 0:.1e}, auf geschlossenen U-Zeilen "
                f"{np.abs(sp_red[zu_idx]).max() / sk_g if len(zu_idx) else 0:.1e}, Moden |Gn lam - en| "
                f"{np.linalg.norm(dual.T.T @ (dual.G @ lam_red) - dual.en) / max(np.linalg.norm(dual.en), 1e-300) if dual.rn else 0:.1e}, eps {sattel.eps:g}")
            # Nachrechnen; eine belastete Mode ohne Halt (weiche Mode, z. B. Gleiten bis zum
            # Anschlag, im Modensystem winzig skaliert und im QP innerhalb der Toleranz) bekommt
            # wie im Newton die am staerksten durchdringenden offenen Zeilen dazu
            for _h in range(6):
                lam_n, alpha_n, unzul, psi_n, fix = _nachrechnen_reibung(Fd, dual, zustand, s, psi, C_z)
                if not unzul:
                    lam, alpha, psi = lam_n, alpha_n, psi_n
                    break
                sp_h = spalt_von(Fd, dual, lam_n, alpha_n)
                offen_h = np.flatnonzero(ungleich_sonst & ~C_z)
                kand = offen_h[np.argsort(sp_h[offen_h])[:max(6, len(offen_h) // 100)]] if len(offen_h) else np.zeros(0, int)
                zu_g = (zustand == OFFEN) & (sp_h[r.n] < 0.0) if k else np.zeros(0, bool)
                if not len(kand) and not zu_g.any():
                    break
                C_z[kand] = True
                zustand[zu_g] = HAFTEN
                log(f"Arbeitsmenge {runde}: Mode ohne Halt im Nachrechnen - {len(kand)} Zeilen, {int(zu_g.sum())} Gruppen geschlossen")
            C = C_z.copy()
            # Kontrolle: weicht das Nachrechnen von der QP-Loesung auf U ab?
            if not unzul:
                abw = float(np.linalg.norm(lam[idxU] - lamU) / max(float(np.linalg.norm(lamU)), 1e-300))
                if abw > 1e-8:
                    log(f"    Nachrechnen weicht von QP auf U ab: {abw:.2e} (max je Zeile {np.abs(lam[idxU] - lamU).max() / max(float(np.abs(lamU).max()), 1e-300):.2e})")
                    # erste Loesung ohne psi-Fixpunkt und die staerksten Abweichungen je Zeile
                    C_a, bek_a, lb_a = _reib_mengen(dual, zustand, s, psi, C_z)
                    lam_e, alpha_e, unzul_e, _ = loesung_dicht(Fd, dual, C_a, lam_bekannt=lb_a, bekannt=bek_a)
                    abw_e = float(np.linalg.norm(lam_e[idxU] - lamU) / max(float(np.linalg.norm(lamU)), 1e-300))
                    log(f"    erste Nachrechnen-Loesung (ohne Fixpunkt): Abweichung {abw_e:.2e}, unzulaessig {unzul_e}; "
                        f"C_all {int(C_a.sum())} Zeilen, bekannt {int(bek_a.sum())}")
                    art_z = np.full(dual.m, "S")
                    art_z[idxU] = "U"
                    if k:
                        art_z[r.n] = np.char.add(art_z[r.n], "n")
                        art_z[r.t[:, 0]] = np.char.add(art_z[r.t[:, 0]], "t")
                        art_z[r.t[:, 1]] = np.char.add(art_z[r.t[:, 1]], "t")
                    grp = -np.ones(dual.m, np.int64)
                    if k:
                        grp[r.n] = np.arange(k)
                        grp[r.t[:, 0]] = np.arange(k)
                        grp[r.t[:, 1]] = np.arange(k)
                    diff = np.zeros(dual.m)
                    diff[idxU] = np.abs(lam[idxU] - lamU)
                    diff[idxS] = np.abs(lam[idxS] - lam_red[idxS])
                    top = np.argsort(-diff)[:6]
                    log("    staerkste Abweichungen: " + "; ".join(
                        f"Zeile {j} {art_z[j]} Zustand {int(zustand[grp[j]]) if grp[j] >= 0 else '-'} C_all {int(C_a[j])} bek {int(bek_a[j])} "
                        f"QP {lam_red[j]:.3e} nach {lam[j]:.3e} Spalt_QP {sp_red[j]:.2e}" for j in top))
            if unzul:
                # Mode ohne Halt bleibt: die QP-Werte (Gleichgewicht der Mode als Gleichung im QP)
                log(f"Arbeitsmenge {runde}: Koerpermode ohne Halt bleibt - QP-Werte")
                lam = np.zeros(dual.m)
                lam[idxK] = lam_b[idxK]
                lam[idxS] = p1 - Qx @ lamU
                lam[idxU] = lamU
                alpha = p2 - Qa @ lamU
            log(f"    Nachrechnen: psi-Fixpunkt {fix} Schritte")
        else:
            ok_qp = True
            lam = np.zeros(dual.m)
            lam[idxK] = lam_b[idxK]
            lam[idxS] = p1
            alpha = p2
        # Pruefung auf ganz F - dieselbe Rechnung, die auch den Nachweis speist
        sp_ = spalt_von(Fd, dual, lam, alpha)
        v = verletzungen(dual, lam, sp_, zustand, s, psi, tol, tol_psi)
        zug = S_z & ungleich_sonst & v["zug_z"]
        durch = ~S_z & ~Uz & ungleich_sonst & v["durch_z"]
        verletzt = v["gruppe"]
        neu_g = verletzt & ~U_g_eff
        innen_g = verletzt & U_g_eff
        verbraucht |= verletzt & halt                        # falscher Halter: nicht wieder waehlen
        verbraucht_z |= zug & halt_z
        # Verletzungen auch innerhalb U (nach dem exakten Nachrechnen): Zug an geschlossenen
        # Zeilen, Durchdringung an offenen, Kegel an haftenden Gruppen
        innen = ungleich_sonst & Uz & ((C & v["zug_z"]) | (~C & v["durch_z"]))
        log(f"Arbeitsmenge {runde}: |S| {len(idxS)}, |U| {len(idxU)} ({int(U_g_eff.sum())} Gruppen), Zug {int(zug.sum())}, "
            f"Durchdringung {int(durch.sum())}, Gruppen neu {int(neu_g.sum())}, innen {int(innen.sum())} Zeilen "
            f"{int(innen_g.sum())} Gruppen, {time.perf_counter() - t1:.1f} s, {time.perf_counter() - t0:.0f} s")
        fertig = ok_qp and not zug.any() and not durch.any() and not neu_g.any() and not innen.any() and not innen_g.any()
        if not fertig and k and (innen_g.any() or neu_g.any()):
            teile = [f"{name}: {int((m_ & innen_g).sum())} innen / {int((m_ & neu_g).sum())} aussen, max {mass:.1e}"
                     for name, (m_, mass) in v["art"].items() if m_.any()]
            log("    Verletzungen: " + "; ".join(teile))
        if fertig:
            return lam, alpha, zustand, s, psi, runde, True
        U_z |= zug | durch
        U_g |= neu_g
        if ablage is not None:
            np.savez(str(ablage), lam=lam, alpha=alpha, zustand=zustand, s=s, psi=psi, C=C, U_z=U_z, U_g=U_g, runde=runde,
                     verbraucht=verbraucht, verbraucht_z=verbraucht_z)
    return lam, alpha, zustand, s, psi, max_runden, False


def loese_reibung(Fd, dual, max_newton: int = 40, max_runden: int = 40, log=print, ablage=None,
                  weiter: bool = False, vorgabe=None) -> dict:
    """Startwert (alle Zeilen als Gleichungen, Zug weggeschnitten) -> Zustands-Newton -> bei Bedarf
    Abschluss mit Kreisen. lam physikalisch (skal * lam); reib: Zustaende, Richtungen, psi.
    `ablage`: Newton-Endzustand (.npz) ablegen; `weiter`: den Newton ueberspringen und mit dem
    abgelegten Zustand in den Abschluss gehen (Messungen am Drehlager).
    `vorgabe`: Genauigkeitsstufe; sie setzt die Toleranzen und steht als `genauigkeit` im Ergebnis.
    Ein Nachweis mit `gehalten` False ist auf groben Stufen ein erwartetes Ergebnis und kein
    Rueckschritt: der Loeser sagt dann, dass er die Zusage nicht erreicht hat, statt sie zu
    behaupten (auf "sehr locker" bricht der Zustands-Newton frueh genug ab, dass der Abschluss
    es nicht mehr einholt - gemessen 18.09.2026 am Block ohne y-Lager)."""
    t0 = time.perf_counter()
    from . import genauigkeit as gen
    vorgabe = gen.aufloesen() if vorgabe is None else vorgabe
    # Die Stufe setzt die Toleranzen: der Newton bricht bei der Schranke ab, das QP rechnet als
    # inneres Verfahren eine Groessenordnung feiner - der Faktor 0,1 ist nicht neu gewaehlt,
    # sondern das Verhaeltnis der bisherigen festen Werte 1e-9 (Newton) und 1e-10 (QP). Die
    # Lockerung von 1e-9 auf 1e-6 ("normal") kostet nichts und spart einen Schritt (gemessen
    # 18.09.2026 am gleitenden Block: 21 -> 20 Newton-Schritte, lam um 1,7e-17 verschoben;
    # Kegel und Gleichgewicht bleiben 1e-16)
    tol = vorgabe.residuum
    tol_qp = 0.1 * tol

    def nachweis_von(lam, alpha, zustand, s, psi):
        """Gemessen wird die Verletzung der Kontaktbedingungen: genau das, was `arbeitsmenge_reibung`
        am Ende jeder Runde prueft, aus derselben Rechnung (`verletzungen`) und mit denselben
        Zustaenden - Zug, Durchdringung, Gleichungsrest, Kegel, Gleiten gegen die Kraft und die
        psi-Konsistenz. Der Nachweis nimmt davon das groesste Mass.

        Nur der Gleichungsrest waere kein Nachweis: Gleichungszeilen stehen in jedem Schritt in der
        Menge C und werden vom Sattelsystem exakt geloest (gemessen 18.09.2026: 2e-23), und eine
        Reibfuge ohne Verbund hat gar keine. Der Nachweis haette dann 'gehalten' gemeldet, waehrend
        die Kegelverletzung 1,0 betrug."""
        sp_end = spalt_von(Fd, dual, lam, alpha)
        rest = verletzungen(dual, lam, sp_end, zustand, s, psi, tol, max(tol, PSI_BODEN))["mass"]
        return gen.bewerte(vorgabe, residuum=rest, rechenart="double", nachiterationen=0,
                           rueckfall=None if rest <= vorgabe.residuum else vorgabe.rueckfall)

    if weiter and ablage is not None and pathlib.Path(str(ablage)).exists():
        z = np.load(str(ablage))
        lam, alpha, zustand, s, psi, C = z["lam"], z["alpha"], z["zustand"], z["s"], z["psi"], z["C"]
        if len(alpha) != dual.rn:                        # Modenbasis hat sich geaendert
            alpha = np.zeros(dual.rn)
        it, ok = int(z["newton"]), False
        log(f"Reibung: Newton-Endzustand aus {pathlib.Path(str(ablage)).name} ({it} Schritte)")
        ablage_r = pathlib.Path(str(ablage)).with_name(pathlib.Path(str(ablage)).stem + "_runde.npz")
        lam, alpha, zustand, s, psi, runden, ok = arbeitsmenge_reibung(Fd, dual, C, zustand, s, psi, lam, alpha,
                                                                        max_runden=max_runden, tol=tol, tol_qp=tol_qp,
                                                                        log=log, ablage=ablage_r, weiter=True)
        nachweis = nachweis_von(lam, alpha, zustand, s, psi)
        log(gen.zeile(nachweis))
        alpha_r = dual.T @ alpha if dual.rn else np.zeros(dual.r)
        u = dual.verschiebung(lam, alpha_r)
        return {"lam": dual.skal * lam, "lam_skal": lam, "alpha": alpha_r, "alpha_moden": alpha, "u": u, "newton": it,
                "runden": runden, "konvergiert": ok, "zeit": time.perf_counter() - t0,
                "genauigkeit": nachweis.als_dict(),
                "reib": {"zustand": zustand, "s": s, "psi": dual.skal[dual.reib.n] * psi}}
    # Startwert: Normal- und Gleichungszeilen als Gleichungen, Tangentialzeilen mit Kraft 0 -
    # alle Zeilen zugleich waeren abhaengig (Tangentialzeilen und Anschlaege halten dieselbe
    # Richtung), das Sattelsystem singulaer und lam ~ 1e12 (gemessen 17.09.2026)
    C0 = ~dual.tang
    lam0, alpha0, _, _ = loesung_dicht(Fd, dual, C0, lam_bekannt=np.zeros(dual.m), bekannt=dual.tang)
    lam0[dual.ungleich] = np.maximum(lam0[dual.ungleich], 0.0)
    lam, alpha, zustand, s, psi, C, it, ok = newton_reibung(Fd, dual, lam0, max_it=max_newton, tol=tol,
                                                            log=log, alpha0=alpha0)
    runden = 0
    if ablage is not None:
        np.savez(str(ablage), lam=lam, alpha=alpha, zustand=zustand, s=s, psi=psi, C=C, newton=it)
    if ok:
        # Newton haelt bei dpsi <= 1e-9: psi-Fixpunkt auf demselben Sattelsystem bis 1e-13, damit
        # ||lam_t|| = mu lam_n exakt gilt (gemessen 17.09.2026: Kegel 4e-11 -> 1e-15)
        lam_p, alpha_p, unzul, psi_p, fix = _nachrechnen_reibung(Fd, dual, zustand, s, psi, C)
        if not unzul:
            lam, alpha, psi = lam_p, alpha_p, psi_p
            log(f"Reibung: psi-Fixpunkt {fix} Schritte")
    if not ok:
        ablage_r = None if ablage is None else pathlib.Path(str(ablage)).with_name(pathlib.Path(str(ablage)).stem + "_runde.npz")
        lam, alpha, zustand, s, psi, runden, ok = arbeitsmenge_reibung(Fd, dual, C, zustand, s, psi, lam, alpha,
                                                                        max_runden=max_runden, tol=tol, tol_qp=tol_qp,
                                                                        log=log, ablage=ablage_r)
    nachweis = nachweis_von(lam, alpha, zustand, s, psi)
    log(gen.zeile(nachweis))
    alpha_r = dual.T @ alpha if dual.rn else np.zeros(dual.r)
    u = dual.verschiebung(lam, alpha_r)
    return {"lam": dual.skal * lam, "lam_skal": lam, "alpha": alpha_r, "alpha_moden": alpha, "u": u, "newton": it, "runden": runden,
            "konvergiert": ok, "zeit": time.perf_counter() - t0, "genauigkeit": nachweis.als_dict(),
            "reib": {"zustand": zustand, "s": s, "psi": dual.skal[dual.reib.n] * psi}}


class DualKondensiert:
    """Duales Problem ohne die Gleichungszeilen E (Kopplungen, haften-Tangentialzeilen, Verbund):
    sie stehen in jedem Schritt in S, also einmal eliminieren. Sattelsystem auf E mit den Moden
    (Sattel: eps-Shift, Schur-Eigenzerlegung); fuer die uebrigen Zeilen I gilt
        Spalt_I = F_red lam_I - d_red - G_red^T alpha_N
    mit F_red = F_II - F_IE Qx + Gn_I^T Qa, d_red = d_I - F_IE p1 + Gn_I^T p2 und den von E nicht
    gehaltenen Moden N (G_red = N^T Gn_I, en_red = N^T en). Sieht fuer ama.dicht aus wie ein Dual
    (m, d, en, T = I, G, Gnt, ungleich, gleich, tang, reib, skal, verschiebung); `voll` gibt lam
    und alpha des vollen Problems zurueck. Am Drehlager (17.09.2026): 66.895 -> 43.400 Zeilen,
    Cholesky je Newton-Schritt 1e14 -> 2.7e13 Flops."""

    def __init__(self, Fd, dual, nachiteration: int = 1, log=print, ablage=None):
        """`ablage`: Pfad (ohne Endung) fuer F_red (.npy, memmap) und die kleinen Teile (.npz);
        passt eine Ablage zum Problem (Zeilenmengen, d), wird sie geladen statt gerechnet."""
        from .bedingungen import Reibung
        t0 = time.perf_counter()
        self.voll_dual = dual
        self.Fd_voll = Fd
        self.E = np.flatnonzero(dual.gleich)
        self.I = np.flatnonzero(~dual.gleich)
        E, I = self.E, self.I
        self.m = len(I)
        self.nachiteration = nachiteration
        geladen = False
        if ablage is not None:
            pfad = pathlib.Path(str(ablage))
            npz, npy = pfad.with_suffix(".npz"), pfad.with_suffix(".npy")
            if npz.exists() and npy.exists():
                z = np.load(npz)
                if (z["m_voll"] == dual.m and np.array_equal(z["E"], E) and np.array_equal(z["I"], I)
                        and np.allclose(z["d_voll"], dual.d) and np.allclose(z["en_voll"], dual.en)):
                    self.Fd = np.array(np.load(npy, mmap_mode="r"), order="F")
                    self.d, self.N, self.en = z["d"], z["N"], z["en"]
                    geladen = True
                    log(f"Kondensiert: F_red aus {npy.name} geladen ({time.perf_counter() - t0:.0f} s)")
        if not geladen:
            sattel = Sattel(Fd, dual, E)
            p1, p2 = sattel.loese(dual.d[E], dual.en)
            W1 = np.array(Fd[np.ix_(E, I)], order="F") if len(E) else np.zeros((0, self.m))
            W2 = (dual.T.T @ dual.G[:, I].toarray()) if dual.rn else np.zeros((0, self.m))
            if len(E):
                Qx, Qa = sattel.loese(W1, W2, nachiteration=nachiteration)
            else:
                Qx, Qa = np.zeros((0, self.m)), np.zeros((dual.rn, self.m))
            F_red = np.array(Fd[np.ix_(I, I)], order="F")
            if len(E):
                F_red -= W1.T @ Qx
            if dual.rn:
                F_red += W2.T @ Qa
            self.d = dual.d[I] - (W1.T @ p1 if len(E) else 0.0) + (W2.T @ p2 if dual.rn else 0.0)
            del Qx, W1
            self.Fd = np.asarray((F_red + F_red.T) / 2, order="F")
            del F_red
            # Moden ohne Halt in E
            self.N = sattel.nullv if dual.rn else np.zeros((0, 0))
            self.en = self.N.T @ dual.en if self.N.shape[1] else np.zeros(0)
            if ablage is not None:
                pfad = pathlib.Path(str(ablage))
                Fm = np.lib.format.open_memmap(pfad.with_suffix(".npy"), mode="w+", dtype=np.float64,
                                               shape=self.Fd.shape, fortran_order=True)
                Fm[:] = self.Fd
                Fm.flush()
                del Fm
                np.savez(pfad.with_suffix(".npz"), m_voll=dual.m, E=E, I=I, d_voll=dual.d, en_voll=dual.en,
                         d=self.d, N=self.N, en=self.en)
                log(f"Kondensiert: F_red nach {pfad.with_suffix('.npy').name} abgelegt")
        kN = self.N.shape[1]
        self.rn = self.r = kN
        self.T = np.eye(kN)
        W2 = (dual.T.T @ dual.G[:, I].toarray()) if dual.rn else np.zeros((0, self.m))
        self.G = sp.csr_matrix(self.N.T @ W2) if kN else sp.csr_matrix((0, self.m))
        self.ungleich = dual.ungleich[I]
        self.tang = dual.tang[I]
        self.gleich = np.zeros(self.m, bool)
        self.skal = dual.skal[I]
        pos = -np.ones(dual.m, np.int64)
        pos[I] = np.arange(self.m)
        r = dual.reib
        self.reib = Reibung(pos[r.n], pos[r.t], r.mu) if r.k else Reibung()
        self.f = dual.f
        self.k = dual.k
        self.off = dual.off
        log(f"Kondensiert: {len(E)} Gleichungszeilen eliminiert, {self.m} Zeilen bleiben, "
            f"{kN} von {dual.rn} Moden ohne Halt in E, {time.perf_counter() - t0:.0f} s")

    def Gnt(self, y):
        return self.G.T @ y

    def Gn(self, lam):
        return self.G @ lam

    def F(self, v):
        return self.Fd @ v

    def voll(self, lam_I, alpha_N):
        """lam (m_voll) und alpha (r_voll, wie dual.T @ alpha) des vollen Problems: Sattelsystem
        auf E mit lam_I auf der rechten Seite (statt Qx zu halten - am Drehlager 8 GB)."""
        dual = self.voll_dual
        E, I = self.E, self.I
        lam = np.zeros(dual.m)
        lam[I] = lam_I
        alpha = np.zeros(dual.rn)
        if len(E) or dual.rn:
            sattel = Sattel(self.Fd_voll, dual, E)
            rhs1 = dual.d[E] - (np.array(self.Fd_voll[np.ix_(E, I)]) @ lam_I if len(E) else 0.0)
            rhs2 = dual.en - ((dual.T.T @ (dual.G[:, I] @ lam_I)) if dual.rn else 0.0)
            lamE, alpha = sattel.loese(rhs1, rhs2, nachiteration=2)
            lam[E] = lamE
            if self.rn:
                alpha = alpha + self.N @ np.asarray(alpha_N, float)
        return lam, (dual.T @ alpha if dual.rn else np.zeros(dual.r))

    def verschiebung(self, lam_I, alpha_N):
        lam, alpha_r = self.voll(lam_I, alpha_N)
        return self.voll_dual.verschiebung(lam, alpha_r)


def loese_reibung_system(system, lasten: dict, Fd=None, log=print, kondensieren: bool = False,
                         vorgabe=None) -> dict:
    """Bequemer Einstieg: System -> Dual -> F (falls nicht gegeben) -> loese_reibung + Pruefung;
    u je Koerper (nk, fj) wie in Ergebnis. `kondensieren`: Gleichungszeilen vorab eliminieren
    (DualKondensiert); lam, u und Pruefung beziehen sich immer auf das volle Problem.
    `vorgabe`: Genauigkeitsstufe, geht unveraendert an `loese_reibung`."""
    from . import kontakt, pruefung

    f = system.lastvektor(lasten)
    dual = kontakt.Dual(system.koerper_liste, system.offsets, system.B, system.ungleich, system.g, f,
                        reib=system.reib)
    if Fd is None:
        Fd = nachgiebigkeit(dual)
    if kondensieren:
        red = DualKondensiert(Fd, dual, log=log)
        erg = loese_reibung(red.Fd, red, log=log, vorgabe=vorgabe)
        lam_v, alpha_v = red.voll(erg["lam_skal"], erg["alpha"])
        erg["lam_skal"] = lam_v
        erg["lam"] = dual.skal * lam_v
        erg["alpha"] = alpha_v
    else:
        erg = loese_reibung(Fd, dual, log=log, vorgabe=vorgabe)
    erg["pruefung"] = pruefung.pruefe(system.koerper_liste, system.offsets, system.B, system.ungleich,
                                      system.g, f, erg["lam"], erg["u"], reib=system.reib)
    erg["u_flach"] = erg["u"]
    erg["u"] = [kb.voll(erg["u"][system.offsets[i]:system.offsets[i + 1]]).reshape(kb.nk, kb.fj)
                for i, kb in enumerate(system.koerper_liste)]
    return erg
