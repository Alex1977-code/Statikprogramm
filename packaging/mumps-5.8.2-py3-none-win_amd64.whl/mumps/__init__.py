"""
MUMPS 5.8.2 (CeCILL-C) fuer Statik3D unter Windows - Anbindung ueber ctypes.

Die Schnittstelle folgt PyMUMPS (``from mumps import DMumpsContext``), damit
``statik3d.solver.LinearSolver._mumps`` sie unveraendert nutzen kann::

    ctx = DMumpsContext(sym=0, par=1)
    ctx.set_silent()
    ctx.set_shape(n)
    ctx.set_centralized_assembled(irn, jcn, a)     # COO, 1-basiert
    ctx.run(job=4)                                  # Analyse + Faktorisierung
    ctx.set_rhs(x); ctx.run(job=3)                  # x wird in place geloest
    ctx.destroy()

Warum kein PyMUMPS: das braucht Cython und mpi4py (unter Windows: MS-MPI),
obwohl die sequentielle MUMPS-Bibliothek den Communicator nur durchreicht.
Dieser Wrapper ruft die C-Schnittstelle ``dmumps_c`` direkt; die Struktur
``DMUMPS_STRUC_C`` ist Feld fuer Feld aus ``_lib/dmumps_c.h`` (Version 5.8.2)
uebernommen - ihre Reihenfolge ist versionsabhaengig, darum liegt der Header
mit im Paket und ``DMumpsContext`` prueft nach dem Initialisieren, dass MUMPS
seine Versionsnummer an die erwartete Stelle der Struktur schreibt.

Bibliotheken in ``_lib/`` - genau eine der beiden Varianten liegt dort:

* ``libdmumps_seq.dll`` - eigener Bau aus dem MUMPS-Quelltext mit MSYS2
  gfortran (OpenMP in MUMPS, BLR_MT), OpenBLAS (OpenMP-Fassung) und METIS;
  die Laufzeit-DLLs (libopenblas, libgomp, libgfortran, libquadmath,
  libwinpthread, libgcc_s_seh) liegen daneben. Braucht keine MKL. OpenMP
  hier ist GNU libgomp: es kollidiert nicht mit der Intel-Laufzeit
  libiomp5md der MKL (PARDISO) im selben Prozess - die "OMP: Error #15"
  gibt es nur zwischen Intel- und LLVM-Laufzeit.
* ``dmumps.dll`` - conda-forge-Paket mumps-seq 5.8.2 (flang, ohne OpenMP in
  MUMPS) mit ``libblas.dll``/``liblapack.dll`` als Weiterleitung auf die
  ``mkl_rt.3.dll`` des pip-Pakets mkl. Rueckfall, falls der eigene Bau fehlt.

Lizenz: MUMPS steht unter CeCILL-C (``LIZENZ/``). Die Bibliothek ist im
Quelltext unveraendert; dieser Wrapper ist eigener Quelltext (Statik3D)
und kein Teil von MUMPS.
"""
from __future__ import annotations

import ctypes
import glob
import os
import sys

import numpy as np

MUMPS_VERSION = "5.8.2"
__version__ = "5.8.2"

_HIER = os.path.dirname(os.path.abspath(__file__))
LIB_DIR = os.path.join(_HIER, "_lib")
LIZENZ_DIR = os.path.join(_HIER, "LIZENZ")

#: (Name der Variante, DLL-Datei) in der Reihenfolge, in der gesucht wird.
_VARIANTEN = (("gfortran", "libdmumps_seq.dll"), ("conda-mkl", "dmumps.dll"))
#: Welche Variante geladen ist - gesetzt beim ersten Laden.
VARIANTE = None

#: MUMPS erwartet fuer den sequentiellen Bau diesen Wert als Communicator
#: (mumps_c.c: USE_COMM_WORLD).
_USE_COMM_WORLD = -987654

MUMPS_INT = ctypes.c_int            # mumps_int_def.h: MUMPS_INTSIZE32
MUMPS_INT8 = ctypes.c_int64
DMUMPS_REAL = ctypes.c_double
_P_INT = ctypes.POINTER(ctypes.c_int)
_P_REAL = ctypes.POINTER(ctypes.c_double)


class DMUMPS_STRUC_C(ctypes.Structure):
    """Feldfolge aus _lib/dmumps_c.h (MUMPS 5.8.2) - nicht umsortieren."""
    _fields_ = [
        ("sym", MUMPS_INT), ("par", MUMPS_INT), ("job", MUMPS_INT),
        ("comm_fortran", MUMPS_INT),
        ("icntl", MUMPS_INT * 60),
        ("keep", MUMPS_INT * 500),
        ("cntl", DMUMPS_REAL * 15),
        ("dkeep", DMUMPS_REAL * 230),
        ("keep8", MUMPS_INT8 * 150),
        ("n", MUMPS_INT), ("nblk", MUMPS_INT),
        ("nz_alloc", MUMPS_INT),
        # zentral zusammengesetzte Matrix
        ("nz", MUMPS_INT), ("nnz", MUMPS_INT8),
        ("irn", _P_INT), ("jcn", _P_INT), ("a", _P_REAL),
        # verteilte Matrix
        ("nz_loc", MUMPS_INT), ("nnz_loc", MUMPS_INT8),
        ("irn_loc", _P_INT), ("jcn_loc", _P_INT), ("a_loc", _P_REAL),
        # elementweise Matrix
        ("nelt", MUMPS_INT), ("eltptr", _P_INT), ("eltvar", _P_INT), ("a_elt", _P_REAL),
        # Blockstruktur
        ("blkptr", _P_INT), ("blkvar", _P_INT),
        # Ordnungen
        ("perm_in", _P_INT), ("sym_perm", _P_INT), ("uns_perm", _P_INT),
        # Skalierung
        ("colsca", _P_REAL), ("rowsca", _P_REAL),
        ("colsca_from_mumps", MUMPS_INT), ("rowsca_from_mumps", MUMPS_INT),
        ("colsca_loc", _P_REAL), ("rowsca_loc", _P_REAL),
        # nach der Faktorisierung
        ("rowind", _P_INT), ("colind", _P_INT), ("pivots", _P_REAL),
        # rechte Seiten, Loesung, Statistik
        ("rhs", _P_REAL), ("redrhs", _P_REAL), ("rhs_sparse", _P_REAL),
        ("sol_loc", _P_REAL), ("rhs_loc", _P_REAL), ("rhsintr", _P_REAL),
        ("irhs_sparse", _P_INT), ("irhs_ptr", _P_INT), ("isol_loc", _P_INT),
        ("irhs_loc", _P_INT), ("glob2loc_rhs", _P_INT), ("glob2loc_sol", _P_INT),
        ("nrhs", MUMPS_INT), ("lrhs", MUMPS_INT), ("lredrhs", MUMPS_INT), ("nz_rhs", MUMPS_INT),
        ("lsol_loc", MUMPS_INT), ("nloc_rhs", MUMPS_INT), ("lrhs_loc", MUMPS_INT), ("nsol_loc", MUMPS_INT),
        ("schur_mloc", MUMPS_INT), ("schur_nloc", MUMPS_INT), ("schur_lld", MUMPS_INT),
        ("mblock", MUMPS_INT), ("nblock", MUMPS_INT), ("nprow", MUMPS_INT), ("npcol", MUMPS_INT),
        ("ld_rhsintr", MUMPS_INT),
        ("info", MUMPS_INT * 80), ("infog", MUMPS_INT * 80),
        ("rinfo", DMUMPS_REAL * 40), ("rinfog", DMUMPS_REAL * 40),
        # Nullraum
        ("deficiency", MUMPS_INT), ("pivnul_list", _P_INT), ("mapping", _P_INT),
        ("singular_values", _P_REAL),
        # Schur
        ("size_schur", MUMPS_INT), ("listvar_schur", _P_INT), ("schur", _P_REAL),
        # Arbeitsspeicher des Anwenders
        ("wk_user", _P_REAL),
        ("version_number", ctypes.c_char * 32),          # MUMPS_VERSION_MAX_LEN + 1 + 1
        ("ooc_tmpdir", ctypes.c_char * 1024), ("ooc_prefix", ctypes.c_char * 256),
        ("write_problem", ctypes.c_char * 1024),
        ("lwk_user", MUMPS_INT),
        ("save_dir", ctypes.c_char * 1024), ("save_prefix", ctypes.c_char * 256),
        ("metis_options", MUMPS_INT * 40),
        ("instance_number", MUMPS_INT),
    ]


# Fehlercodes INFOG(1) < 0 (MUMPS-Handbuch 5.8, Abschnitt 8): die haeufigen
# in Klartext, alles andere mit Nummer.
_FEHLER = {
    -1: "Fehler auf einem Prozess (INFOG(2) nennt ihn)",
    -2: "NNZ ausserhalb des zulaessigen Bereichs",
    -3: "JOB in dieser Reihenfolge nicht zulaessig (erst Analyse, dann Faktorisierung, dann Loesen)",
    -4: "Fehler in der vom Anwender vorgegebenen Permutation",
    -5: "Speicher fuer die Analyse konnte nicht angelegt werden",
    -6: "Matrix strukturell singulaer",
    -7: "Speicher konnte nicht angelegt werden",
    -8: "Ganzzahl-Arbeitsspeicher zu klein - ICNTL(14) erhoehen",
    -9: "Gleitkomma-Arbeitsspeicher zu klein - ICNTL(14) erhoehen",
    -10: "Matrix numerisch singulaer",
    -11: "Arbeitsspeicher fuer das Loesen zu klein",
    -13: "Speicher konnte nicht angelegt werden (Groesse in INFOG(2))",
    -16: "N ausserhalb des zulaessigen Bereichs",
    -17: "Sendepuffer zu klein",
    -19: "Maximaler Speicher (ICNTL(23)) zu klein",
    -20: "Empfangspuffer zu klein",
    -22: "Ein Zeiger der Struktur ist falsch gesetzt (INFOG(2) nennt ihn)",
    -37: "Eine Einstellung ist mit der gewaehlten Faktorisierung unvereinbar",
    -40: "Matrix nicht positiv definit (SYM=1) - SYM=2 verwenden",
    -44: "Loesen ohne gueltige Faktorisierung",
}


class MUMPSError(RuntimeError):
    """INFOG(1) < 0 nach einem Aufruf von dmumps_c."""

    def __init__(self, infog1: int, infog2: int, job: int):
        self.infog1, self.infog2, self.job = infog1, infog2, job
        text = _FEHLER.get(infog1, "Fehler")
        super().__init__(f"MUMPS (JOB={job}): INFOG(1)={infog1}, INFOG(2)={infog2} - {text}")


# ---------------------------------------------------------------------------
# Bibliothek laden
# ---------------------------------------------------------------------------
_dll = None
_dll_verzeichnisse = []            # Handles von os.add_dll_directory - offen halten


def _mkl_verzeichnisse() -> list:
    """Wo mkl_rt.3.dll liegen kann: neben der exe (PyInstaller), in der
    venv (pip install mkl legt sie unter Library/bin ab) oder dort, wohin
    statik3d.solver._find_mkl schon gezeigt hat."""
    kandidaten = []
    rt = os.environ.get("PYPARDISO_MKL_RT", "")
    if rt:
        kandidaten.append(os.path.dirname(rt))
    mei = getattr(sys, "_MEIPASS", "")
    if mei:
        kandidaten += [mei, os.path.join(mei, "Library", "bin")]
    kandidaten += [os.path.join(sys.prefix, "Library", "bin"), sys.prefix]
    try:
        import site
        for sp_ in site.getsitepackages():
            kandidaten.append(os.path.abspath(os.path.join(sp_, "..", "..", "Library", "bin")))
    except Exception:                                   # noqa: BLE001
        pass
    aus = []
    for d in kandidaten:
        if os.path.isdir(d) and glob.glob(os.path.join(d, "mkl_rt*.dll")) and d not in aus:
            aus.append(d)
    return aus


def physische_kerne() -> int:
    """Zahl der physischen Kerne (ohne Hyperthreading), Windows-API
    GetLogicalProcessorInformation; sonst cpu_count()."""
    try:
        k32 = ctypes.windll.kernel32

        class SLPI(ctypes.Structure):
            _fields_ = [("ProcessorMask", ctypes.c_size_t), ("Relationship", ctypes.c_int),
                        ("Reserved", ctypes.c_ulonglong * 2)]
        laenge = ctypes.c_ulong(0)
        k32.GetLogicalProcessorInformation(None, ctypes.byref(laenge))
        anzahl = laenge.value // ctypes.sizeof(SLPI)
        puffer = (SLPI * anzahl)()
        if not k32.GetLogicalProcessorInformation(puffer, ctypes.byref(laenge)):
            raise OSError("GetLogicalProcessorInformation")
        kerne = sum(1 for e in puffer if e.Relationship == 0)         # RelationProcessorCore
        if kerne > 0:
            return kerne
    except Exception:                                   # noqa: BLE001
        pass
    return os.cpu_count() or 1


#: Mehr Threads bringen MUMPS mit OpenBLAS nichts mehr - gemessen am
#: Ryzen 9 5950X (16 Kerne / 32 Threads), Faktorisierung symmetrisch:
#: Wuerfel 34 914 FHG: 1,26 s (1), 0,97 s (4), 0,86-1,09 s (8), 1,58 s (16),
#: 3,3 s (31 Threads); 201 720 FHG: 22,1 s (1), 8,1 s (8), 9,8 s (16).
THREADS_HOECHSTENS = 8


def threads_vorgabe() -> int:
    """Wie viele Threads MUMPS nehmen soll.

    MUMPS_NUM_THREADS gilt, wenn gesetzt, so wie es ist (bis zur Zahl der
    logischen Kerne). Sonst gilt MKL_NUM_THREADS bzw. OMP_NUM_THREADS -
    Statik3D setzt beide in solver.mkl_threads() auf "alle Kerne bis auf
    einen" - oder eben diese Vorgabe, jeweils gekappt auf die physischen
    Kerne und THREADS_HOECHSTENS: ueber die physischen Kerne hinaus
    (Hyperthreading) und ueber acht Threads hinaus wird MUMPS mit OpenBLAS
    langsamer, nicht schneller (Zahlen bei THREADS_HOECHSTENS).
    """
    eigen = os.environ.get("MUMPS_NUM_THREADS", "").strip()
    if eigen.isdigit() and int(eigen) > 0:
        return max(1, min(int(eigen), os.cpu_count() or 1))
    kappe = max(1, min(physische_kerne(), THREADS_HOECHSTENS))
    for name in ("MKL_NUM_THREADS", "OMP_NUM_THREADS"):
        wert = os.environ.get(name, "").strip()
        if wert.isdigit() and int(wert) > 0:
            return min(int(wert), kappe)
    return max(1, min(kappe, (os.cpu_count() or 2) - 1))


def _umgebung_setzen(name: str, wert: str) -> None:
    """Umgebungsvariable so setzen, dass auch die MinGW-Laufzeit sie sieht.

    Python schreibt ueber die UCRT; libgomp und libgfortran lesen ueber
    msvcrt.dll, die ihre eigene Kopie der Umgebung beim Start anlegt. Ein
    os.environ[...] = ... aus Python bleibt fuer sie unsichtbar (gemessen:
    OMP_NUM_THREADS=31 gesetzt, libgomp meldete 32).
    """
    os.environ[name] = wert
    try:
        ctypes.cdll.msvcrt._putenv(f"{name}={wert}".encode("ascii"))
    except Exception:                                   # noqa: BLE001
        pass
    try:
        ctypes.windll.kernel32.SetEnvironmentVariableW(name, wert)
    except Exception:                                   # noqa: BLE001
        pass


def set_threads(n: int) -> int:
    """Threadzahl fuer MUMPS und seine BLAS setzen (wirkt sofort, auch nach
    dem Laden); Rueckgabe: was die Laufzeit danach meldet.

    Beim eigenen Bau geht das **nur** ueber OpenMP (omp_set_num_threads):
    OpenBLAS in der OpenMP-Fassung richtet sich dann nach
    omp_get_max_threads() und rechnet einkernig, sobald es aus einer
    Parallelregion heraus gerufen wird (omp_in_parallel) - so, wie MUMPS
    es fuer seine Baumthreads (ICNTL(48)) braucht. openblas_set_num_threads()
    darf hier NIE gerufen werden: OpenBLAS 0.3.34 merkt sich das als
    "ausdruecklich gesetzt" (blas_is_num_threads_set_explicitly) und
    ignoriert omp_in_parallel() fortan. Gemessen am Wuerfel mit 34 914 FHG,
    SYM=0, 8 Threads: fuenf Baumthreads drehten in exec_blas in der
    while(true)-Schleife um die MAX_PARALLEL_NUMBER Puffer, ein sechster
    hatte eine verschachtelte OpenMP-Region geoeffnet - 1 959 CPU-Sekunden
    ohne Fortschritt (gdb-Rueckverfolgung im Bauverzeichnis, 13.09.2026).
    """
    n = max(1, int(n))
    _lade()
    if VARIANTE == "gfortran":
        gomp = ctypes.CDLL(os.path.join(LIB_DIR, "libgomp-1.dll"))
        gomp.omp_set_num_threads.argtypes = [ctypes.c_int]
        gomp.omp_set_num_threads(n)
    else:
        for name in ("mkl_rt.3.dll", "mkl_rt.2.dll", "mkl_rt.dll"):
            try:
                mkl = ctypes.CDLL(name)
                mkl.MKL_Set_Num_Threads.argtypes = [ctypes.c_int]
                mkl.MKL_Set_Num_Threads(n)
                break
            except (OSError, AttributeError):
                continue
    return threads()


def _lade() -> ctypes.CDLL:
    global _dll, VARIANTE
    if _dll is not None:
        return _dll
    if sys.platform != "win32":
        raise ImportError("dieses mumps-Paket enthaelt nur Windows-Bibliotheken (win_amd64)")
    pfad = None
    for name, datei in _VARIANTEN:
        if os.path.isfile(os.path.join(LIB_DIR, datei)):
            VARIANTE, pfad = name, os.path.join(LIB_DIR, datei)
            break
    if pfad is None:
        raise ImportError(f"keine MUMPS-DLL in {LIB_DIR} (erwartet libdmumps_seq.dll oder dmumps.dll)")
    n = threads_vorgabe()
    # vor dem Laden in die Umgebung (libgomp und MKL lesen sie beim Laden),
    # nach dem Laden ausdruecklich setzen (siehe _umgebung_setzen)
    _umgebung_setzen("OMP_NUM_THREADS", str(n))
    verzeichnisse = [LIB_DIR]
    if VARIANTE == "conda-mkl":
        mkl = _mkl_verzeichnisse()
        if not mkl:
            raise ImportError("mkl_rt.3.dll nicht gefunden - diese MUMPS-DLL rechnet auf der MKL "
                              "(pip install mkl; in der exe liegt sie neben den uebrigen DLLs)")
        verzeichnisse += mkl
    for d in verzeichnisse:
        try:
            _dll_verzeichnisse.append(os.add_dll_directory(d))
        except OSError:
            pass
    try:
        _dll = ctypes.CDLL(pfad)
    except OSError as ex:
        raise ImportError(f"{os.path.basename(pfad)} laesst sich nicht laden ({ex}); "
                          "Suchpfade: " + ", ".join(verzeichnisse)) from ex
    _dll.dmumps_c.argtypes = [ctypes.POINTER(DMUMPS_STRUC_C)]
    _dll.dmumps_c.restype = None
    set_threads(n)
    return _dll


def threads() -> int:
    """Mit wie vielen Threads MUMPS wirklich rechnet - gefragt bei der
    Laufzeit, nicht aus der Umgebung geraten."""
    try:
        _lade()
        if VARIANTE == "gfortran":
            gomp = ctypes.CDLL(os.path.join(LIB_DIR, "libgomp-1.dll"))
            f = gomp.omp_get_max_threads
            f.restype, f.argtypes = ctypes.c_int, []
            return max(1, int(f()))
        for name in ("mkl_rt.3.dll", "mkl_rt.2.dll", "mkl_rt.dll"):
            try:
                mkl = ctypes.CDLL(name)
            except OSError:
                continue
            f = mkl.MKL_Get_Max_Threads
            f.restype, f.argtypes = ctypes.c_int, []
            return max(1, int(f()))
    except Exception:                                   # noqa: BLE001
        pass
    return 1


def beschreibung() -> str:
    """Fuer Protokoll und Selbsttest: Bau und Threads."""
    _lade()
    bau = {"gfortran": "gfortran/OpenMP, OpenBLAS, METIS",
           "conda-mkl": "conda-forge/flang, BLAS aus der MKL"}.get(VARIANTE, VARIANTE)
    n = threads()
    return f"MUMPS {MUMPS_VERSION} ({bau}), " + (f"{n} Threads" if n > 1 else "einkernig")


# ---------------------------------------------------------------------------
# Kontext
# ---------------------------------------------------------------------------
class DMumpsContext:
    """Eine MUMPS-Instanz in doppelter Genauigkeit (Schnittstelle wie PyMUMPS).

    ``sym``: 0 unsymmetrisch (volle Matrix), 1 symmetrisch positiv definit,
    2 allgemein symmetrisch - bei 1 und 2 nur **ein** Dreieck uebergeben
    (MUMPS summiert doppelt gegebene Eintraege). ``par=1``: der Prozess
    rechnet mit (sequentiell die einzige sinnvolle Wahl).
    """

    def __init__(self, par: int = 1, sym: int = 0, comm=None):
        _lade()
        self.id = DMUMPS_STRUC_C()
        self.myid = 0
        self._irn = self._jcn = self._a = self._rhs = None
        self._lebt = False
        self.id.par = int(par)
        self.id.sym = int(sym)
        self.id.comm_fortran = _USE_COMM_WORLD
        self.id.job = -1
        _dll.dmumps_c(ctypes.byref(self.id))
        self._lebt = True
        version = self.id.version_number.decode("ascii", "replace").strip()
        if not version.startswith(MUMPS_VERSION):
            # Die Struktur passt nicht zur Bibliothek - alles Weitere waere
            # Speichermuell. Lieber hier abbrechen.
            self.destroy()
            raise RuntimeError(f"MUMPS meldet Version '{version}', erwartet {MUMPS_VERSION}: "
                               "dmumps_c.h und die DLL passen nicht zusammen")
        self._pruefen(-1)

    # -- Einstellungen ------------------------------------------------------
    def set_silent(self) -> None:
        """Keine Ausgabe auf Fortran-Einheiten (in einer exe ohne Konsole
        gibt es die nicht)."""
        self.set_icntl(1, -1)
        self.set_icntl(2, -1)
        self.set_icntl(3, -1)
        self.set_icntl(4, 0)

    def set_icntl(self, i: int, wert: int) -> None:
        """ICNTL(i) = wert, i 1-basiert wie im MUMPS-Handbuch."""
        if not 1 <= i <= 60:
            raise IndexError(f"ICNTL({i}) gibt es nicht (1..60)")
        self.id.icntl[i - 1] = int(wert)

    def get_icntl(self, i: int) -> int:
        return int(self.id.icntl[i - 1])

    def set_cntl(self, i: int, wert: float) -> None:
        if not 1 <= i <= 15:
            raise IndexError(f"CNTL({i}) gibt es nicht (1..15)")
        self.id.cntl[i - 1] = float(wert)

    def infog(self, i: int) -> int:
        """INFOG(i), 1-basiert."""
        return int(self.id.infog[i - 1])

    def rinfog(self, i: int) -> float:
        return float(self.id.rinfog[i - 1])

    def set_shape(self, n: int) -> None:
        self.id.n = int(n)

    # -- Matrix -------------------------------------------------------------
    def set_centralized_assembled_rows_cols(self, irn, jcn) -> None:
        """Zeilen- und Spaltenindizes, 1-basiert."""
        irn = np.ascontiguousarray(irn, dtype=np.int32)
        jcn = np.ascontiguousarray(jcn, dtype=np.int32)
        if irn.ndim != 1 or irn.shape != jcn.shape:
            raise ValueError("irn und jcn muessen gleich lange 1-D-Felder sein")
        if irn.size and (irn.min() < 1 or jcn.min() < 1):
            raise ValueError("Indizes sind 1-basiert (kleinster Wert 1)")
        self._irn, self._jcn = irn, jcn          # am Leben halten: MUMPS liest die Zeiger spaeter
        self.id.nnz = int(irn.size)
        self.id.nz = 0                            # nnz (64 Bit) hat Vorrang
        self.id.irn = irn.ctypes.data_as(_P_INT)
        self.id.jcn = jcn.ctypes.data_as(_P_INT)

    def set_centralized_assembled_values(self, a) -> None:
        a = np.ascontiguousarray(a, dtype=np.float64)
        if self._irn is None or a.shape != self._irn.shape:
            raise ValueError("erst Indizes setzen; Werte muessen dieselbe Laenge haben")
        self._a = a
        self.id.a = a.ctypes.data_as(_P_REAL)

    def set_centralized_assembled(self, irn, jcn, a) -> None:
        """COO-Matrix, Indizes 1-basiert (wie PyMUMPS)."""
        self.set_centralized_assembled_rows_cols(irn, jcn)
        self.set_centralized_assembled_values(a)

    def set_centralized_sparse(self, A) -> None:
        """scipy-Matrix (beliebiges Format); bei sym != 0 nur das untere Dreieck."""
        from scipy import sparse
        A = sparse.coo_matrix(A)
        if self.id.sym != 0:
            A = sparse.tril(A, format="coo")
        self.set_shape(A.shape[0])
        self.set_centralized_assembled(A.row + 1, A.col + 1, A.data)

    # -- rechte Seite -------------------------------------------------------
    def set_rhs(self, rhs) -> None:
        """Rechte Seite(n); nach JOB=3 steht dort die Loesung (in place).

        1-D: ein Vektor der Laenge n. 2-D (n, nrhs): Fortran-Reihenfolge,
        denn MUMPS erwartet die rechten Seiten spaltenweise hintereinander.
        Es wird nicht kopiert - darum muss das Feld schon passen.
        """
        rhs = np.asarray(rhs)
        if rhs.dtype != np.float64:
            raise TypeError("rhs muss float64 sein (in place - keine Kopie)")
        if rhs.ndim == 1:
            if not rhs.flags.c_contiguous:
                raise ValueError("rhs muss zusammenhaengend sein")
            nrhs = 1
        elif rhs.ndim == 2:
            if not rhs.flags.f_contiguous:
                raise ValueError("rhs (n, nrhs) muss Fortran-geordnet sein (np.asfortranarray)")
            nrhs = rhs.shape[1]
        else:
            raise ValueError("rhs muss 1-D oder 2-D sein")
        if rhs.shape[0] != self.id.n:
            raise ValueError(f"rhs hat {rhs.shape[0]} Zeilen, die Matrix {self.id.n}")
        self._rhs = rhs
        self.id.rhs = rhs.ctypes.data_as(_P_REAL)
        self.id.nrhs = int(nrhs)
        self.id.lrhs = int(self.id.n)

    # -- Ausfuehren ---------------------------------------------------------
    def run(self, job: int) -> None:
        """JOB: 1 Analyse, 2 Faktorisierung, 3 Loesen, 4 = 1+2, 5 = 2+3, 6 = 1+2+3."""
        if not self._lebt:
            raise RuntimeError("MUMPS-Instanz ist schon freigegeben")
        self.id.job = int(job)
        _dll.dmumps_c(ctypes.byref(self.id))
        self._pruefen(job)

    def _pruefen(self, job: int) -> None:
        if self.id.infog[0] < 0:
            raise MUMPSError(int(self.id.infog[0]), int(self.id.infog[1]), job)

    def destroy(self) -> None:
        """JOB=-2: die Faktorisierung und alles andere in MUMPS freigeben."""
        if self._lebt:
            self._lebt = False
            self.id.job = -2
            _dll.dmumps_c(ctypes.byref(self.id))
        self._irn = self._jcn = self._a = self._rhs = None

    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        self.destroy()

    def __del__(self):
        try:
            self.destroy()
        except Exception:                               # noqa: BLE001
            pass


__all__ = ["DMumpsContext", "DMUMPS_STRUC_C", "MUMPSError", "MUMPS_VERSION", "VARIANTE",
           "THREADS_HOECHSTENS", "threads", "set_threads", "threads_vorgabe", "physische_kerne",
           "beschreibung", "LIB_DIR", "LIZENZ_DIR"]
